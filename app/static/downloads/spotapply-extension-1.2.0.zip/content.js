// SpotApply Extension — Content Script
// Fills job application forms in the user's browser tab.

// ── Frame gating ──────────────────────────────────────────────────────────────
// The manifest injects this script into every frame (all_frames: true) so that
// career sites embedding their ATS board in an iframe still get filled. But we
// must stay inert inside ad/analytics/social iframes: only the top frame or a
// frame whose own host is a known ATS may run the copilot.
const HP_IS_TOP = (() => { try { return window === window.top; } catch (_) { return false; } })();

// Trusted ATS hosts: the host itself or a real subdomain — NEVER a substring.
// /greenhouse\.io/ accepted "greenhouse.io.unrelated.example" as an ATS, and
// with a live session that page received the applicant's details.
// Keep in lockstep with ATS_SUFFIXES in background.js (a test compares them).
const ATS_SUFFIXES = [
  "greenhouse.io", "lever.co", "ashbyhq.com", "myworkdayjobs.com", "workday.com",
  "myworkdaysite.com", "smartrecruiters.com", "avature.net", "icims.com", "taleo.net",
  "successfactors.com", "successfactors.eu", "sapsf.com", "brassring.com", "jobvite.com",
  "workable.com", "bamboohr.com", "recruitee.com", "teamtailor.com", "personio.de",
  "personio.com", "pinpointhq.com", "breezy.hr", "join.com", "rippling.com", "dover.com",
  "paylocity.com", "ultipro.com",
];
// Hosts that are only ever EMBEDDED as an application iframe on a careers page.
const ATS_FRAME_EXTRA = ["applytojob.com", "jazz.co", "jazzhr.com", "dayforcehcm.com",
                         "dayforce.com", "eightfold.ai", "oraclecloud.com"];

function hostIs(host, domain) {
  const h = String(host || '').toLowerCase().replace(/\.$/, '');
  return h === domain || h.endsWith('.' + domain);
}
function isTrustedATSHost(host) { return ATS_SUFFIXES.some((d) => hostIs(host, d)); }

const HP_FRAME_ACTIVE = HP_IS_TOP || isTrustedATSHost(location.hostname) ||
  ATS_FRAME_EXTRA.some((d) => hostIs(location.hostname, d));

// Gate for the always-on document listeners below (submit tracking, dropdown
// learning). They were registered unconditionally, so on EVERY site: submitting
// any form (a site login, a search box) marked the pending application
// SUBMITTED and killed the fill session, and picking any ARIA dropdown option
// POSTed the choice + label to /api/save-answer with the user's token.
//
// Both only mean anything while an application is actually being filled ON THIS
// PAGE, so that is exactly the gate: the copilot is running here (set by
// fillForm, covering manual Fill and auto-resume alike), or this is a known ATS
// host. Note "page has a form" is NOT sufficient — hasApplicationForm() accepts
// a lone input[type=email], i.e. any newsletter box on the web.
// isKnownATS/isBlockedHost are hoisted function declarations defined further
// down; they are only called at event time.
function hpCopilotSurface() {
  if (!HP_FRAME_ACTIVE) return false;
  try {
    if (isBlockedHost()) return false;
    return _copilotActive || isKnownATS();
  } catch (_) {
    return false;
  }
}

// Query matching elements including inside open shadow roots (some ATS widgets
// hide their <input type="file"> in a shadow DOM where querySelectorAll can't
// see it). Depth-first, open roots only.
function queryAllDeep(selector, root = document) {
  const out = [];
  const walk = (node) => {
    if (!node || !node.querySelectorAll) return;
    node.querySelectorAll(selector).forEach((el) => out.push(el));
    node.querySelectorAll('*').forEach((el) => { if (el.shadowRoot) walk(el.shadowRoot); });
  };
  try { walk(root); } catch (_) {}
  return out;
}

// ── Fields nobody may fill ───────────────────────────────────────────────────
// Live test 2026-10-09 (Ashby): the page's HIDDEN reCAPTCHA textarea
// (name="g-recaptcha-response", display:none) has no label, so its NAME became
// the "question", the AI's reply ("I'd be happy to help, but…") came back and
// was typed into it. A captcha / anti-bot field, a honeypot, and a text field
// the user cannot see are never filled, never asked about, never learned from.
// Honeypot WORDING counts only when the whole text is the instruction ("Leave
// this field blank") or it addresses humans ("If you are human, ..."): a real
// field that says "leave blank if none" is the applicant's to fill. "Human"
// counts only as the whole address (then punctuation, the end, or "leave" /
// "don't"): "If you are a Human Resources professional, ..." is a question.
// Keep the pattern IDENTICAL to app/autofill/field_guards.py.
const _ANTI_BOT_RE = /(re-?captcha|h-?captcha|captcha|turnstile|cf[-_]chl|honey-?pot|arkose|funcaptcha|friendly-?captcha|frc-captcha|bot[-_ ]?(?:check|trap|field)|anti[-_ ]?bot|if you(?:'re|’re| are) (?:a )?human(?:\s*[,.;:!?)]|\s*$|\s+(?:please |then )?(?:leave|do ?n[o'’]t)\b)|^\W*(?:please )?(?:leave this (?:field |input |box )?(?:blank|empty)|do ?n[o'’]t (?:fill|change) (?:in )?this(?: field)?(?: in| out)?)\W*$)/i;
// Captcha WIDGETS (never a page or form wrapper, whose class may mention captcha).
const _CAPTCHA_WIDGET_SEL = '.g-recaptcha, .grecaptcha-badge, .h-captcha, .cf-turnstile, .frc-captcha';

function isAntiBotField(el) {
  if (!el || !el.getAttribute) return false;
  // Each text on its own (a honeypot sentence must be the WHOLE text), with
  // its whitespace collapsed the way field_guards.is_anti_bot_field does.
  const test = (t) => !!t && _ANTI_BOT_RE.test(String(t).replace(/\s+/g, ' ').trim());
  const own = [el.getAttribute('name'), el.id, el.getAttribute('class'),
               el.getAttribute('aria-label'), el.getAttribute('placeholder'),
               el.getAttribute('title')];
  if (own.some(test)) return true;
  try { if (el.closest && el.closest(_CAPTCHA_WIDGET_SEL)) return true; } catch (_) {}
  // A honeypot announces itself to people: "Leave this field blank".
  try {
    const lbl = (el.labels && el.labels[0] && el.labels[0].textContent) || '';
    if (test(lbl)) return true;
  } catch (_) {}
  return false;
}

/** A field a person could actually see and type into right now. */
function isUserVisible(el) {
  if (!el || !el.isConnected) return false;
  const win = (el.ownerDocument && el.ownerDocument.defaultView) || window;
  let style = null;
  try { style = win.getComputedStyle(el); } catch (_) { return true; }
  if (!style) return true;
  if (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse') return false;
  if (el.offsetParent === null && style.position !== 'fixed') return false;   // a display:none ancestor
  const r = el.getBoundingClientRect();
  if (r.width < 2 && r.height < 2) return false;                // 0x0 / 1px honeypots
  const sx = win.scrollX || 0, sy = win.scrollY || 0;
  if (r.right + sx <= 0 || r.bottom + sy <= 0) return false;    // pushed off the page (left:-9999px)
  return true;
}

/** A free-text entry: the kind of field a hidden one must never be written into. */
function isTextEntry(el) {
  if (!el) return false;
  if (el.tagName === 'TEXTAREA') return true;
  if (el.tagName !== 'INPUT') return false;
  const t = (el.getAttribute('type') || 'text').toLowerCase();
  return ['text', 'email', 'tel', 'url', 'number', 'search', ''].includes(t);
}

/** May the copilot write into this field at all? */
function canFillField(el) {
  if (!el || isAntiBotField(el)) return false;
  if (isTextEntry(el) && !isUserVisible(el)) return false;
  return true;
}

/** A form field's NAME used as its label ("g-recaptcha-response", "question_123"). */
function looksLikeFieldIdentifier(text) {
  const s = String(text || '').trim();
  return !!s && !/\s/.test(s) && /^[A-Za-z0-9_.:\[\]-]+$/.test(s) && /[_\-\d\[\]:.]/.test(s);
}

// A MODEL reply ABOUT the question instead of an answer to it. Never typed into
// a form (the server refuses these too; this covers an older server). The full
// test is for what a model just wrote; a remembered answer may be the user's
// own words ("I am unable to start before January"), so it is judged only by
// the forms a model alone writes (looksLikeModelOnlyReply). Same patterns as
// app/autofill/field_guards.py.
const _META_START_RE = /^\s*["']?(?:i'?d be (?:happy|glad) to help|i(?:'m| am) (?:sorry,? (?:but )?i (?:cannot|can't|can not|am unable to|am not able to)|unable to|not able to) (?:answer|write|respond|provide|help|complete|assist)\b|i(?:'m| am) (?:sorry|unable|not able)\b[^.?!]{0,60}\b(?:the|this|your) (?:essay )?(?:question|prompt)\b|i (?:cannot|can't|can not|am unable to|won't) (?:answer|write|respond|provide|help(?! but)|complete)|as an ai(?: (?:language )?model| assistant)?\s*,|i notice (?:that )?(?:the|this|your) (?:essay )?(?:question|prompt|field|text)|it (?:looks|seems|appears) (?:like|that) (?:the|this|your) (?:essay )?(?:question|prompt|field|text)|(?:the|this) (?:essay )?(?:question|prompt|field) (?:appears|seems|you provided|is (?:incomplete|unclear|missing))|could you (?:please )?(?:provide|clarify|share)|please (?:provide|clarify|share) (?:the|more|a|an))/i;
const _META_ANY_RE = /(?:question|prompt) (?:appears|seems) (?:to be )?(?:incomplete|unclear|missing|empty|cut off)|(?:looks|seems|appears) (?:like|to be) (?:a|an) (?:technical|form|html|internal|system) (?:parameter|field|identifier|name|token|value)|(?:this|that|it|"[^"]{1,80}") (?:is|isn't|is not|doesn't look like|does not look like|doesn't appear to be|does not appear to be) (?:a|an) (?:real |actual |complete |valid )?(?:essay |application )?question\b|form field (?:name|identifier)|provide the (?:actual|full|complete) (?:essay )?question|as an ai language model|as an ai (?:model|assistant),/i;
const _META_MODEL_ONLY_RE = /^\s*["']?(?:i'?d be (?:happy|glad) to help(?: you)?(?:\s*[,!.:;]| with (?:this|that|the|your) (?:essay |application )?(?:question|prompt))|as an ai(?: (?:language )?model| assistant)?\s*,|(?:i notice (?:that )?|it (?:looks|seems|appears) (?:like|that) )?(?:the|this|your) (?:essay )?(?:question|prompt) (?:appears|seems|is) (?:to be )?(?:incomplete|unclear|missing|empty|cut off))/i;
function looksLikeMetaReply(answer) {
  const a = String(answer || '').trim();
  if (!a) return false;
  if (a.replace(/^[\s."']+|[\s."']+$/g, '').toUpperCase() === 'SKIP') return true;
  return _META_START_RE.test(a) || _META_ANY_RE.test(a);
}
/** A reply in a form only a model writes: safe to apply to the user's own words. */
function looksLikeModelOnlyReply(answer) {
  const a = String(answer || '').trim();
  return !!a && _META_MODEL_ONLY_RE.test(a);
}

// Backend base URL for a fill pack. The server deploys independently of
// installed extensions, so accept both the current key and the legacy
// hirepath_url one — an old server must keep working with a new install and
// vice versa. Everything else in this file goes through this helper.
function packBase(pack) {
  return (pack && (pack.spotapply_url || pack.hirepath_url)) || '';
}

// A pack can only drive a fill if it actually carries the applicant. The
// dashboard's init pack is credentials-only, so without this check the filler
// happily wrote `undefined` into every field it matched.
function packIsFillable(pack) {
  if (!pack || typeof pack !== 'object') return false;
  return Boolean(
    (pack.first_name && String(pack.first_name).trim()) ||
    (pack.last_name && String(pack.last_name).trim()) ||
    (pack.email && String(pack.email).trim())
  );
}

function _packSummary(pack) {
  if (!pack || typeof pack !== 'object') return String(pack);
  return JSON.stringify({
    keys: Object.keys(pack).length,
    app_id: pack.app_id ?? null,
    job_title: pack.job_title ?? null,
    hasName: !!(pack.first_name || pack.last_name),
    hasEmail: !!pack.email,
    hasToken: !!pack.auth_token,
  });
}

// ── EEO / demographic self-identification ────────────────────────────────────
// Gender, race/ethnicity, veteran and disability questions are VOLUNTARY,
// legally-protected self-identification. Answering them on someone's behalf —
// even with "Decline to self-identify" — is a decision only the applicant can
// make, so it is strictly opt-in and OFF by default. The fields are still
// highlighted for the user to complete; we just never write them unattended.
let _eeoAutofillEnabled = false;
try {
  chrome.storage.local.get(['spotapply_eeo_autofill'], (d) => {
    _eeoAutofillEnabled = d && d.spotapply_eeo_autofill === true;
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.spotapply_eeo_autofill) {
      _eeoAutofillEnabled = changes.spotapply_eeo_autofill.newValue === true;
    }
  });
} catch (_) {}

// ── Native autofill switch ───────────────────────────────────────────────────
// Some boards parse the uploaded resume themselves ("Autofill with Resume" on
// Workday, Ashby's autofill card, Lever's parsing upload). When one is offered
// we feed it the resume FIRST and only fill what it left empty or got wrong
// (see runNativeAutofill). ON unless the user switched it off: an absent key
// is ON, so an install predating the setting behaves the same as a new one.
let _nativeAutofillEnabled = true;
try {
  chrome.storage.local.get(['spotapply_native_autofill'], (d) => {
    _nativeAutofillEnabled = !(d && d.spotapply_native_autofill === false);
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.spotapply_native_autofill) {
      _nativeAutofillEnabled = changes.spotapply_native_autofill.newValue !== false;
    }
  });
} catch (_) {}

// Protected self-identification questions, by their wording. Used at every
// write path that is not fillEEOField itself — saved-answer recall, dropdown
// learning, AI answers — so the opt-out cannot be bypassed by a remembered
// answer (audit 2026-09-30: recall set Gender while autofill was OFF).
const _DEMOGRAPHIC_RE = /\b(gender|sex|pronouns?|race|racial|ethnic\w*|hispanic|latin[oaex]|veteran|disab\w*|sexual orientation|transgender|lgbtq?\w*)\b/i;
function isDemographicQuestion(text) {
  return _DEMOGRAPHIC_RE.test(deaccent(String(text || '')));
}

/** An answer the user SAVED in their SpotApply profile. Consent is the saved
 *  form (`eeo_confirmed`), not the wording: a saved "Decline to self-identify"
 *  is as deliberate as "Male". The old rule skipped declines, so a confirmed
 *  decline was the one profile answer the form then asked the user again
 *  (owner's report, 2026-10-10: the self-identification given in the profile
 *  was not filled). An unconfirmed profile states nothing — the server already
 *  sends its legacy defaults as "Decline", and those are never written. */
function eeoStated(value) {
  const v = String(value || '').trim();
  return !!(v && _copilotPack && _copilotPack.eeo_confirmed);
}

// ── EEO answer categories ────────────────────────────────────────────────────
// Employer forms phrase the same answers a dozen ways ("Decline to
// self-identify" / "I don't wish to answer" / "Prefer not to say"; "I am not a
// protected veteran" / "No, I am not a veteran"), so a profile value is matched
// to an option by CATEGORY, never by substring: "Male" contains-matches
// "Female", and a confirmed decline matched nothing on a form whose option
// reads "I decline to self-identify". Parenthetical qualifiers are dropped
// first — "Asian (Not Hispanic or Latino)" is Asian, not Hispanic. Order within
// a kind matters: the negative phrasing is tested before the positive one it
// contains ("I am NOT a protected veteran" holds "protected veteran").
const _EEO_DECLINE_RE = /decline|prefer not|do not wish|don.t wish|choose not|not to (?:answer|disclose|identify|self|say|specify|provide)|rather not|no answer|don.t want|not want to answer|wish not/i;
const _EEO_CATEGORIES = {
  gender: [
    ['nonbinary', /non.?binary|genderqueer|gender.?(?:fluid|non.?conform|diverse)|third gender/i],
    ['male',      /^male\b|\bman\b|^m$/i],
    ['female',    /^female\b|\bwoman\b|^f$/i],
    ['other',     /\bother\b|another|self.?describe|not listed/i],
  ],
  ethnicity: [
    ['two_or_more',     /two or more|multi.?racial|mixed/i],
    ['hispanic',        /hispanic|latin/i],
    ['black',           /\bblack\b|african.?american/i],
    ['asian',           /\basian\b/i],
    ['native_american', /american indian|alaskan? native|native american|indigenous|first nations/i],
    ['pacific',         /hawaiian|pacific islander/i],
    ['white',           /\bwhite\b|caucasian/i],
    ['middle_eastern',  /middle eastern|north african/i],
  ],
  veteran: [
    ['no',  /not a (?:protected )?veteran|not protected|^no\b|i am not|do not identify/i],
    ['yes', /^yes\b|protected veteran|i am a veteran|one or more of the classifications|identify as (?:a )?(?:protected )?veteran|disabled veteran|recently separated|active.?duty|armed forces|served/i],
  ],
  disability: [
    ['no',  /^no\b|do not have|don.t have|not have a disability|no disability|never had/i],
    ['yes', /^yes\b|i have a disability|have a disability|history.record of having|had one in the past/i],
  ],
  // Greenhouse asks "Are you Hispanic/Latino?" as its own Yes/No before Race.
  hispanic: [
    ['no',  /^no\b|not hispanic/i],
    ['yes', /^yes\b|hispanic or latin/i],
  ],
};
const _EEO_PLACEHOLDER_RE = /^(?:please )?(?:select|choose)\b|^-+$|^\s*$/i;

function eeoCategory(kind, text) {
  const t = deaccent(String(text || '')).replace(/\([^)]*\)/g, ' ').replace(/\s+/g, ' ').trim();
  if (!t) return null;
  if (_EEO_DECLINE_RE.test(t)) return 'decline';
  for (const pair of (_EEO_CATEGORIES[kind] || [])) {
    if (pair[1].test(t)) return pair[0];
  }
  return null;
}

/** Index of the option that answers `value` for a `kind` question, else -1. */
function eeoPickOption(kind, value, optionTexts) {
  const want = eeoCategory(kind, value);
  const texts = (optionTexts || []).map(t => String(t || ''));
  if (!want) {
    // A value with no category: only an exact match may stand in for it.
    const lower = String(value || '').toLowerCase().trim();
    return lower ? texts.findIndex(t => t.toLowerCase().trim() === lower) : -1;
  }
  for (let i = 0; i < texts.length; i++) {
    if (_EEO_PLACEHOLDER_RE.test(texts[i].trim())) continue;
    if (eeoCategory(kind, texts[i]) === want) return i;
  }
  return -1;
}

/** The profile's answer to a `kind` question. Greenhouse's separate
 *  "Are you Hispanic/Latino?" is derived from the ethnicity answer. */
function eeoValueFor(pack, kind) {
  const p = pack || {};
  if (kind === 'gender') return p.gender || '';
  if (kind === 'ethnicity') return p.ethnicity || '';
  if (kind === 'veteran') return p.veteran_status || '';
  if (kind === 'disability') return p.disability_status || '';
  if (kind === 'hispanic') {
    const cat = eeoCategory('ethnicity', p.ethnicity);
    if (!cat) return '';
    if (cat === 'decline') return 'Decline to self-identify';
    return cat === 'hispanic' ? 'Yes' : 'No';
  }
  return '';
}

/** Which protected question an element asks (from its own label, name, id,
 *  aria text — and its field block's label only when that block holds exactly
 *  one control), or null. The kind decides WHICH profile answer is written;
 *  a wrong guess here would write a demographic answer into another field. */
function eeoKindOf(el) {
  const ctx = deaccent(_eeoContextText(el)).toLowerCase();
  if (!ctx.trim()) return null;
  if (/hispanic|latin[oax]?\b/.test(ctx) && !/\brace\b|ethnic/.test(ctx)) return 'hispanic';
  if (/\bgender\b|\bsex\b/.test(ctx)) return 'gender';
  if (/\brace\b|racial|ethnic/.test(ctx)) return 'ethnicity';
  if (/veteran/.test(ctx)) return 'veteran';
  if (/disab/.test(ctx)) return 'disability';
  return null;
}

function _eeoContextText(el) {
  if (!el || !el.getAttribute) return '';
  const parts = [];
  try { parts.push(labelText(el) || ''); } catch (_) {}
  for (const a of ['aria-label', 'name', 'id', 'data-automation-id', 'placeholder', 'title']) {
    const v = el.getAttribute(a);
    if (v) parts.push(v);
  }
  try {
    const inner = el.querySelector && el.querySelector('input, [role="combobox"]');
    if (inner && inner !== el) parts.push(_eeoContextText(inner));   // a control wrapping its input
    const block = el.closest('[class*="field"], [class*="question"], [class*="form-group"], fieldset, li, .form-row');
    if (block) {
      const controls = block.querySelectorAll('select, [role="combobox"], button[aria-haspopup="listbox"], input:not([type="hidden"])');
      const lab = block.querySelector('label, legend, [class*="label"]');
      if (lab && controls.length <= 2) parts.push(lab.textContent || '');
    }
  } catch (_) {}
  return parts.join(' ');
}

function selectEEOOption(el, kind, value) {
  if (el.dataset && el.dataset.spotapplyUserModified === 'true') {
    console.log('[SpotApply] Keeping your own choice in', el.name || el.id || 'a dropdown');
    return false;
  }
  const opts = Array.from(el.options || []);
  const idx = eeoPickOption(kind || eeoKindOf(el), value, opts.map(o => o.text));
  if (idx < 0) return selectOption(el, value);     // unknown wording: the literal, or nothing
  el.value = opts[idx].value;
  try { el.dataset.spotapplyFilled = 'true'; } catch (_) {}
  el.dispatchEvent(new Event('change', { bubbles: true }));
  return true;
}

function selectEEORadio(radio, kind, value) {
  const name = radio.getAttribute('name');
  const group = name
    ? Array.from(document.querySelectorAll(`input[type="radio"][name="${CSS.escape(name)}"]`))
    : [radio];
  const texts = group.map(r => labelText(r) || (r.closest('label') ? r.closest('label').textContent : '') || r.value || '');
  const idx = eeoPickOption(kind || eeoKindOf(radio), value, texts);
  if (idx < 0) return false;
  const pick = group[idx];
  if (pick.dataset && pick.dataset.spotapplyUserModified === 'true') return false;
  if (!pick.checked) {
    pick.click();
    if (!pick.checked) { pick.checked = true; pick.dispatchEvent(new Event('change', { bubbles: true })); }
  }
  try { pick.dataset.spotapplyFilled = 'true'; } catch (_) {}
  return true;
}

/** Write an EEO answer only with explicit consent. Returns true if written. */
function fillEEOField(el, value, kind) {
  // Consent = the popup switch, OR the user having saved this answer in their
  // own SpotApply profile (owner's rule, 2026-09-30). A remembered answer from
  // another form is still never consent (recall skips these questions).
  if (!_eeoAutofillEnabled && !eeoStated(value)) {
    console.log('[SpotApply] Leaving demographic question for you (EEO autofill is off):',
                (el && (el.name || el.id)) || 'field');
    return false;
  }
  if (!value || !el) return false;
  if (el.tagName === 'SELECT') return selectEEOOption(el, kind, value);
  if (el.tagName === 'INPUT' && el.type === 'radio') return selectEEORadio(el, kind, value);
  // A button or combobox opens asynchronously — fillEEOCustomDropdowns owns
  // those, after the synchronous writers have run.
  if (el.tagName === 'BUTTON' || el.getAttribute('role') === 'combobox') return false;
  return fillInput(el, value);
}

/** The EEO <select>s a page shows, by id or label — run twice on Greenhouse,
 *  whose Race dropdown appears only after "Are you Hispanic/Latino?" = No. */
function fillEEOSelectsIn(root, pack) {
  let n = 0;
  for (const el of root.querySelectorAll(
    "select[id*='gender' i], select[id*='race' i], select[id*='ethnic' i], select[id*='hispanic' i], " +
    "select[id*='veteran' i], select[id*='disab' i]"
  )) {
    if (el.value && el.value !== '') continue;
    const kind = eeoKindOf(el);
    if (!kind) continue;
    if (fillEEOField(el, eeoValueFor(pack, kind) || 'decline', kind)) n++;
  }
  return n;
}

function _customDropdownHasValue(el) {
  const txt = ((el.textContent || '') + ' ' + (el.value || '')).replace(/\s+/g, ' ').trim();
  if (!txt) return false;
  return !_EEO_PLACEHOLDER_RE.test(txt) && !/^select\b|^choose\b|^-$|^select an option|^select\.\.\./i.test(txt);
}

/** Voluntary self-ID on CUSTOM dropdowns — Greenhouse's React selects
 *  (`.select__control` + `input[role=combobox]`), Workday's listbox buttons,
 *  Avature-style comboboxes. These never rendered as <select>, so the sync
 *  writers above could not reach them; a confirmed answer was left blank on
 *  every such form. Same consent rule, category matching, nothing else touched. */
async function fillEEOCustomDropdowns(pack) {
  let n = 0;
  const seen = new Set();
  const controls = queryAllDeep(
    "[role='combobox'], button[aria-haspopup='listbox'], button[data-automation-id='select-button'], [class*='select__control']"
  );
  for (const raw of controls) {
    const el = (raw.closest && raw.closest('[class*="select__control"]')) || raw;
    if (seen.has(el) || el.tagName === 'SELECT') continue;
    seen.add(el);
    if (!el.offsetParent && !el.getClientRects().length) continue;
    if (el.dataset && (el.dataset.spotapplyUserModified === 'true' || el.dataset.spotapplyFilled === 'true')) continue;
    const kind = eeoKindOf(el);
    if (!kind) continue;
    const value = eeoValueFor(pack, kind);
    if (!value) continue;
    if (!_eeoAutofillEnabled && !eeoStated(value)) {
      console.log('[SpotApply] Leaving demographic question for you (EEO autofill is off):', kind);
      continue;
    }
    if (_customDropdownHasValue(el)) continue;
    try {
      if (await selectEEOCustom(el, kind, value)) n++;
    } catch (e) {
      console.warn('[SpotApply] EEO dropdown failed:', e.message);
    }
  }
  return n;
}

async function selectEEOCustom(el, kind, value) {
  const trigger = (el.querySelector && el.querySelector('input[role="combobox"], [role="combobox"]')) || el;
  const press = (t) => {
    for (const type of ['mousedown', 'mouseup', 'click']) {
      t.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    }
  };
  try { trigger.focus(); } catch (_) {}
  press(el);
  if (trigger !== el) press(trigger);
  await delay(350);
  const options = queryAllDeep(
    '[role="option"], [role="listbox"] li, [class*="select__option"], [data-automation-id*="option" i], ' +
    '.wd-Dropdown-Option, [role="menuitem"], [data-automation-label]'
  ).filter(o => o.offsetParent !== null || o.getClientRects().length);
  const texts = options.map(o => (o.getAttribute('data-automation-label') || o.textContent || '').trim());
  const idx = eeoPickOption(kind, value, texts);
  if (idx < 0) {
    try { trigger.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); } catch (_) {}
    console.log('[SpotApply] No option answers', kind, 'on this dropdown — left for you');
    return false;
  }
  press(options[idx]);
  await delay(300);
  try { el.dataset.spotapplyFilled = 'true'; } catch (_) {}
  return true;
}

// ── Essay prompts vs field labels ────────────────────────────────────────────
// Field matching is substring-based, so a 40-word prompt like "Our team
// operates like an AI transformation startup within a larger company… share one
// example…" hit the /company/ rule and got the user's employer name written
// into it — a verified, non-empty, green-highlighted write of the WRONG thing.
// Read-back verification cannot catch this: the value landed, it just doesn't
// belong. The shape of the LABEL is the signal — a real field label is a short
// noun phrase; an essay prompt is a sentence.
function looksLikeEssayPrompt(labelText, el) {
  const t = String(labelText || '').trim();
  if (!t) return false;
  const words = t.split(/\s+/).length;
  if (words >= 12) return true;
  // A textarea asking anything conversational is a prompt, not a field.
  if (el && el.tagName === 'TEXTAREA' && words >= 6) return true;
  return /\b(describe|tell us|share (?:an?|one|your)|give (?:an?|us)|walk us|explain why|in your own words)\b/i.test(t);
}

// ── Phone fields wrapped in an international-telephone widget ────────────────
// Recruitee (and intl-tel-input generally) renders a country selector beside
// the number and re-parses whatever is typed. Writing "+1 (513) 276-3950" made
// the widget eat "51" as the country code: the field became "+51 32763950" and
// the country flipped to Peru — an application submitted with a number that
// cannot receive a call.
//
// Detection is EMPIRICAL, not markup-based: sniffing for .iti/country-button
// markup missed Recruitee entirely. We write, then check the digits — if they
// survived, there was no widget to worry about.

/** Digits only, in E.164 when we can tell the country. */
function toE164(raw, defaultCc = '1') {
  const s = String(raw || '').trim();
  if (!s) return '';
  const digits = s.replace(/\D/g, '');
  if (!digits) return '';
  if (s.startsWith('+')) return '+' + digits;
  // A bare 10-digit number is North American; 11 starting with 1 already has it.
  if (digits.length === 10) return `+${defaultCc}${digits}`;
  if (digits.length === 11 && digits.startsWith('1')) return `+${digits}`;
  return `+${digits}`;
}

/**
 * Write a phone number without letting a country widget re-interpret it.
 * Returns true only if the value stuck AND the country did not change.
 */
function fillPhoneField(el, raw) {
  const want = String(raw || '').trim();
  if (!want || isAntiBotField(el)) return false;
  const wantDigits = want.replace(/\D/g, '').slice(-10);   // national significant digits
  if (!wantDigits) return false;

  // After the board's own resume autofill, its formatting of the SAME number
  // stands ("(415) 555-0199" for "+1 415 555 0199"); only a different number
  // is corrected — the number is the applicant's, so a wrong parse is not.
  _lastWriteKept = false;
  if (_nativePrefillActive && String(el.value || '').trim() &&
      !shouldOverwrite('phone', el.value, want)) {
    _lastWriteKept = true;
    return true;
  }

  const beforeCountry = intlTelCountry(el);
  // Verify by DIGITS, never by string equality: every phone widget reformats
  // ("+1 513-276-3950", "(513) 276-3950"), so a strict compare always reported
  // "write did not stick" — and the old fallback then re-wrote the raw string,
  // which is exactly what let the widget eat "51" as a country code.
  // Trailing digits alone are NOT enough. "+51 32763950" contains the very
  // same ten digits as "(513) 276-3950" — the widget just re-partitioned them,
  // stealing "51" as Peru's country code. When the field carries a "+", the
  // WHOLE number must match, country code included.
  const wantE164Digits = toE164(want).replace(/\D/g, '');
  const landed = () => {
    const v = String(el.value || '');
    const digits = v.replace(/\D/g, '');
    if (v.includes('+')) return digits === wantE164Digits;
    return digits.endsWith(wantDigits) && digits.length <= wantE164Digits.length;
  };

  const write = (value) => {
    try {
      const proto = Object.getOwnPropertyDescriptor(
        (el.ownerDocument?.defaultView || window).HTMLInputElement.prototype, 'value');
      if (proto && proto.set) proto.set.call(el, value); else el.value = value;
      ['input', 'change', 'blur'].forEach((ev) =>
        el.dispatchEvent(new Event(ev, { bubbles: true })));
    } catch (_) { try { el.value = value; } catch (__) {} }
  };

  // 1. Write it as given. Markup-sniffing for intl-tel missed Recruitee, so
  //    detect the widget EMPIRICALLY instead: if the digits survive and the
  //    country didn't move, there was no widget to worry about and the form
  //    keeps its own formatting.
  write(want);
  if (landed() && !countryChanged(el, beforeCountry)) return markPhoneFilled(el, want);

  // 2. Something re-parsed it. E.164 states the country explicitly instead of
  //    letting the widget carve a country code out of the leading digits.
  write(toE164(want));
  if (landed() && !countryChanged(el, beforeCountry)) return markPhoneFilled(el, want);

  // 3. Some widgets own the "+" and reject it in the text box. Set the country
  //    selector explicitly, then write only the national digits.
  const set = setIntlTelCountry(el, 'us');
  write(wantDigits);
  if (landed() && (set || !countryChanged(el, beforeCountry))) return markPhoneFilled(el, want);

  // 4. Still wrong — do NOT leave a mangled number in a field that gets
  //    submitted. Clear it and let the user type it.
  console.warn('[SpotApply] Phone widget rejected the number (value now',
               JSON.stringify(el.value), ', country', intlTelCountry(el),
               ') — clearing it rather than submitting something unreachable');
  write('');
  try { delete el.dataset.spotapplyFilled; } catch (_) {}
  return false;
}

function markPhoneFilled(el, want) {
  try {
    el.dataset.spotapplyFilled = 'true';
    el.dataset.spotapplyLastWrite = String(el.value || '');
  } catch (_) {}
  return true;
}

function countryChanged(el, before) {
  const after = intlTelCountry(el);
  if (!after) return false;                 // nothing readable — landed() decides
  // A FAILED "before" read must not mean "nothing changed": on Recruitee the
  // country control sits outside the input's immediate wrapper, so `before`
  // came back null and a flip to Peru sailed through this guard.
  if (!before) return !/united states|\bus\b|^us$/i.test(after);
  return before !== after;
}

/** Point an intl-tel country selector at `iso` (best effort). */
function setIntlTelCountry(el, iso) {
  const scope = el.closest('.iti, .intl-tel-input, .PhoneInput, div');
  if (!scope) return false;
  const sel = scope.querySelector('select[class*="country" i], select[name*="country" i]');
  if (sel) {
    const opt = Array.from(sel.options).find(
      (o) => (o.value || '').toLowerCase() === iso ||
             /united states|usa/i.test(o.text || ''));
    if (opt) {
      sel.value = opt.value;
      sel.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
  }
  return false;
}

/** Best-effort read of the widget's currently selected country. */
function intlTelCountry(el) {
  if (!el) return null;
  // Widen the search: Recruitee renders the country control as a sibling of
  // the input's WRAPPER, not of the input, so a single closest('div') missed it
  // entirely and every country check silently passed.
  const scopes = [el.closest('.iti, .intl-tel-input, .PhoneInput')];
  let node = el.parentElement;
  for (let i = 0; node && i < 4; i++, node = node.parentElement) scopes.push(node);

  for (const scope of scopes) {
    if (!scope || !scope.querySelector) continue;
    const sel = scope.querySelector('select[class*="country" i], select[name*="country" i]');
    if (sel && sel.value) return sel.value;
    // aria-label is how the accessible ones expose it, e.g.
    // "Select country calling code: Peru".
    const btn = Array.from(scope.querySelectorAll('button, [role="combobox"], [aria-label]'))
      .find((b) => /country|calling code|dial code/i.test(
        (b.getAttribute('aria-label') || b.getAttribute('title') || '')));
    if (btn) {
      const label = (btn.getAttribute('aria-label') || btn.getAttribute('title') || '').trim();
      // Keep just the country part of "…calling code: Peru".
      const m = label.match(/:\s*(.+)$/);
      return (m ? m[1] : label).trim().slice(0, 40) || null;
    }
    const flag = scope.querySelector('.iti__selected-flag');
    if (flag) return (flag.getAttribute('title') || flag.textContent || '').trim().slice(0, 40) || null;
  }
  return null;
}

// ── Yes/No screening questions ───────────────────────────────────────────────
// A screening-heavy board (14 required radios on one Recruitee form) left every
// one unanswered, because these were routed to the LLM's ai_answers and that
// came back empty. They don't need a model: the answers are already in the
// profile. An unanswered REQUIRED radio is worse than a debatable one — the
// user cannot submit at all.
//
// Only questions the profile actually PROVES are answered. Citizenship, W2 vs
// C2C, relocation, criminal history and anything demographic are deliberately
// left blank: guessing those is harmful, and the user reviews the yellow
// fields anyway.
function classifyScreeningQuestion(q, pack) {
  const t = String(q || '').toLowerCase().replace(/\s+/g, ' ').trim();
  if (!t) return null;

  // Relocation — "are you willing to relocate?" is answered YES only when the
  // user ticked "Open to relocation" (their own statement). Otherwise left for
  // them. Never "Do you need relocation assistance/package?" — that asks for a
  // benefit, not willingness, and Yes there is a request we must not make.
  if (/relocat|willing to move/.test(t)) {
    if (/assist|package|benefit|support|stipend|reimburs|expense|cover/.test(t)) return null;
    return pack.open_to_relocation === true ? true : null;
  }

  // Never auto-answer these — a wrong answer here is damaging, and the profile
  // does not actually establish any of them.
  const NEVER = /citizen|green ?card|permanent resident|felony|convicted|criminal|background check|drug (test|screen)|w-?2\b|c2c|corp.to.corp|1099|relocat|willing to move|salary|compensation|notice period/;
  if (NEVER.test(t)) return null;
  if (/gender|race|ethnic|veteran|disab|hispanic|latino/.test(t)) return null;

  // Sponsorship / work authorization — ONE interpreter for every control type.
  if (/sponsor|authoriz|eligible to work|right to work|legally (able|permitted|allowed) to work|work permit/.test(t)) {
    return interpretWorkAuthQuestion(t, pack);
  }

  // "Do you have N+ years of …?" — total tenure answers only a GENERIC
  // question. "5 years of Rust" asks about Rust, and total years say nothing
  // about Rust (audit 2026-09-30: seven total years answered Yes).
  const yrs = t.match(/(\d{1,2})\s*\+?\s*(?:or more\s*)?(?:years?|yrs)/);
  if (yrs && /experience|working|hands.?on|worked/.test(t)) {
    const need = Number(yrs[1]);
    const have = Number(pack.years_experience || 0);
    if (!yearsQuestionIsGeneric(t)) {
      // "3+ years of software engineering": the field the user's own job
      // titles name — their total years answer it.
      if (subjectMatchesTitles(t, pack)) return have ? have >= need : null;
      // A named skill: the résumé's time with it — dated months first, else
      // the length of the jobs it was used in. Not in the résumé = No (the
      // user could not truthfully say Yes either). Owner's rule, 2026-09-30.
      const months = skillMonthsFor(t, pack);
      if (months === null) return null;      // not a skill-shaped question: leave it
      return months >= need * 12;
    }
    if (!have) return null;
    return have >= need;
  }

  // "Do you hold a Bachelor's degree or higher?" — the LEVEL from the profile,
  // and the SUBJECT too when the question names one ("… in computer science"
  // is not answered by a Bachelor of Arts).
  if (/\b(bachelor|master|phd|doctorate|associate|degree|b\.?s\.?|m\.?s\.?)\b/.test(t) && /degree|bachelor|master|phd|doctorate|associate/.test(t)) {
    const RANK = { associate: 1, bachelor: 2, master: 3, mba: 3, phd: 4, doctor: 4 };
    const rankOf = (x) => {
      const l = String(x || '').toLowerCase();
      let best = 0;
      for (const [k, v] of Object.entries(RANK)) if (l.includes(k)) best = Math.max(best, v);
      // "B.S." / "M.S." / "M.Eng" abbreviations.
      if (/\bb\.?\s?(s|a|e|tech)\b/.test(l)) best = Math.max(best, 2);
      if (/\bm\.?\s?(s|a|eng|tech)\b/.test(l)) best = Math.max(best, 3);
      return best;
    };
    // Degree names from the history, plus fields of study the USER's profile
    // states (degree_fields). The résumé extractor's field_of_study is not
    // used: its prompt INFERS a field when the résumé names none.
    const degrees = [pack.degree].concat(
      Array.isArray(pack.education) ? pack.education.map((e) => e && e.degree) : [],
      Array.isArray(pack.degree_fields) ? pack.degree_fields : []);
    const have = Math.max(0, ...degrees.map(rankOf));
    const asked = rankOf(t);
    if (!have || !asked) return null;
    if (/\bnot\b|n't\b/.test(t)) return null;                 // negated wording: leave it
    const subject = degreeSubjectAsked(t);
    if (subject) {
      const held = degrees.map((d) => deaccent(String(d || '')).toLowerCase()).join(' | ');
      const words = subject.split(/\s+/).filter((w) => w.length > 2);
      const alternatives = subject.split(/\s+or\s+|\s*,\s*|\s*\/\s*/).map((x) => x.trim()).filter(Boolean);
      const anyAlt = alternatives.some((alt) => alt.split(/\s+/).filter((w) => w.length > 2)
        .every((w) => held.includes(w)));
      if (!words.length || !anyAlt) return null;              // subject unproven: leave for review
    }
    // "or higher" / "or above" is the usual phrasing; treat a bare mention the
    // same way, since these questions are always a minimum bar.
    return have >= asked ? true : null;   // below the bar: the user decides, never an auto "No"
  }

  // "Do you have experience with X?" — only YES, and only when EVERY skill the
  // question joins with "and" (or ANY joined with "or") is a listed skill.
  // "Python and Kubernetes" with only Python listed stays for the user.
  const trig = t.match(/(experience (with|in|using)|experience using|proficien\w* (in|with)|familiar with|worked with|comfortable with|skilled (in|with)|knowledge of)\s+(.+)$/);
  if (trig) {
    if (/\b(not|never|no)\b|n't\b/.test(t.slice(0, trig.index))) return null;
    const skills = String(pack.key_skills || '').toLowerCase();
    if (!skills) return null;
    const terms = skills.split(/[,;|/]/).map((x) => x.trim()).filter((x) => x.length > 1);
    const wordIn = (needle, hay) => {
      const esc = needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      return new RegExp(`(^|[^a-z0-9])${esc}([^a-z0-9]|$)`, 'i').test(hay);
    };
    // The segment names a listed skill ("…with Python?"), or IS a distinctive
    // part of one ("Kafka" for a listed "Apache Kafka", "React" for "React.js").
    const has = (seg) => {
      const core = seg.replace(/[^a-z0-9#+.\s-]/g, ' ').replace(/\s+/g, ' ').trim();
      return terms.some((term) => wordIn(term, seg) ||
        (core.length >= 3 && !/\s/.test(core) && wordIn(core, term.replace(/\.js\b/, ' js'))) ||
        (core.length >= 3 && !/\s/.test(core) && term.replace(/\.js$/, '') === core));
    };
    const object = trig[trig.length - 1].replace(/[?.!]+\s*$/, '').trim();
    const isOr = /\s(or|either)\s/.test(object) && !/\sand\s/.test(object);
    const parts = object.split(/\s*,\s*|\s+and\s+|\s+or\s+|\s*&\s*|\s*\/\s*/).map((x) => x.trim()).filter(Boolean);
    if (!parts.length) return null;
    const hits = parts.map(has);
    // Not in the résumé = No (owner's rule, 2026-09-30) — but only for
    // skill-shaped answers; a long phrase is a description we cannot look up.
    const skillShaped = parts.every((x) => x.split(/\s+/).length <= 3);
    if (isOr) return hits.some(Boolean) ? true : (skillShaped ? false : null);
    return hits.every(Boolean) ? true : (skillShaped ? false : null);
  }
  return null;
}

/**
 * Dated months for the skill a years-question names, or null when the question
 * names something the evidence does not cover. Every skill word left in the
 * question must be matched: "Python and Kubernetes" needs both.
 */
function skillMonthsFor(t, pack) {
  const rest = String(t).toLowerCase()
    .replace(/\d+/g, ' ').replace(/[^a-z0-9#+./\s-]/g, ' ').replace(/[.?]+(\s|$)/g, ' ')
    .replace(_GENERIC_YEARS_WORDS, ' ').replace(/\s+/g, ' ').trim();
  if (!rest) return null;
  const parts = rest.split(/\s+(?:and|&)\s+|\s*,\s*|\s*\/\s*/).map((x) => x.trim()).filter(Boolean);
  // A long phrase is a description ("a fast paced startup environment"), not a
  // skill we can look up — never answer it No.
  if (parts.some((x) => x.split(/\s+/).length > 3)) return null;
  const dated = (pack && typeof pack.skill_months === 'object' && pack.skill_months) || {};
  const role = (pack && typeof pack.skill_role_months === 'object' && pack.skill_role_months) || {};
  const matches = (skill, part) => {
    const k = String(skill).toLowerCase().replace(/\.js$/, '');
    const esc = k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`(^|[^a-z0-9])${esc}([^a-z0-9]|$)`).test(part) ||
      (part.length >= 3 && !/\s/.test(part) && new RegExp(`(^|[^a-z0-9])${part.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^a-z0-9]|$)`).test(k));
  };
  let least = null;
  for (const part of parts) {
    const monthsOf = (map) => {
      const hit = Object.entries(map).find(([skill]) => matches(skill, part));
      return hit ? Number(hit[1]) || 0 : 0;
    };
    const m = monthsOf(dated) || monthsOf(role);
    least = least === null ? m : Math.min(least, m);
  }
  return least;
}

/** Does a years-question's subject name the field of the user's own job titles? */
function subjectMatchesTitles(t, pack) {
  const titles = [pack.current_title].concat(
    Array.isArray(pack.work_experience) ? pack.work_experience.map((w) => w && w.title) : [])
    .filter(Boolean).join(' | ').toLowerCase();
  if (!titles) return false;
  const words = String(t).toLowerCase().replace(/\d+/g, ' ').replace(/[^a-z\s]/g, ' ')
    .replace(_GENERIC_YEARS_WORDS, ' ').split(/\s+/).filter((w) => w.length > 2);
  if (!words.length || words.length > 3) return false;
  const stem = (w) => w.replace(/(ing|ment|ers|er|s)$/, '');
  return words.every((w) => titles.includes(stem(w)) || titles.includes(w));
}

// Words that describe tenure, not a subject: what is left of a years question
// once these are removed IS its subject.
const _GENERIC_YEARS_WORDS = /\b(do|does|you|your|have|has|had|at|least|a|an|the|minimum|of|in|with|total|overall|professional|relevant|related|work|working|worked|industry|full[- ]?time|paid|hands[- ]?on|post[- ]?graduate|combined|experience|experienced|years?|yrs?|more|or|than|plus|over|how|many|much|role|roles|position|positions|field|this|similar|job|jobs|career)\b/g;
function yearsQuestionIsGeneric(t) {
  // Every non-alphanumeric goes: a required-field "*" left over from the label
  // made "5 years of relevant work experience? *" look like a named skill.
  const rest = String(t).toLowerCase()
    .replace(/\d+/g, ' ').replace(/[^a-z\s]/g, ' ')
    .replace(_GENERIC_YEARS_WORDS, ' ').replace(/\s+/g, ' ').trim();
  return rest === '';
}

/** The field of study a degree question names ("computer science"), or "". */
function degreeSubjectAsked(t) {
  const m = String(t).toLowerCase().match(
    /(?:degree|bachelor'?s?|master'?s?|ph\.?d\.?|doctorate|associate'?s?)\s+(?:degree\s+)?(?:in|of)\s+([a-z0-9 ,/&-]+?)(?:\s+(?:or (?:a )?(?:related|equivalent|similar|higher|above)|or equivalent|from|with|and\b)|[?.,;]|$)/);
  if (!m) return '';
  let subj = m[1].replace(/\b(a|an|the|any)\b/g, ' ').replace(/\s+/g, ' ').trim();
  if (/^(field|discipline|subject|major|area)s?$/.test(subj)) return '';   // "any field"
  return subj;
}

// ── Work authorization & sponsorship: ONE interpreter ────────────────────────
// Audit 2026-09-30 found three different rule sets: "UK Citizen" answered Yes
// to US authorization, a combined "authorized without sponsorship" radio said
// Yes for a profile marked "Not authorized", and "Can you work without visa
// sponsorship?" answered No for requires_sponsorship=false. Every control type
// (radio, select, text) now asks this one function. It answers ONLY what the
// profile states for the country the question asks about; anything else is
// null = left for the applicant.
const _COUNTRY_WORDS = [
  ['united states', /\b(united states|u\.?s\.?a?\.?|usa|america|american)\b/],
  ['canada', /\b(canada|canadian)\b/],
  ['united kingdom', /\b(united kingdom|u\.?k\.?|britain|british|england)\b/],
  ['india', /\b(india|indian)\b/],
  ['australia', /\b(australia|australian)\b/],
  ['germany', /\b(germany|german)\b/],
  ['ireland', /\b(ireland|irish)\b/],
  ['mexico', /\b(mexico|mexican)\b/],
];
function _countryIn(text) {
  const l = ' ' + String(text || '').toLowerCase() + ' ';
  for (const [name, re] of _COUNTRY_WORDS) if (re.test(l)) return name;
  return '';
}
function _normCountry(c) {
  const l = String(c || '').toLowerCase().trim();
  if (!l) return '';
  return _countryIn(l) || l;
}

/**
 * {authorized: true|false|null, country} from the profile's own status. A US
 * immigration status is US authorization; "<X> citizen" is authorization in X
 * only; a bare "Citizen"/"Green Card" (the dashboard's short options) is read
 * in the country the user searches (preferred_country, the US by default).
 */
function workAuthFacts(pack) {
  const wa = [pack.work_authorization, pack.work_auth_status, pack.visa_status]
    .map((x) => String(x || '').trim()).filter(Boolean).join(' | ');
  const home = _normCountry(pack.preferred_country) || 'united states';
  // The server's verdict on the status AND its end date wins over the status
  // text: "F-1 OPT" with an EAD date that has passed is not "authorized" —
  // null there means the applicant answers (older servers omit the key).
  if (Object.prototype.hasOwnProperty.call(pack, 'authorized_now')) {
    if (pack.authorized_now === null) return { authorized: null, country: home };
    if (pack.authorized_now === false) return { authorized: false, country: home };
  }
  if (!wa) return { authorized: null, country: home };
  const l = wa.toLowerCase();
  if (/not\s+(currently\s+)?authoriz|unauthoriz|^no\b|\bno work (permit|authoriz)/.test(l)) {
    return { authorized: false, country: home };
  }
  if (/need(s|ing)?\s+(visa\s+)?sponsor|require(s|d)?\s+(visa\s+)?sponsor/.test(l)) {
    return { authorized: null, country: home };       // depends on the employer
  }
  const named = _countryIn(l.replace(/\b(h-?1b|opt|cpt|ead|tn|l-?1)\b/g, ' '));
  if (/citizen|national|passport/.test(l) && named) return { authorized: true, country: named };
  if (/green\s*card|permanent resident|\blpr\b|h-?1b|\bopt\b|\bcpt\b|stem opt|\bead\b|\btn\b|l-?1|h-?4|asylee|refugee/.test(l)) {
    return { authorized: true, country: 'united states' };
  }
  if (/citizen|authoriz|permanent/.test(l)) return { authorized: true, country: home };
  return { authorized: null, country: home };
}

/** true = Yes, false = No, null = leave for the applicant. */
function interpretWorkAuthQuestion(q, pack) {
  const t = ' ' + String(q || '').toLowerCase().replace(/\s+/g, ' ').trim() + ' ';
  const asksSponsor = /sponsor/.test(t);
  const asksAuth = /authoriz|eligible to work|right to work|legally (able|permitted|allowed) to work|work permit|permitted to work/.test(t);
  // "without sponsorship", "not require sponsorship", "no sponsorship needed"
  // "…without the need for visa sponsorship…" is the same question as
  // "…without sponsorship?": a Lever form answered Yes for a profile that needs
  // sponsorship because only the short wording was known.
  const withoutSponsor = /\b(without|w\/o)\b[^.?!]{0,40}?\bsponsor|\b(not|never)\s+(?:[a-z-]+\s+){0,6}?(requir|need)\w*\s+(?:[a-z-]+\s+){0,3}?sponsor|\bno\s+(?:[a-z-]+\s+){0,3}?sponsor/.test(t);
  const sponsorKnown = typeof pack.requires_sponsorship === 'boolean';
  const requires = pack.requires_sponsorship === true;
  const facts = workAuthFacts(pack);
  const qCountry = _countryIn(t);
  // A question about another country than the one the status covers: unknown.
  const authorized = (qCountry && facts.country && qCountry !== facts.country)
    ? null : facts.authorized;

  if (withoutSponsor && (asksAuth || asksSponsor)) {
    // Combined: "authorized to work WITHOUT sponsorship?" — the applicant
    // decides (owner's rule, 2026-09-30), except the one case with nothing to
    // decide: authorized and never needing sponsorship (citizen, green card).
    if (authorized === true && sponsorKnown && !requires) return true;
    return null;
  }
  if (asksSponsor) {
    if (!sponsorKnown) return null;
    return requires;                                // "will you require sponsorship?"
  }
  if (asksAuth) return authorized;
  return null;
}

/** Text of the question a radio group belongs to. */
function radioGroupQuestion(el) {
  const fs = el.closest('fieldset');
  const legend = fs && fs.querySelector('legend');
  if (legend && legend.textContent.trim()) return legend.textContent.trim();
  const labelledby = el.getAttribute('aria-labelledby');
  if (labelledby) {
    const src = document.getElementById(labelledby);
    if (src && src.textContent.trim()) return src.textContent.trim();
  }
  const group = el.closest('[role="radiogroup"], .form-group, .field, div');
  if (group) {
    // The question is the group's text minus the option captions.
    const optionText = Array.from(group.querySelectorAll('label')).map((l) => l.textContent.trim());
    let text = (group.textContent || '').trim();
    optionText.forEach((o) => { if (o && o.length < 25) text = text.replace(o, ' '); });
    return text.replace(/\s+/g, ' ').trim().slice(0, 300);
  }
  return '';
}

/** Answer Yes/No screening radios from profile data. Returns count answered. */
function answerScreeningRadios(pack) {
  const radios = queryAllDeep('input[type="radio"]');
  const byGroup = new Map();
  for (const r of radios) {
    const key = r.name || (r.closest('fieldset, [role="radiogroup"]') || {}).id || '';
    if (!key) continue;
    if (!byGroup.has(key)) byGroup.set(key, []);
    byGroup.get(key).push(r);
  }

  let answered = 0;
  for (const [, group] of byGroup) {
    if (group.some((r) => r.checked)) continue;              // already answered
    if (group.some((r) => r.dataset.spotapplyUserModified === 'true')) continue;
    const question = radioGroupQuestion(group[0]);
    const want = classifyScreeningQuestion(question, pack);
    if (want === null) continue;

    const optionLabel = (r) => {
      const lbl = (r.id && document.querySelector(`label[for="${CSS.escape(r.id)}"]`)) || r.closest('label');
      return ((lbl && lbl.textContent) || r.value || '').trim().toLowerCase();
    };
    const target = group.find((r) => {
      const cap = optionLabel(r);
      return want ? /^\s*yes\b/.test(cap) || cap === 'true' : /^\s*no\b/.test(cap) || cap === 'false';
    });
    if (!target) continue;

    try {
      target.click();          // click, not .checked — frameworks listen for it
      if (!target.checked) {
        target.checked = true;
        target.dispatchEvent(new Event('change', { bubbles: true }));
      }
      if (target.checked) {
        target.dataset.spotapplyFilled = 'true';
        answered++;
        console.log('[SpotApply] Screening answered:', want ? 'Yes' : 'No', '—',
                    question.slice(0, 70));
      }
    } catch (e) {
      console.debug('[SpotApply] radio click failed:', e.message);
    }
  }
  if (answered) console.log(`[SpotApply] Answered ${answered} screening question(s) from your profile`);
  return answered;
}

// ── Yes/No BUTTON pairs (Ashby) ──────────────────────────────────────────────
// Ashby renders a boolean question as two <button type="button">s, "Yes" and
// "No", under the question's label: no radio, no select. Nothing matched them,
// so on the live test (2026-10-09) both required work-authorization questions
// stayed blank AND were missing from the "need you" count. The answer comes
// from the same interpreter as every other control (classifyScreeningQuestion
// -> interpretWorkAuthQuestion); anything it cannot prove stays for the user.
function _btnText(b) {
  return String((b && (b.textContent || (b.getAttribute && b.getAttribute('aria-label')))) || '')
    .replace(/\s+/g, ' ').trim();
}

/** Every rendered Yes/No button pair: {box, yes, no, question, label, entry}. */
function yesNoButtonGroups(root) {
  const groups = [];
  const seen = new Set();
  for (const yes of queryAllDeep('button', root || document)) {
    if (!/^yes$/i.test(_btnText(yes))) continue;
    const host = yes.getRootNode && yes.getRootNode().host;
    if (host && host.id === 'hp-copilot-overlay') continue;          // our own UI
    const box = yes.parentElement;
    if (!box || seen.has(box)) continue;
    const buttons = Array.from(box.children).filter((c) => c.tagName === 'BUTTON');
    if (buttons.length !== 2) continue;
    const no = buttons.find((b) => /^no$/i.test(_btnText(b)));
    if (!no) continue;
    // Never press anything that would submit the form.
    if ([yes, no].some((b) => String(b.type || '').toLowerCase() === 'submit' && b.form)) continue;
    seen.add(box);
    const q = yesNoQuestion(box);
    groups.push({ box, yes, no, question: q.text, label: q.label, entry: q.entry });
  }
  return groups;
}

/** The question a Yes/No pair answers: its field's label, else the field's text. */
function yesNoQuestion(box) {
  const clean = (t) => String(t || '').replace(/\s+/g, ' ').trim().slice(0, 300);
  const by = box.getAttribute && box.getAttribute('aria-labelledby');
  if (by) {
    const n = document.getElementById(by.split(/\s+/)[0]);
    if (n && clean(n.textContent)) return { text: clean(n.textContent), label: n, entry: box.parentElement };
  }
  let node = box.parentElement;
  for (let i = 0; node && i < 4; i++, node = node.parentElement) {
    // Stop before a container that holds ANOTHER question: its label is not ours.
    const otherPair = Array.from(node.querySelectorAll('button'))
      .some((b) => !box.contains(b) && /^(yes|no)$/i.test(_btnText(b)));
    const otherField = node.querySelector('input:not([type="hidden"]):not([type="radio"]):not([type="checkbox"]), textarea, select');
    if (otherPair || otherField) break;
    const label = Array.from(node.querySelectorAll('label, legend, [class*="question-title" i], [role="heading"]'))
      .find((l) => !box.contains(l) && !l.contains(box) && clean(l.textContent));
    if (label) return { text: clean(label.textContent), label, entry: node };
    const text = clean(String(node.textContent || '').replace(box.textContent || '', ' '));
    if (text.length >= 5) return { text, label: null, entry: node };
  }
  return { text: '', label: null, entry: box.parentElement };
}

function _btnOn(b) {
  if (!b || !b.getAttribute) return false;
  for (const a of ['aria-pressed', 'aria-checked', 'aria-selected']) {
    if (b.getAttribute(a) === 'true') return true;
  }
  if (/^(on|checked|active|selected|true)$/i.test(b.getAttribute('data-state') || '')) return true;
  return /(^|[\s_-])(active|selected|checked|pressed|chosen)([\s_-]|$)/i.test(String(b.getAttribute('class') || ''));
}

/** 'yes' | 'no' | null — what the pair holds now, by the page's own state first. */
function yesNoChoice(g) {
  const y = _btnOn(g.yes), n = _btnOn(g.no);
  if (y && !n) return 'yes';
  if (n && !y) return 'no';
  return (g.box.dataset && (g.box.dataset.spotapplyUserChoice || g.box.dataset.spotapplyChoice)) || null;
}

function yesNoRequired(g) {
  if (g.box.getAttribute && g.box.getAttribute('aria-required') === 'true') return true;
  if (g.label && labelMarksRequired(g.label)) return true;
  try {
    if (g.entry && g.entry.querySelector('input[required], input[aria-required="true"]')) return true;
  } catch (_) {}
  return /\*/.test(g.question || '');
}

/** Click Yes/No where the profile proves the answer. Returns how many. */
function answerYesNoButtons(pack) {
  let answered = 0;
  for (const g of yesNoButtonGroups(document)) {
    if (!g.box.getClientRects().length) continue;                 // not rendered
    if (yesNoChoice(g)) continue;                                   // already answered, by anyone
    if (g.box.dataset.spotapplyUserModified === 'true') continue;
    const q = g.question;
    if (!q || isDemographicQuestion(q)) continue;
    const want = classifyScreeningQuestion(q, pack);
    if (want === null) continue;                                    // not proven: the applicant answers
    const target = want ? g.yes : g.no;
    if (target.disabled) continue;
    try {
      target.click();      // a click, not a class flip: the app's own handler records it
      g.box.dataset.spotapplyChoice = want ? 'yes' : 'no';
      g.box.dataset.spotapplyFilled = 'true';
      answered++;
      console.log('[SpotApply] Yes/No answered:', want ? 'Yes' : 'No', '-', q.slice(0, 70));
    } catch (e) {
      console.debug('[SpotApply] yes/no click failed:', e.message);
    }
  }
  if (answered) console.log(`[SpotApply] Answered ${answered} Yes/No question(s) from your profile`);
  return answered;
}

// A Yes/No the USER pressed is theirs: never re-answered, always counted.
document.addEventListener('click', (e) => {
  if (!e.isTrusted || !hpCopilotSurface()) return;
  const b = e.target && e.target.closest && e.target.closest('button');
  const t = _btnText(b);
  if (!b || !/^(yes|no)$/i.test(t) || !b.parentElement) return;
  b.parentElement.dataset.spotapplyUserModified = 'true';
  b.parentElement.dataset.spotapplyUserChoice = t.toLowerCase();
}, { capture: true, passive: true });

// ── "Required", however the form marks it ────────────────────────────────────
// Ashby draws the asterisk with CSS (label::after { content: "*" }) and tags
// the label with a `_required_…` class, so the text says "Location" while the
// page shows "Location*". Reading only the text left required fields yellow
// (optional) and out of the required count.
function labelMarksRequired(lbl) {
  if (!lbl) return false;
  const t = String(lbl.textContent || '');
  if (t.includes('*') || /\(required\)|\brequired\b/i.test(t)) return true;
  const cls = String((lbl.getAttribute && lbl.getAttribute('class')) || '');
  if (/(^|[\s_-])required([\s_-]|$)/i.test(cls)) return true;
  try {
    if (lbl.querySelector && lbl.querySelector('abbr[title*="required" i], [aria-label="required" i]')) return true;
  } catch (_) {}
  try {
    const win = (lbl.ownerDocument && lbl.ownerDocument.defaultView) || window;
    for (const pseudo of ['::after', '::before']) {
      if (String(win.getComputedStyle(lbl, pseudo).content || '').includes('*')) return true;
    }
  } catch (_) {}
  return false;
}

/** The label elements that name a field (for a radio: its GROUP's question). */
function fieldLabelElements(el) {
  const out = [];
  try { if (el.labels) out.push(...Array.from(el.labels)); } catch (_) {}
  try {
    const doc = (el.getRootNode && el.getRootNode()) || document;
    if (el.id && doc.querySelector) {
      const l = doc.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (l) out.push(l);
    }
  } catch (_) {}
  const by = el.getAttribute && el.getAttribute('aria-labelledby');
  if (by) by.split(/\s+/).forEach((id) => { const n = id && document.getElementById(id); if (n) out.push(n); });
  if (el.type === 'radio' || el.type === 'checkbox') {
    const fs = el.closest && el.closest('fieldset');
    const lg = fs && fs.querySelector('legend');
    if (lg) out.push(lg);
    // The field's own question label: not an option caption (those wrap or
    // point at a radio/checkbox).
    let node = el.parentElement;
    for (let i = 0; node && i < 4; i++, node = node.parentElement) {
      // Never climb into a container that holds another question's inputs.
      const foreign = Array.from(node.querySelectorAll('input, textarea, select'))
        .some((o) => o !== el && !((o.type === 'radio' || o.type === 'checkbox') && o.name && o.name === el.name)
                     && o.type !== 'hidden');
      if (foreign) break;
      const q = Array.from(node.querySelectorAll('label, legend, [class*="question-title" i]')).find((l) =>
        !l.contains(el) && !l.querySelector('input[type="radio"], input[type="checkbox"]') &&
        !(l.htmlFor && (() => { try { const t = document.getElementById(l.htmlFor); return t && /radio|checkbox/.test(t.type); } catch (_) { return false; } })()));
      if (q) { out.push(q); break; }
    }
  }
  return out;
}

// ── Location autocomplete (Ashby and friends) ────────────────────────────────
// A location "combobox" commits only a SUGGESTION the user picks. Typing
// "Cincinnati, OH" into it left an uncommitted string the form discarded on
// blur, so the required Location stayed empty (live test, 2026-10-09). Type the
// city, wait for the suggestions, pick the one that matches the profile.
function isAutocompleteInput(el) {
  if (!el || el.tagName !== 'INPUT') return false;
  const role = (el.getAttribute('role') || '').toLowerCase();
  const ac = (el.getAttribute('aria-autocomplete') || '').toLowerCase();
  const pop = (el.getAttribute('aria-haspopup') || '').toLowerCase();
  if (role === 'combobox' || ac === 'list' || ac === 'both' || pop === 'listbox') return true;
  // Unannotated search-as-you-type boxes still say so: aria-expanded, or a
  // "Start typing..." placeholder with the browser's own autofill turned off.
  if (el.hasAttribute('aria-expanded')) return true;
  return /start typing|type to search|search for a (?:city|location)/i.test(el.getAttribute('placeholder') || '') &&
    /^(off|new-password|nope)$/i.test(el.getAttribute('autocomplete') || 'off');
}

/** Write text the way typing does, WITHOUT a blur (blur closes the suggestions). */
function _typeNoBlur(el, value) {
  try {
    const win = (el.ownerDocument && el.ownerDocument.defaultView) || window;
    const d = Object.getOwnPropertyDescriptor(win.HTMLInputElement.prototype, 'value');
    if (d && d.set) d.set.call(el, value); else el.value = value;
  } catch (_) { try { el.value = value; } catch (__) {} }
  try {
    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
  } catch (_) {
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }
}

function _suggestionsFor(el) {
  const ids = [el.getAttribute('aria-controls'), el.getAttribute('aria-owns')]
    .filter(Boolean).join(' ').split(/\s+/).filter(Boolean);
  const lists = ids.map((id) => document.getElementById(id)).filter(Boolean);
  const opts = lists.length
    ? lists.flatMap((l) => Array.from(l.querySelectorAll('[role="option"]')))
    : queryAllDeep('[role="option"]');
  return opts.filter((o) => o.getClientRects().length &&
    !(o.getRootNode && o.getRootNode().host && o.getRootNode().host.id === 'hp-copilot-overlay'));
}

/**
 * The suggestion that IS the profile's place, or null when it is not certain.
 *
 * The region is compared COMPONENT BY COMPONENT ("London, Ontario, Canada" is
 * London | Ontario | Canada), never as a substring: "on" is inside "London"
 * and "Toronto", and "Virginia" inside "West Virginia" (review 2026-10-09: a
 * substring test committed London, England for "London, ON"). A 2-letter code
 * matches only as its own, case-sensitive component.
 */
function pickLocationSuggestion(options, pack) {
  const loc = parseLocation(pack && pack.location);
  const norm = (s) => deaccent(String(s || '')).toLowerCase().replace(/\s+/g, ' ').trim();
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const city = norm(loc.city);
  if (!city) return null;
  const cityRe = new RegExp('(^|[^a-z])' + esc(city) + '([^a-z]|$)');
  // A suggestion's comma components, ZIP codes dropped ("OH 45202" is OH).
  const parts = (o) => String((o && o.textContent) || '').split(',')
    .map((p) => p.replace(/\b\d{5}(?:-\d{4})?\b/g, '').replace(/\s+/g, ' ').trim()).filter(Boolean);
  let hits = (options || []).filter((o) => cityRe.test(norm(o.textContent)));
  // "Columbus" is not "Columbus Grove": a suggestion naming the city exactly wins.
  // The CITY slot only: "New York Mills, New York" names the STATE New York, so
  // reading any component made every place in that state an exact hit and the
  // pick came back empty for "New York, NY" (review 2026-10-09).
  const exact = hits.filter((o) => norm(parts(o)[0] || '') === city);
  if (exact.length) hits = exact;
  if (!hits.length) return null;

  // The profile's region as a code and a name ("OH" / "ohio", either written);
  // a country in that slot ("London, UK") is the country, not a region.
  const regions = Object.assign({}, US_STATES, CA_PROVINCES);
  const isRegionCode = (k) => !!k && Object.prototype.hasOwnProperty.call(regions, k);
  const regionNames = new Set(Object.keys(regions).map((k) => norm(regions[k])));
  let code = isRegionCode(loc.abbr) ? loc.abbr : '';
  let regionName = code ? norm(regions[code]) : norm(loc.state);
  if (!code && regionNames.has(regionName)) {
    code = Object.keys(regions).find((k) => norm(regions[k]) === regionName) || '';
  }
  const slotCountry = code ? '' : _countryIn(loc.state);
  if (slotCountry) regionName = '';
  const country = _normCountry(residenceCountry(pack)) || slotCountry ||
    (US_STATES[code] ? 'united states' : (CA_PROVINCES[code] ? 'canada' : ''));
  // The components that can name a country: a US state or Canadian province is
  // a region, never a country ("New Mexico" is not Mexico).
  const countryParts = (o) => parts(o).slice(1)
    .filter((p) => !(isRegionCode(p) || regionNames.has(norm(p))));
  // A suggestion that names a country we know, other than the profile's.
  const otherCountry = (o) => {
    const theirs = countryParts(o).map(_countryIn).find(Boolean) || '';
    return !!(theirs && country && theirs !== country);
  };

  if (code || regionName) {
    const isRegion = (p) => (code && p === code) || (!!regionName && norm(p) === regionName);
    const inRegion = hits.filter((o) => parts(o).slice(1).some(isRegion));
    if (inRegion.length) return inRegion.length === 1 ? inRegion[0] : null;   // still two: the user picks
    // No suggestion names the profile's region. A lone one is the place only
    // when it names no OTHER state or province and no other country.
    if (hits.length !== 1) return null;
    if (parts(hits[0]).slice(1).some((p) => isRegionCode(p) || regionNames.has(norm(p)))) return null;
    return otherCountry(hits[0]) ? null : hits[0];
  }
  if (hits.length === 1) return otherCountry(hits[0]) ? null : hits[0];
  const inCountry = country
    ? hits.filter((o) => countryParts(o).some((p) => _normCountry(p) === country)) : [];
  return inCountry.length === 1 ? inCountry[0] : null;   // two Springfields: the user picks
}

/** Type the profile's city into a location autocomplete and pick its suggestion. */
async function fillLocationCombobox(el, pack) {
  _lastWriteSkippedEmpty = false;
  if (!el || !canFillField(el) || el.dataset.spotapplyUserModified === 'true') return false;
  const loc = parseLocation(pack && pack.location);
  if (!loc.city) { _lastWriteSkippedEmpty = true; return false; }
  try { el.focus(); } catch (_) {}
  _typeNoBlur(el, loc.city);
  let pick = null;
  let lastCount = -1;
  const deadline = Date.now() + 6000;
  while (Date.now() < deadline) {
    await delay(300);
    const opts = _suggestionsFor(el);
    // Wait for the list to settle (a debounced search fills it in steps).
    if (opts.length && opts.length === lastCount) { pick = pickLocationSuggestion(opts, pack); break; }
    lastCount = opts.length;
  }
  if (!pick) {
    // Never leave typed-but-uncommitted text behind: the form discards it, and
    // it looks filled to the user.
    _typeNoBlur(el, '');
    try { el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); } catch (_) {}
    console.log('[SpotApply] Location suggestions did not include your city, left for you');
    return false;
  }
  for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup']) {
    try {
      const Ctor = type.startsWith('pointer') && typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
      pick.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, view: window }));
    } catch (_) {}
  }
  try { pick.click(); } catch (_) {}
  await delay(300);
  const ok = deaccent(String(el.value || '')).toLowerCase().includes(deaccent(loc.city).toLowerCase());
  if (ok) {
    try {
      el.dataset.spotapplyFilled = 'true';
      el.dataset.spotapplyLastWrite = String(el.value || '');
    } catch (_) {}
    console.log('[SpotApply] Location picked from suggestions:', String(el.value || '').slice(0, 60));
  }
  return ok;
}

// ── "How did you hear about this opportunity?" ───────────────────────────────
// Owner's rule (2026-10-09): answered ONLY from the answer the user saved in
// their profile (UserProfile.how_heard_answer, sent as pack.how_heard_answer).
// Never from a remembered answer, never by the AI (the server refuses it as a
// fact only the applicant holds), never guessed. Nothing saved = the applicant
// answers it, and it is counted with the fields that need them.
// Keep the pattern IDENTICAL to app/autofill/field_guards.py _HEAR_ABOUT_RE.
const _HEAR_ABOUT_RE = /how did you (?:first )?(?:hear|learn|find out|find)|hear about (?:us|this)|(?:referral|lead|candidate|application) source|source of (?:referral|application)|where did you (?:hear|find|see|learn)/i;

function isHowHeardQuestion(text) {
  return _HEAR_ABOUT_RE.test(String(text || '').replace(/\s+/g, ' '));
}

// _HEAR_ABOUT_RE is the REFUSAL list: no model and no memory answers anything
// in it. The saved answer FILLS less (review 2026-10-09): only a question about
// how the applicant came to THIS job, role, position, posting, us or the
// company, or a referral / lead / application source field. "How did you learn
// Python?" and "How did you find your current role?" are in the refusal list
// and stay the applicant's to answer.
// The asking words, as _HEAR_ABOUT_RE has them.
const _HH_ASKED = '(?:how did you (?:first )?(?:learn|find out|find)|where did you (?:find|see|learn))';
const _HOW_HEARD_FILL_RE = new RegExp(
  'how did you (?:first )?hear|where did you hear|hear about (?:us|this)|' +
  '(?:referral|lead|candidate|application) source|source of (?:referral|application)|' +
  _HH_ASKED + ' (?:about |of )?(?:us\\b|(?:this|the|our|that) (?:open |job )?' +
  '(?:jobs?|roles?|positions?|opportunit(?:y|ies)|openings?|postings?|vacanc(?:y|ies)|company|organi[sz]ation)\\b)',
  'i');

/** A company's name without its legal suffix: "Acme, Inc." -> "acme". */
function _companyCore(company) {
  let s = deaccent(String(company || '')).toLowerCase().replace(/\s+/g, ' ').trim();
  for (let prev = ''; prev !== s;) {
    prev = s;
    s = s.replace(/[\s,]+(?:inc|incorporated|llc|ltd|limited|corp|corporation|co|company|plc|gmbh)\.?$/, '').trim();
  }
  s = s.replace(/^the /, '');
  return s.length >= 2 ? s : '';
}

/**
 * Does the saved how-did-you-hear answer answer this question? Never wider
 * than the refusal list. `company` is the job's (pack.company): "How did you
 * first learn about Acme?" asks about this job only on Acme's form.
 */
function isHowHeardFillQuestion(text, company) {
  const t = deaccent(String(text || '')).replace(/\s+/g, ' ');
  if (!isHowHeardQuestion(t)) return false;
  if (_HOW_HEARD_FILL_RE.test(t)) return true;
  const name = _companyCore(company);
  if (!name) return false;
  const esc = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(_HH_ASKED + ' (?:about |of )?(?:the )?' + esc + '(?![a-z0-9])', 'i').test(t);
}

/** The user's saved answer as one line, or "" (= the applicant answers it). */
function howHeardAnswer(pack) {
  return String((pack && pack.how_heard_answer) || '').replace(/\s+/g, ' ').trim();
}

// Other words for the SAME source, never a broader or a narrower one: a saved
// "Job board" must not become "Indeed", which the user never said.
const _HOW_HEARD_SYNONYMS = [
  ['company website', 'company site', 'company web site', 'companys website', 'corporate website',
   'careers page', 'career page', 'careers site', 'career site', 'careers website', 'career website',
   'our website', 'your website'],
  ['job board', 'job boards', 'job site', 'job sites', 'job website', 'job posting site',
   'job posting website', 'job search site', 'job search website', 'job listing site'],
  ['referral', 'referred'],
  ['career fair', 'careers fair', 'job fair', 'hiring event'],
  ['social media', 'social network', 'social networking'],
  ['search engine', 'web search', 'online search', 'internet search'],
];

/** Lowercase words, accents and apostrophes dropped ("Company's" = "companys"). */
function _hhTokens(s) {
  return deaccent(String(s || '')).toLowerCase().replace(/['’]/g, '')
    .replace(/[^a-z0-9]+/g, ' ').trim().split(' ').filter(Boolean);
}

/** Does word list `hay` hold `needle` as a run of whole words? */
function _hhHas(hay, needle) {
  if (!needle.length || needle.length > hay.length) return false;
  for (let i = 0; i + needle.length <= hay.length; i++) {
    if (needle.every((w, j) => hay[i + j] === w)) return true;
  }
  return false;
}

function _hhIsOther(tok) { return tok[0] === 'other'; }

/** "Select...", "Please choose", "--": a list's placeholder, not a choice. */
function _hhIsPlaceholder(text) {
  return /^\s*(?:-+|(?:please\s+)?(?:select|choose)\b.*)?\s*$/i.test(String(text || ''));
}

/**
 * The option (by index into `texts`) that answers the saved how-did-you-hear
 * answer: {index, specify}, or null when nothing fits for certain. In order:
 * the option that IS it; the one containing it or contained in it (whole
 * words); a synonym; else "Other", with the saved text for its "please
 * specify" box. Two candidates at one step are the applicant's choice.
 */
function pickHowHeardOption(texts, saved) {
  const want = _hhTokens(saved);
  if (!want.length) return null;
  const opts = (texts || []).map((t, i) => ({ i, raw: String(t || ''), tok: _hhTokens(t) }))
    .filter((o) => o.tok.length && !_hhIsPlaceholder(o.raw));
  const specifyFor = (o) => {
    if (!_hhIsOther(o.tok)) return '';
    // "Other: a podcast" -> "a podcast"; a plain "Other" has nothing to add.
    const s = String(saved).replace(/\s+/g, ' ').trim();
    const m = s.match(/^other\b\s*[:,-]?\s*(.*)$/i);
    let rest = m ? m[1] : s;
    const p = rest.match(/^\((.*)\)$/);
    if (p) rest = p[1];
    return rest.trim();
  };
  const pick = (o) => ({ index: o.i, specify: specifyFor(o) });
  const exact = opts.filter((o) => o.tok.join(' ') === want.join(' '));
  if (exact.length) return pick(exact[0]);
  const real = opts.filter((o) => !_hhIsOther(o.tok));
  const contains = real.filter((o) => _hhHas(o.tok, want) || _hhHas(want, o.tok));
  if (contains.length) return contains.length === 1 ? pick(contains[0]) : null;
  const families = (tok) => _HOW_HEARD_SYNONYMS
    .map((f, k) => (f.some((ph) => _hhHas(tok, ph.split(' '))) ? k : -1)).filter((k) => k >= 0);
  const mine = families(want);
  if (mine.length) {
    const syn = real.filter((o) => families(o.tok).some((k) => mine.includes(k)));
    if (syn.length) return syn.length === 1 ? pick(syn[0]) : null;
  }
  const other = opts.filter((o) => _hhIsOther(o.tok));
  return other.length ? pick(other[0]) : null;
}

// A box for the "Other" choice says so: "If other, please specify", "Other
// (please specify)", "Specify other", "Other source", or only "Please
// specify" / "Other". A box asking to explain, describe or list something is
// the next question (review 2026-10-09: "Please describe why you want to work
// at Acme" got the saved answer, and memory learned it).
const _SPECIFY_RE = /\bif other\b|\bif you (?:selected|chose|picked|answered) \W?other\b|\bother\b[^a-z0-9]*(?:please )?specify\b|\bspecify (?:the |your )?other\b|\bother source\b|^\W*(?:please )?specify\W*$|^\W*other\W*$/i;

function _saysSpecifyOther(text) {
  return _SPECIFY_RE.test(String(text || '').replace(/\s+/g, ' ').trim());
}

/** A free-text box whose own words name the "Other" choice. */
function _isSpecifyField(c) {
  if (!isTextEntry(c)) return false;
  return [labelText(c), c.getAttribute('placeholder'), c.getAttribute('aria-label')]
    .some((t) => _saysSpecifyOther(t));
}

const _OTHER_BOX_SEL = 'input:not([type="hidden"]):not([type="radio"]):not([type="checkbox"])' +
  ':not([type="file"]):not([type="submit"]):not([type="button"]):not([type="image"]), textarea, select';

/** The fields on screen now. Taken before a pick, to see what the pick revealed. */
function _shownFields() {
  return new Set(queryAllDeep(_OTHER_BOX_SEL).filter(isUserVisible));
}

/**
 * Does `box` sit in the question's own container? The smallest element
 * holding the question's controls (`own`) and the box holds no other field,
 * the box has no label of its own (a label makes it another question), the
 * container holds the question's own caption (its <label>/<legend>), and it
 * holds no other caption or text: every word in it is the question's label or
 * an option's. A section holding the how-heard question and the NEXT question
 * with an unlinked label (a sibling <label> without `for`, a div caption) is
 * not the question's container (review 2026-10-09: that next question got
 * the saved answer after an Other pick).
 */
function _inQuestionContainer(box, own) {
  if ((box.labels && box.labels.length) || box.getAttribute('aria-labelledby') ||
      box.getAttribute('aria-label')) return false;
  let node = own[0] && own[0].parentElement;
  while (node && !(node.contains(box) && own.every((o) => node.contains(o)))) node = node.parentElement;
  if (!node || node === document.body || node === document.documentElement) return false;
  if (!Array.from(node.querySelectorAll('input:not([type="hidden"]), select, textarea'))
    .every((f) => f === box || own.includes(f))) return false;
  const captions = new Set();
  for (const o of own) {
    for (const l of Array.from(o.labels || [])) captions.add(l);
    const fs = o.closest && o.closest('fieldset');
    const lg = fs && fs.querySelector('legend');
    if (lg) captions.add(lg);
  }
  const mine = (n) => {
    for (let p = n.parentElement; p && p !== node.parentElement; p = p.parentElement) {
      if (captions.has(p) || own.includes(p) || p === box) return true;
    }
    return false;
  };
  if (!Array.from(captions).some((c) => node.contains(c))) return false;
  const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
  for (let t = walker.nextNode(); t; t = walker.nextNode()) {
    if (String(t.nodeValue || '').trim() && !mine(t)) return false;
  }
  return true;
}

/**
 * The "please specify" box for an Other pick: the next field after the
 * question, and only when it is tied to that choice. Its own words name
 * Other / specify, it sits in the question's own container, or the pick
 * revealed it (`shownBefore`: the fields on screen before the pick). Any
 * other next field belongs to another question.
 */
function _howHeardSpecifyField(anchor, own, shownBefore) {
  for (const c of queryAllDeep(_OTHER_BOX_SEL)) {
    if (c === anchor) continue;
    let following = false;
    try {
      following = !!(anchor.compareDocumentPosition(c) & Node.DOCUMENT_POSITION_FOLLOWING) && !anchor.contains(c);
    } catch (_) {}
    if (!following) continue;
    if (!isTextEntry(c) || !canFillField(c)) return null;
    const tied = _isSpecifyField(c) || !!(shownBefore && !shownBefore.has(c)) ||
      _inQuestionContainer(c, own);
    return tied ? c : null;
  }
  return null;
}

/**
 * Write the saved answer into the Other choice's box. `own` = the question's
 * controls, `shownBefore` = _shownFields() taken before the pick.
 */
async function fillHowHeardSpecify(anchor, text, own, shownBefore) {
  if (!anchor || !text) return false;
  await delay(400);                       // an "If other" box often appears only now
  const box = _howHeardSpecifyField(anchor, own || [anchor], shownBefore);
  if (!box || String(box.value || '').trim() || box.dataset.spotapplyUserModified === 'true') return false;
  // Part of the how-heard answer: never learned, whatever is typed in it later.
  try { box.dataset.spotapplyHowHeard = 'true'; } catch (_) {}
  return fillInput(box, text);
}

/**
 * A select already holding a real choice (the page's, the user's or ours).
 * The first option shown only because nothing is selected is not a choice.
 */
function _selectHasChoice(el) {
  const o = el.options && el.options[el.selectedIndex];
  if (!o || o.value === '' || _hhIsPlaceholder(o.text)) return false;
  return !(el.selectedIndex === 0 && !o.defaultSelected);
}

/**
 * Answer one how-did-you-hear FIELD (a select, a combobox / dropdown button,
 * or a text box) from the saved answer. true = something was written.
 */
async function answerHowHeardField(el, pack) {
  const saved = howHeardAnswer(pack);
  _lastWriteSkippedEmpty = false;
  if (!saved) { _lastWriteSkippedEmpty = true; return false; }   // the applicant answers it
  if (!el || !canFillField(el) || (el.dataset && el.dataset.spotapplyUserModified === 'true')) return false;
  if (el.tagName === 'SELECT') {
    if (_selectHasChoice(el)) return false;              // chosen already, by anyone
    const opts = Array.from(el.options || []);
    const pick = pickHowHeardOption(opts.map((o) => o.text), saved);
    if (!pick) { _lastWriteSkippedEmpty = true; return false; }
    const shown = pick.specify ? _shownFields() : null;
    el.value = opts[pick.index].value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    try { el.dataset.spotapplyFilled = 'true'; } catch (_) {}
    console.log('[SpotApply] How you heard about the job, from your profile:', opts[pick.index].text);
    if (pick.specify) await fillHowHeardSpecify(el, pick.specify, [el], shown);
    return true;
  }
  if (el.tagName === 'BUTTON' || isAutocompleteInput(el)) return fillHowHeardDropdown(el, saved);
  if (isTextEntry(el)) {
    if (String(el.value || '').trim()) return false;
    return fillInput(el, saved);
  }
  return false;
}

/** A combobox or dropdown button: open it, pick the saved answer's option. */
async function fillHowHeardDropdown(el, saved) {
  const isInput = el.tagName === 'INPUT';
  if (isInput && String(el.value || '').trim()) return false;
  const caption = (o) => String(o.textContent || o.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
  // Wait until the list stops changing (a debounced search fills it in steps).
  const settle = async (ms) => {
    let last = -1;
    const end = Date.now() + ms;
    while (Date.now() < end) {
      await delay(250);
      const o = _suggestionsFor(el);
      if (o.length && o.length === last) return o;
      last = o.length;
    }
    return _suggestionsFor(el);
  };
  const press = (target) => {
    for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup']) {
      try {
        const Ctor = type.startsWith('pointer') && typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
        target.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, view: window }));
      } catch (_) {}
    }
    try { target.click(); } catch (_) {}
  };
  try { el.focus(); } catch (_) {}
  press(el);                                    // most lists open on a click, showing every option
  let opts = await settle(1500);
  let typed = false;
  let pick = opts.length ? pickHowHeardOption(opts.map(caption), saved) : null;
  if (!pick && isInput) {
    // A search box lists only what matches the text typed.
    _typeNoBlur(el, saved);
    typed = true;
    opts = await settle(4000);
    pick = opts.length ? pickHowHeardOption(opts.map(caption), saved) : null;
  }
  if (!pick) {
    if (typed) _typeNoBlur(el, '');            // never leave uncommitted text behind
    try { el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); } catch (_) {}
    _lastWriteSkippedEmpty = true;
    console.log('[SpotApply] No option matches your saved "how did you hear" answer, left for you');
    return false;
  }
  const chosen = caption(opts[pick.index]);
  const shown = pick.specify ? _shownFields() : null;
  press(opts[pick.index]);
  await delay(300);
  try { el.dataset.spotapplyFilled = 'true'; } catch (_) {}
  console.log('[SpotApply] How you heard about the job, from your profile:', chosen.slice(0, 60));
  if (pick.specify) await fillHowHeardSpecify(el, pick.specify, [el], shown);
  return true;
}

/** An option's caption: its label (radio) or its own text. */
function _choiceText(o) {
  if (o.tagName === 'INPUT') {
    let lbl = null;
    try { lbl = (o.id && (o.getRootNode() || document).querySelector(`label[for="${CSS.escape(o.id)}"]`)) || o.closest('label'); } catch (_) {}
    return String((lbl && lbl.textContent) || o.getAttribute('aria-label') || o.value || '').replace(/\s+/g, ' ').trim();
  }
  return _btnText(o);
}

function _choiceOn(o) {
  return o.tagName === 'INPUT' ? !!o.checked : _btnOn(o);
}

/** The question a group of choices answers: {text, label}. */
function _choiceQuestion(box) {
  const clean = (t) => String(t || '').replace(/\s+/g, ' ').trim().slice(0, 300);
  const by = box.getAttribute && box.getAttribute('aria-labelledby');
  if (by) {
    const n = document.getElementById(by.split(/\s+/)[0]);
    if (n && clean(n.textContent)) return { text: clean(n.textContent), label: n };
  }
  const al = box.getAttribute && clean(box.getAttribute('aria-label'));
  if (al) return { text: al, label: null };
  for (let i = 0, node = box; node && i < 5; i++, node = node.parentElement) {
    // Never climb into a container that holds another question's fields.
    if (i > 0 && Array.from(node.querySelectorAll('select, textarea, input:not([type="hidden"])'))
      .some((c) => !box.contains(c) && !_isSpecifyField(c))) break;
    if (node.tagName === 'FIELDSET') {
      const lg = Array.from(node.children).find((c) => c.tagName === 'LEGEND');
      if (lg && clean(lg.textContent)) return { text: clean(lg.textContent), label: lg };
    }
    if (i === 0) continue;
    const label = Array.from(node.querySelectorAll('legend, label, [class*="question-title" i], [role="heading"]'))
      .find((l) => !box.contains(l) && !l.contains(box) && clean(l.textContent));
    if (label) return { text: clean(label.textContent), label };
  }
  return { text: '', label: null };
}

/**
 * Every rendered group of choices whose question the saved how-did-you-hear
 * answer answers (isHowHeardFillQuestion; `company` = pack.company): radio
 * groups, and option lists drawn as buttons or ARIA radios/options (Ashby).
 * [{box, options, kind, question, label}]
 */
function howHeardChoiceGroups(root, company) {
  const groups = new Map();
  const add = (box, o, kind) => {
    if (!groups.has(box)) groups.set(box, { box, options: [], kind });
    groups.get(box).options.push(o);
  };
  const byName = new Map();
  for (const r of queryAllDeep('input[type="radio"]', root || document)) {
    if (!r.name) continue;
    if (!byName.has(r.name)) byName.set(r.name, []);
    byName.get(r.name).push(r);
  }
  for (const [, rs] of byName) {
    let box = rs[0].parentElement;
    while (box && !rs.every((r) => box.contains(r))) box = box.parentElement;
    if (box) rs.forEach((r) => add(box, r, 'radio'));
  }
  for (const o of queryAllDeep('button, [role="radio"], [role="option"]', root || document)) {
    if (o.tagName === 'INPUT') continue;
    const host = o.getRootNode && o.getRootNode().host;
    if (host && host.id === 'hp-copilot-overlay') continue;            // our own UI
    if (o.tagName === 'BUTTON' && String(o.type || '').toLowerCase() === 'submit' && o.form) continue;
    const box = (o.closest && o.closest('[role="radiogroup"], [role="listbox"]')) || o.parentElement;
    if (box && !(groups.has(box) && groups.get(box).kind === 'radio')) add(box, o, 'list');
  }
  const out = [];
  for (const g of groups.values()) {
    if (g.options.length < 2 || !g.box.getClientRects().length) continue;
    const q = _choiceQuestion(g.box);
    if (!isHowHeardFillQuestion(q.text, company)) continue;
    out.push(Object.assign(g, { question: q.text, label: q.label }));
  }
  return out;
}

/** Answer how-did-you-hear radio groups and option lists. Returns how many. */
async function answerHowHeardChoices(pack) {
  const saved = howHeardAnswer(pack);
  if (!saved) return 0;                         // nothing saved: the applicant answers
  let answered = 0;
  for (const g of howHeardChoiceGroups(document, pack.company)) {
    if (g.options.some(_choiceOn)) continue;      // answered already, by anyone
    if (g.box.dataset.spotapplyUserModified === 'true' ||
        g.options.some((o) => o.dataset && o.dataset.spotapplyUserModified === 'true')) continue;
    const pick = pickHowHeardOption(g.options.map(_choiceText), saved);
    if (!pick) continue;
    const target = g.options[pick.index];
    if (target.disabled || isAntiBotField(target)) continue;
    const shown = pick.specify ? _shownFields() : null;
    try {
      target.click();                             // a click: the page's own handler records it
      if (g.kind === 'radio' && !target.checked) {
        target.checked = true;
        target.dispatchEvent(new Event('change', { bubbles: true }));
      }
    } catch (e) {
      console.debug('[SpotApply] how-heard click failed:', e.message);
      continue;
    }
    try { g.box.dataset.spotapplyFilled = 'true'; target.dataset.spotapplyFilled = 'true'; } catch (_) {}
    answered++;
    console.log('[SpotApply] How you heard about the job, from your profile:', _choiceText(target).slice(0, 60));
    if (pick.specify) await fillHowHeardSpecify(g.options[g.options.length - 1], pick.specify, g.options, shown);
  }
  return answered;
}

// Some ATS templates write "Résumé" with a DECOMPOSED accent (e + U+0301),
// which a precomposed /résumé/ literal never matches. Strip diacritics before
// matching so both spellings — and "RESUME", "Resume/CV", "Curriculum Vitae" —
// are recognised the same way.
function deaccent(text) {
  try {
    return String(text || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  } catch (_) {
    return String(text || '');
  }
}

/** True when the text names a résumé/CV, however it is accented or cased. */
function saysResume(text) {
  return /resume|\bcv\b|curriculum\s*vitae/i.test(deaccent(text));
}

/** Full name with no "undefined" leakage — "" when we know neither part. */
function fullNameOf(pack) {
  return [pack && pack.first_name, pack && pack.last_name]
    .map((p) => (p == null ? '' : String(p).trim()))
    .filter(Boolean)
    .join(' ');
}

// Fire-and-forget event report so autofill failures are visible on the server
// (FunnelEvent) instead of dying in the browser console.
function reportTelemetry(pack, event, meta) {
  try {
    if (!pack || !packBase(pack) || !pack.auth_token) return;
    apiFetch(`${packBase(pack)}/api/extension/telemetry`, 'POST', pack.auth_token, {
      event,
      app_id: pack.app_id || null,
      host: location.hostname,
      meta: meta || {},
    }).catch(() => {});
  } catch (_) {}
}

// Track user manual changes to prevent autofill overwrites.
//
// isTrusted is the whole point: fillInput dispatches input/change to notify
// React, and these listeners used to treat OUR OWN events as a manual edit.
// Every field we filled was instantly flagged user-modified, so no later pass
// could correct it — nothing self-healed when the resume or ai_answers finally
// arrived. Only a real user gesture sets the flag.
const _markUserModified = (e) => {
  if (!e.isTrusted) return;                    // synthetic = ours, not the user
  const t = e.target;
  if (!t || !t.tagName) return;
  if (!['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON'].includes(t.tagName)) return;
  // Editing a field back to exactly what we wrote is not a divergence.
  if (t.dataset && t.dataset.spotapplyLastWrite !== undefined &&
      String(t.value || '') === t.dataset.spotapplyLastWrite) return;
  t.dataset.spotapplyUserModified = 'true';
};
document.addEventListener('input', _markUserModified, { capture: true, passive: true });
document.addEventListener('change', _markUserModified, { capture: true, passive: true });

// Learn custom dropdown selections manually made by the user.
// Gated: without hpCopilotSurface() this shipped the user's menu choices from
// unrelated sites (any page with an expanded ARIA dropdown) to /api/save-answer.
document.addEventListener('click', (e) => {
  const opt = e.target.closest('[role="option"], [data-automation-id*="option" i], .wd-Dropdown-Option, li, [role="menuitem"]');
  if (opt && hpCopilotSurface()) {
    const activeBtn = document.querySelector('button[aria-expanded="true"], button[data-automation-id="select-button"]:focus, button[aria-haspopup="listbox"]:focus');
    if (activeBtn) {
      const val = opt.textContent?.trim();
      const label = getFieldSignature(activeBtn);
      if (val && label && label.length >= 3) {
        // Never learn a protected answer: saved demographic answers would be
        // written back later without the user's consent. Nor how they heard
        // about one job: only the profile's saved answer is ever used (the
        // extension's own pick on a listbox button was POSTed here).
        if (isDemographicQuestion(label)) return;
        if (isHowHeardQuestion(label)) return;
        console.log('[SpotApply] Learning dropdown field:', label, '->', val);
        getTabPack((pack) => {
          if (pack && packBase(pack) && pack.auth_token) {
            apiFetch(`${packBase(pack)}/api/save-answer`, 'POST', pack.auth_token, {
              question: label,
              answer: val,
              app_id: pack.app_id || null,
            });
          }
        });
      }
    }
  }
}, { capture: true, passive: true });

// Tell the background a link or button was clicked on an application page, so
// a tab it opens (an Apply button with target=_blank) continues the session,
// while a tab the user opens themselves (Ctrl+T) does not.
document.addEventListener('click', (e) => {
  const el = e.target && e.target.closest &&
    e.target.closest('a, button, [role="button"], input[type="button"], input[type="submit"]');
  if (el && hpCopilotSurface()) {
    chromeCall(() => chrome.runtime.sendMessage({ type: 'PAGE_CLICK' }, () => void chrome.runtime.lastError));
  }
}, { capture: true, passive: true });

// Detect step advance click immediately (Next/Continue/Save and Continue)
document.addEventListener('click', (e) => {
  const btn = e.target.closest('button, a, input[type="button"], input[type="submit"]');
  if (btn) {
    const txt = (btn.textContent || btn.value || '').toLowerCase().trim();
    if (/next|continue|save.*continue|submit|agree|accept/i.test(txt)) {
      console.log('[SpotApply] User clicked next/continue button — clearing overlay and scheduling check');
      removeOverlay();
      _resumeAttachedOnPage = null; // reset for next page
      _nativeAutofillOnPage = null; // the next step may offer its own autofill
      if (_resumeStatus && _resumeStatus.state !== 'error') _resumeStatus = null;
      
      // Force a check after 2 seconds to see if we transitioned to a new step
      setTimeout(() => {
        if (!_copilotActive) return;
        if (_fillingInProgress) return;
        runCopilotStep();
      }, 2000);
    }

    // A real submission button says "submit" — never bare "apply" ("Apply"
    // OPENS the form). Pressing it is only an ATTEMPT (see noteSubmitAttempt).
    if (/\bsubmit\b/i.test(txt) && !/\bapply\b/i.test(txt) && hpCopilotSurface()) {
      const form = btn.closest('form');
      if (form && isLoginForm(form)) return;
      // The click fires BEFORE the browser validates. A form that will refuse
      // to submit (an empty required field) is not even an attempt — the old
      // listener marked such applications Submitted and ended the session.
      if (form && typeof form.checkValidity === 'function' && !form.checkValidity()) {
        console.log('[SpotApply] Submit pressed but the form is incomplete — nothing recorded');
        return;
      }
      const hasFields = form
        ? form.querySelectorAll('input, textarea, select').length > 1
        : document.querySelectorAll('input[type="file"], textarea').length > 0;
      if (hasFields) noteSubmitAttempt('click');
    }
  }
}, { capture: true, passive: true });

// The form's own submit event: fires only once browser validation passed.
// Same gates: an ungated listener reported ANY form anywhere (an ATS login
// form included) as an application.
document.addEventListener('submit', (e) => {
  if (!hpCopilotSurface()) return;
  const form = e.target;
  if (!form || isLoginForm(form)) return;
  if (!formLooksLikeApplication(form)) return;
  noteSubmitAttempt('submit');
}, { capture: true, passive: true });

/** A sign-in / sign-up form, never an application. */
function isLoginForm(form) {
  return !!(form && form.querySelector && form.querySelector('input[type="password"]'));
}

/** Enough application-shaped fields to be the application, not a search box. */
function formLooksLikeApplication(form) {
  if (!form || !form.querySelectorAll) return false;
  if (form.querySelector('input[type="file"]')) return true;
  return form.querySelectorAll('input:not([type="hidden"]), textarea, select').length >= 3;
}

// ── Submission: an attempt is not an application ─────────────────────────────
// Audit 2026-09-30: pressing Submit on a form with two empty required fields
// marked the application SUBMITTED and deleted the session. Now:
//   attempt  → remembered on this tab's session only (SUBMIT_ATTEMPTED);
//   confirmed → the employer's own success page, or the user saying so, and
//               only then /application/{id}/submit (FORM_SUBMITTED).
// The session survives validation errors, a login step and a failed upload.
const _CONFIRM_RE = /thank(s| you) for (applying|your application|submitting)|application (has been |was )?(successfully )?(submitted|received|sent)|we(?:'ve| have) received your application|you(?:'ve| have) (successfully )?applied|successfully (submitted|applied)|your application is (complete|on its way|in)/i;
const SUBMIT_CONFIRM_WINDOW_MS = 20 * 60 * 1000;
let _attemptWatch = null;
let _confirmedApps = new Set();

/** The employer's page says the application went through, and no form is left. */
function detectApplicationConfirmed() {
  let text = '';
  try { text = String((document.body && document.body.innerText) || '').slice(0, 30000); } catch (_) {}
  if (!_CONFIRM_RE.test(text)) return false;
  // Boilerplate like "thank you for your interest" sits on job pages too; a
  // page still showing an application form has not confirmed anything.
  const openForm = queryAllDeep('input[type="file"], input[type="email"], textarea')
    .some((el) => el.offsetParent !== null);
  return !openForm;
}

function noteSubmitAttempt(how) {
  // Tell the background FIRST and synchronously: a native submit navigates
  // away immediately, and a lookup-then-send lost the attempt every time. The
  // background records it only on a tab that has a session.
  chromeCall(() => chrome.runtime.sendMessage({ type: 'SUBMIT_ATTEMPTED', url: location.href }, () => {
    void chrome.runtime.lastError;
  }));
  const watch = (pack) => {
    if (!pack || !pack.app_id || _confirmedApps.has(pack.app_id)) return;
    console.log('[SpotApply] Submit attempt (' + how + ') for app', pack.app_id, '— waiting for the employer to confirm');
    watchForConfirmation(pack, Date.now());
  };
  if (_copilotPack) watch(_copilotPack); else getTabPack(watch);
}

/** After an attempt: confirm from the page, else ask the user once. */
function watchForConfirmation(pack, since) {
  if (_attemptWatch) clearInterval(_attemptWatch);
  let asked = false;
  _attemptWatch = setInterval(() => {
    if (_confirmedApps.has(pack.app_id)) { clearInterval(_attemptWatch); return; }
    if (detectApplicationConfirmed()) {
      clearInterval(_attemptWatch);
      confirmSubmitted(pack, 'employer_confirmation');
      return;
    }
    // Greenhouse's other two outcomes after a press: an emailed verification
    // code, or a visual challenge. Both are the human's; say so once and never
    // press again (noteSubmitAttempt is not re-run).
    if (!_confirmPromptOpen && typeof verificationCodeField === 'function' && verificationCodeField()) {
      showOverlay('📬 <b>Enter the verification code</b><br><small>The site emailed you a code to finish this application — ' +
                  'check your inbox (and spam) and paste it here.</small>', [], false);
      reportHandoff(pack, 'verification_code_needed', { after: 'submit' });
      asked = true;      // the code step is the answer; do not also ask "did it submit?"
    } else if (!_confirmPromptOpen && typeof captchaBlocksSubmit === 'function' && captchaBlocksSubmit()) {
      showOverlay('🤖 <b>Please solve the CAPTCHA</b><br><small>The site wants a person here; finish it and click Submit yourself.</small>', [], false);
      reportHandoff(pack, 'captcha_needed', { after: 'submit' });
      asked = true;
    }
    if (!asked && Date.now() - since > 12000) {
      asked = true;
      askIfSubmitted(pack);
    }
    if (Date.now() - since > SUBMIT_CONFIRM_WINDOW_MS) clearInterval(_attemptWatch);
  }, 1500);
}

/** No success page we can recognise: the user decides. Never assumed. */
let _confirmPromptOpen = false;
function askIfSubmitted(pack) {
  if (_confirmedApps.has(pack.app_id)) return;
  _confirmPromptOpen = true;
  showOverlay(
    '📨 <b>Did the employer confirm your application?</b><br>' +
    '<small>SpotApply marks it Submitted only when you say so or the site shows a confirmation.</small>' +
    '<div style="margin-top:8px;display:flex;gap:6px">' +
    '<button data-hp-confirm="yes" style="background:#10b981;color:#fff;border:0;border-radius:8px;padding:6px 10px;font-weight:700;cursor:pointer">Yes, it\'s submitted</button>' +
    '<button data-hp-confirm="no" style="background:rgba(255,255,255,.12);color:#fff;border:0;border-radius:8px;padding:6px 10px;font-weight:700;cursor:pointer">Not yet</button></div>',
    [], false);   // stays until answered — no 30 s auto-hide
  const root = document.getElementById('hp-copilot-overlay');
  const scope = (root && root.shadowRoot) || document;
  const yes = scope.querySelector('[data-hp-confirm="yes"]');
  const no = scope.querySelector('[data-hp-confirm="no"]');
  if (yes) yes.addEventListener('click', () => { _confirmPromptOpen = false; confirmSubmitted(pack, 'user_confirmed'); });
  if (no) no.addEventListener('click', () => { _confirmPromptOpen = false; removeOverlay(); });
}

function confirmSubmitted(pack, how) {
  if (!pack || !pack.app_id || _confirmedApps.has(pack.app_id)) return;
  _confirmedApps.add(pack.app_id);
  chromeCall(() => chrome.runtime.sendMessage(
    { type: 'FORM_SUBMITTED', appId: pack.app_id, pack, how },
    (res) => {
      if (chrome.runtime.lastError || !res || !res.ok) {
        _confirmedApps.delete(pack.app_id);   // allow a retry from this tab
        console.warn('[SpotApply] Could not save the submitted status:',
                     (res && res.error) || (chrome.runtime.lastError && chrome.runtime.lastError.message));
        showOverlay('⚠️ <b>Couldn\'t update SpotApply</b><br><small>Your application may be submitted, but the status was not saved. ' +
                    'Mark it Submitted from your dashboard.</small>', [], true);
        return;
      }
      _copilotActive = false;
      showOverlay('✅ <b>Marked as submitted in SpotApply</b>', [], true);
    }));
}

// ── This tab's application session ───────────────────────────────────────────
// The pack for THIS tab only (background.js keeps one session per tab). Every
// read of "the current application" goes through here — never a global pack.
function getTabPack(cb) {
  chromeCall(() => chrome.runtime.sendMessage({ type: 'GET_TAB_SESSION' }, (res) => {
    if (chrome.runtime.lastError) { cb(null, {}); return; }
    cb((res && res.pack) || null, res || {});
  }));
}

// ── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Write a value into a field. Returns TRUE only if the value is actually in
 * the element afterwards — React and friends routinely discard a write, and a
 * counter that trusts the attempt reported "13 filled" on an empty form.
 */
function fillInput(el, value) {
  if (!el || value === undefined || value === null || value === "") return false;
  // Belt and braces: a template literal over a missing profile field yields
  // the literal string "undefined", which is worse than leaving it blank
  // because it looks filled and gets submitted.
  const _s = String(value);
  if (!_s.trim() || /^(undefined|null)(\s+(undefined|null))*$/i.test(_s.trim())) {
    // Nothing to write is not a failure — an empty portfolio_url produced
    // "Write did not stick" + "Matched but nothing landed" log noise for a
    // field that was simply blank in the profile. Flag it so the caller can
    // tell "we had no value" from "the site rejected our value".
    _lastWriteSkippedEmpty = true;
    if (_s.trim()) {
      console.warn('[SpotApply] Refusing to write placeholder value:', JSON.stringify(_s),
                   'into', el.name || el.id || el.tagName);
    }
    return false;
  }
  _lastWriteSkippedEmpty = false;
  _lastWriteKept = false;

  // Never treat a file input as a text field. Browsers forbid setting .value on
  // <input type="file"> (it throws "accepts a filename"), and the resume is
  // handled separately by attachResume.
  if (el.tagName === 'INPUT' && el.type === 'file') return false;

  // A captcha / anti-bot / honeypot field is never written, by any path.
  if (isAntiBotField(el)) {
    console.log('[SpotApply] Not touching an anti-bot field:', el.name || el.id || el.tagName);
    return false;
  }

  // Respect manual user edits — do not overwrite
  if (el.dataset.spotapplyUserModified === 'true') {
    console.log('[SpotApply] Skipping fill for user-modified field:', el.name || el.id || el.tagName);
    return false;
  }
  
  // Skip if value is already the same
  if (el.value === value) return true; // already correct

  // Guard: only operate on actual form elements — prevents "Illegal invocation"
  // when called on DIVs/spans (e.g. Workday data-automation-id containers)
  const tag = el.tagName;
  // After the board's own resume autofill, what it wrote is kept unless it is
  // the applicant's identity and wrong: the pack is their canonical data, but
  // a company, a title or a history entry the parser read is theirs to review
  // (shouldOverwrite). Without the parser having run this changes nothing.
  if (_nativePrefillActive && (tag === "INPUT" || tag === "TEXTAREA")) {
    const current = String(el.value || "");
    if (current.trim()) {
      const kind = identityKindOf(el);
      if (!shouldOverwrite(kind, current, _s)) {
        _lastWriteKept = true;
        return valuesEquivalent(kind, current, _s);   // true: it already says this
      }
    }
  }
  if (tag === "BUTTON") {
    const isWorkday = hostIs(window.location.hostname, 'workday.com') || hostIs(window.location.hostname, 'myworkdayjobs.com');
    const isSelectBtn = el.getAttribute('data-automation-id') === 'select-button' || el.getAttribute('aria-haspopup') === 'listbox';
    if (isWorkday || isSelectBtn) {
      selectWorkdayDropdown(el, value);
      return true;   // async widget — treated as attempted+applied
    }
    return false;
  }
  if (tag !== "INPUT" && tag !== "TEXTAREA" && tag !== "SELECT") {
    // Try to find an input inside the element (common with Workday containers)
    const inner = el.querySelector('input, textarea');
    if (inner) return fillInput(inner, value);
    return false;
  }
  if (tag === "SELECT") return selectOption(el, value);

  // Set the value using native prototype setter (bypasses React/framework intercepts)
  // Wrapped in try/catch because Workday/custom elements can throw "Illegal invocation"
  try {
    const win = el.ownerDocument?.defaultView || window;
    const proto = tag === "TEXTAREA"
      ? win.HTMLTextAreaElement.prototype
      : win.HTMLInputElement.prototype;
    const nativeSetter = Object.getOwnPropertyDescriptor(proto, "value");
    if (nativeSetter && nativeSetter.set) {
      nativeSetter.set.call(el, value);
    } else {
      el.value = value;
    }
  } catch (e) {
    // Fallback: direct assignment (works for most elements)
    try { el.value = value; } catch (_) {}
    console.warn('[SpotApply] fillInput fallback for:', el.tagName, el.name || el.id || '', e.message);
  }

  // Mark what WE wrote. Without this a diagnostic can't tell a SpotApply fill
  // from Chrome's own autofill or the site restoring a draft — which is the
  // first question to answer when a field comes out wrong or empty.
  try {
    el.dataset.spotapplyFilled = 'true';
    el.dataset.spotapplyLastWrite = _s;
  } catch (_) {}

  // Dispatch events to notify React/Angular/Vue of the change
  try {
    ["input", "change", "blur"].forEach(ev =>
      el.dispatchEvent(new Event(ev, { bubbles: true }))
    );
  } catch (_) {}

  // Read back: a controlled component can reject the write outright. Only a
  // value that survived counts as filled.
  const landed = String(el.value || "") === _s;
  if (!landed) {
    console.warn('[SpotApply] Write did not stick on', el.name || el.id || el.tagName,
                 '— field is controlled or read-only');
  }
  return landed;
}

// ── Work authorization vs sponsorship ────────────────────────────────────────
// Two DIFFERENT questions that ATS forms both phrase around "sponsor/authoriz":
//   "Are you legally authorized to work in the US?"      -> yes for most profiles
//   "Will you now or in the future require sponsorship?" -> pack.requires_sponsorship
// They usually render as Yes/No dropdowns, so feeding either one the
// work_authorization STATUS string ("US Citizen") matches no option and leaves
// a required field blank — and answering the sponsorship question with the
// authorization answer is worse than blank, since a wrong "Yes" here is an
// instant filter-out. Decide from the question text, answer Yes/No when the
// options are boolean, and only fall back to the status string otherwise.

function _yesNoOptions(el) {
  // Real choices, ignoring the "Please select" placeholder.
  const opts = Array.from(el.options || []).filter(
    (o) => o.value !== "" && !/^\s*(please\s+)?select/i.test(o.text || ""));
  if (opts.length < 2 || opts.length > 3) return null;
  const yes = opts.find((o) => /^\s*yes\b/i.test(o.text) || /^yes$/i.test(o.value));
  const no = opts.find((o) => /^\s*no\b/i.test(o.text) || /^no$/i.test(o.value));
  return yes && no ? { yes, no } : null;
}

// Kept for callers that only need "is this person authorized at all".
function _isAuthorized(pack) {
  return workAuthFacts(pack).authorized;
}

/** Answer a sponsorship/work-authorization field. Returns true if handled. */
function answerWorkAuthField(el, pack, label) {
  const l = String(label || "").toLowerCase();
  if (!/sponsor|authoriz|eligible\s+to\s+work|right\s+to\s+work|legally|work\s+permit|visa/.test(l)) return false;
  if (el.dataset && el.dataset.spotapplyUserModified === 'true') return false;
  const answer = interpretWorkAuthQuestion(l, pack);
  const yn = el.tagName === "SELECT" ? _yesNoOptions(el) : null;
  if (yn) {
    if (answer === null) return false;              // unknown — leave for the user
    el.value = (answer ? yn.yes : yn.no).value;
    el.dispatchEvent(new Event("change", { bubbles: true }));
    try { el.dataset.spotapplyFilled = 'true'; } catch (_) {}
    return true;
  }
  // A yes/no QUESTION in a text box or a non-boolean list: answer it only when
  // known, never with the status string.
  const isQuestion = /\?|^\s*(are|do|will|can|have|is)\b/.test(l);
  if (isQuestion || /sponsor/.test(l)) {
    if (answer === null) return false;
    if (el.tagName === "SELECT") return selectOption(el, answer ? "Yes" : "No");
    return fillInput(el, answer ? "Yes" : "No");
  }
  // A status field ("Work authorization", "Visa status"): the user's own words.
  if (pack.work_authorization) {
    if (el.tagName === "SELECT") return selectOption(el, pack.work_authorization);
    return fillInput(el, pack.work_authorization);
  }
  return false;
}

function selectOption(el, value) {
  if (!el || !value) return false;
  // A choice the user made by hand is theirs — no writer may change it back.
  if (el.dataset && el.dataset.spotapplyUserModified === 'true') {
    console.log('[SpotApply] Keeping your own choice in', el.name || el.id || 'a dropdown');
    return false;
  }
  const lower = String(value).toLowerCase().trim();
  const opts = Array.from(el.options);
  const norm = (s) => String(s).toLowerCase().trim();

  // Match in order of confidence so short values like "No" or "CA" don't
  // wrongly substring-match "Norway" / "Canada":
  //   1. exact text/value equality
  //   2. option starts with the value (or vice-versa)
  //   3. substring contains (last resort)
  const exact = opts.find(o => norm(o.text) === lower || norm(o.value) === lower);
  const starts = opts.find(o => norm(o.text).startsWith(lower) || norm(o.value).startsWith(lower));
  const contains = opts.find(o => norm(o.text).includes(lower) || norm(o.value).includes(lower));
  const match = exact || starts || contains;
  if (match) {
    el.value = match.value;
    try { el.dataset.spotapplyFilled = 'true'; } catch (_) {}
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  return false;
}

function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

function findInteractiveField(elements, filterFn) {
  const matched = elements.filter(filterFn);
  if (!matched.length) return null;
  // Prefer button (custom dropdown) first, then select, then input
  return matched.find(el => el.tagName === 'BUTTON') || 
         matched.find(el => el.tagName === 'SELECT') || 
         matched.find(el => el.tagName === 'INPUT') || 
         matched[0];
}

function findItemContainer(el, selector) {
  let container = el.closest('fieldset, [data-automation-id*="-item"], [data-automation-id="workExperienceSection"], [data-automation-id="educationSection"], div[class*="FormSection"], div[class*="group"]');
  if (container && container !== document.body) {
    const items = container.querySelectorAll(selector);
    if (items.length > 1) {
      let current = el.parentElement;
      while (current && current !== container) {
        if (current.querySelectorAll(selector).length === 1) {
          return current;
        }
        current = current.parentElement;
      }
    }
    return container;
  }
  let current = el.parentElement;
  let lastSingle = el;
  while (current && current !== document.body) {
    if (current.querySelectorAll(selector).length > 1) {
      return lastSingle;
    }
    lastSingle = current;
    current = current.parentElement;
  }
  return lastSingle || el.parentElement || document.body;
}

function waitFor(selector, timeout = 8000, root = document) {
  return new Promise((resolve) => {
    const el = root.querySelector(selector);
    if (el) { resolve(el); return; }
    const obs = new MutationObserver(() => {
      const found = root.querySelector(selector);
      if (found) { obs.disconnect(); resolve(found); }
    });
    obs.observe(root.documentElement || root, { childList: true, subtree: true });
    setTimeout(() => { obs.disconnect(); resolve(null); }, timeout);
  });
}

function labelText(el) {
  if (!el) return "";
  let label = "";
  try {
    // 1. Check aria-labelledby (common on Workday custom fields/buttons)
    const ariaLabelledBy = el.getAttribute("aria-labelledby");
    if (ariaLabelledBy) {
      const ids = ariaLabelledBy.split(/\s+/);
      const textParts = [];
      for (const id of ids) {
        if (!id) continue;
        const referredEl = document.getElementById(id);
        if (referredEl) {
          // Exclude the button's/input's own text if it references itself
          if (referredEl === el) continue;
          const txt = referredEl.textContent?.trim();
          if (txt) textParts.push(txt);
        }
      }
      if (textParts.length > 0) {
        label = textParts.join(" ");
      }
    }
  } catch (e) {}

  if (!label) {
    try {
      // Access labels only on form elements that support it
      const win = el.ownerDocument?.defaultView || window;
      if (el instanceof win.HTMLInputElement || el instanceof win.HTMLSelectElement || el instanceof win.HTMLTextAreaElement) {
        label = el.labels?.[0]?.textContent || "";
      }
    } catch (e) {}
  }

  if (!label && el.id) {
    try {
      label = document.querySelector(`label[for="${el.id}"]`)?.textContent || "";
    } catch (e) {}
  }

  if (!label) {
    try {
      label = el.getAttribute("aria-label") ||
        el.getAttribute("placeholder") ||
        el.getAttribute("name") ||
        el.id || "";
    } catch (e) {}
  }

  // 2. If still no label, traverse up to find a nearby label/legend
  if (!label) {
    try {
      let parent = el.parentElement;
      let depth = 0;
      while (parent && depth < 5 && parent !== document.body) {
        const labelEl = parent.querySelector("label, legend");
        if (labelEl) {
          label = labelEl.textContent || "";
          break;
        }
        parent = parent.parentElement;
        depth++;
      }
    } catch (e) {}
  }

  return String(label).toLowerCase().trim();
}

// ── Greenhouse ────────────────────────────────────────────────────────────────

async function fillGreenhouse(pack) {
  // If on the job description page (no form visible), click Apply
  let root = document;
  const hasForm = document.querySelector(
    "#first_name, input[name='job_application[first_name]'], #resume_upload_or_paste, #resume, form#application_form"
  );
  if (!hasForm) {
    const applyBtns = [
      ...document.querySelectorAll("a[href*='/apply'], button"),
    ].filter(el => /apply/i.test(el.textContent) && el.offsetParent);
    if (applyBtns[0]) {
      applyBtns[0].click();
      await delay(3000);
    }
  }

  // Check for Greenhouse embed iframe (custom career pages)
  for (const fr of document.querySelectorAll("iframe")) {
    try {
      if (fr.src?.includes("greenhouse.io/embed")) {
        root = fr.contentDocument;
        break;
      }
    } catch (e) {}
  }

  // ── Fixed fields (standard Greenhouse IDs) ──
  const fixed = {
    "#first_name": pack.first_name,
    "#last_name": pack.last_name,
    "#email": pack.email,
    "#phone": pack.phone,
    "input[name='job_application[first_name]']": pack.first_name,
    "input[name='job_application[last_name]']": pack.last_name,
    "input[name='job_application[email]']": pack.email,
    "input[name='job_application[phone]']": pack.phone,
    "#job_application_first_name": pack.first_name,
    "#job_application_last_name": pack.last_name,
    "#job_application_email": pack.email,
    "#job_application_phone": pack.phone,
  };
  for (const [sel, val] of Object.entries(fixed)) {
    const el = root.querySelector(sel);
    if (el) fillInput(el, val);
  }

  await delay(300);

  // ── Cover letter (textarea) ──
  for (const sel of [
    "#cover_letter",
    "textarea[name='job_application[cover_letter]']",
    "textarea[id*='cover']",
    "textarea[name*='cover']",
  ]) {
    const el = root.querySelector(sel);
    if (el) { fillInput(el, pack.cover_letter || ""); break; }
  }

  // ── LinkedIn / GitHub / Portfolio / Website ──
  for (const [kw, val] of [
    ["linkedin", pack.linkedin_url],
    ["github", pack.github_url],
    ["portfolio", pack.portfolio_url],
    ["website", pack.portfolio_url],
    ["twitter", ""],
  ]) {
    if (!val) continue;
    const el = root.querySelector(
      `input[id*="${kw}" i], input[placeholder*="${kw}" i], input[name*="${kw}" i]`
    );
    if (el) fillInput(el, val);
  }

  // ── Custom questions via label matching ──
  // Greenhouse custom questions render as <label> + <input|textarea|select>
  // We scan every visible field and match by its label text.
  const allInputs = root.querySelectorAll(
    "input:not([type='hidden']):not([type='file']):not([type='submit']):not([type='checkbox']):not([type='radio']), textarea, select"
  );
  for (const inp of allInputs) {
    if (!canFillField(inp)) continue;          // hidden / captcha / honeypot
    const lbl = labelText(inp);
    if (!lbl) continue;
    if (isHowHeardQuestion(lbl)) continue;     // fillUniversal: the saved answer only

    // Skip already-filled fixed fields — unless the board's own resume
    // autofill wrote them and they are identity fields, which fillInput then
    // checks against the pack (a wrong parse of the applicant's own details).
    if (inp.value && inp.value.trim() && !nativeMayCorrect(inp)) continue;

    if (/first.?name|given.?name/i.test(lbl)) fillInput(inp, pack.first_name);
    else if (/last.?name|family.?name|surname/i.test(lbl)) fillInput(inp, pack.last_name);
    // Single "Full name" field — Recruitee, Lever and most lightweight boards
    // use one instead of first/last. Missing here, so on those forms the name
    // was the one required field the copilot never filled.
    else if (/full.?name|candidate.?name|^\s*name\s*\*?\s*$/i.test(lbl))
      fillInput(inp, fullNameOf(pack));
    else if (/\bemail\b/i.test(lbl)) fillInput(inp, pack.email);
    else if (/phone|mobile|telephone/i.test(lbl)) fillPhoneField(inp, pack.phone);
    // An autocomplete is left to fillUniversal, which picks a suggestion.
    else if (/city|location|where.*based|where.*live/i.test(lbl)) { if (!isAutocompleteInput(inp)) fillInput(inp, pack.location || ""); }
    else if (/linkedin/i.test(lbl)) fillInput(inp, pack.linkedin_url || "");
    else if (/github/i.test(lbl)) fillInput(inp, pack.github_url || "");
    else if (/portfolio|personal.*site|website|personal.*url/i.test(lbl)) fillInput(inp, pack.portfolio_url || "");
    else if (/cover.?letter/i.test(lbl) && inp.tagName === "TEXTAREA") fillInput(inp, pack.cover_letter || "");
    else if (/years?.*(of\s+)?experience|how.*long.*experience/i.test(lbl)) fillInput(inp, String(pack.years_experience || ""));
    else if (/current.*title|job.*title|position/i.test(lbl)) fillInput(inp, pack.current_title || "");
    else if (/salary|compensation|expected.*pay/i.test(lbl)) fillInput(inp, String(pack.salary_min || ""));
    else if (/pronouns/i.test(lbl)) fillInput(inp, "");
    else if (inp.tagName === "SELECT") {
      if (/hispanic|latin/i.test(lbl) && !/\brace\b|ethnic/i.test(lbl)) fillEEOField(inp, eeoValueFor(pack, 'hispanic'), 'hispanic');
      else if (/gender/i.test(lbl)) fillEEOField(inp, pack.gender || 'decline', 'gender');
      else if (/race|ethnic/i.test(lbl)) fillEEOField(inp, pack.ethnicity || 'decline', 'ethnicity');
      else if (/veteran/i.test(lbl)) fillEEOField(inp, pack.veteran_status || 'decline', 'veteran');
      else if (/disability/i.test(lbl)) fillEEOField(inp, pack.disability_status || 'decline', 'disability');
      else if (/sponsor|visa|authoriz/i.test(lbl)) answerWorkAuthField(inp, pack, lbl);
      else if (/country/i.test(lbl) && residenceCountry(pack)) selectOption(inp, residenceCountry(pack));
    }
  }

  // ── EEOC selects (by id or label; catches any missed above) ──
  // Twice: Greenhouse reveals Race only after "Are you Hispanic/Latino?" = No.
  fillEEOSelectsIn(root, pack);
  setTimeout(() => { try { fillEEOSelectsIn(root, pack); } catch (_) {} }, 700);

  // ── Work authorization radio/select ──
  if (pack.work_authorization) {
    const authSel = root.querySelector("select[id*='authoriz'], select[name*='authoriz']");
    if (authSel && !authSel.value) selectOption(authSel, pack.work_authorization);
  }

  // Fill essay questions from AI-generated answers in pack
  if (pack.ai_answers) {
    await fillEssayQuestions(root, pack);
  }

  return true;
}

// ── Lever ─────────────────────────────────────────────────────────────────────

async function fillLever(pack) {
  // Navigate to /apply if on description page
  if (!window.location.pathname.includes("/apply")) {
    const applyLink = document.querySelector("a[href*='/apply']");
    if (applyLink) {
      applyLink.click();
      await delay(2500);
    } else {
      const url = window.location.href.replace(/\/?$/, "/apply");
      window.location.href = url;
      return true; // page reloads, content script re-runs
    }
  }

  const map = {
    "input[name='name']": fullNameOf(pack),
    "input[name='email']": pack.email,
    "input[name='phone']": pack.phone,
    // "Current company" — the employer, never the job title (audit 2026-09-30:
    // "Software Engineer" landed here). Blank when nothing is current.
    "input[name='org']": currentEmployer(pack),
    "input[name='urls[LinkedIn]']": pack.linkedin_url || "",
    "input[name='urls[GitHub]']": pack.github_url || "",
    "input[name='urls[Portfolio]']": pack.portfolio_url || "",
    "input[name='urls[Other]']": pack.portfolio_url || "",
  };

  for (const [sel, val] of Object.entries(map)) {
    const el = document.querySelector(sel);
    if (el && val) fillInput(el, val);
  }

  const cl = document.querySelector("textarea[name='comments'], textarea[id*='cover']");
  if (cl) fillInput(cl, pack.cover_letter || "");

  if (pack.ai_answers) {
    await fillEssayQuestions(document, pack);
  }

  return true;
}

// ── Ashby ─────────────────────────────────────────────────────────────────────

async function fillAshby(pack) {
  // Click the "Application" tab if we're on the Overview tab
  const tabs = document.querySelectorAll('button[role="tab"], a[role="tab"], nav a, .tab, [data-tab]');
  for (const tab of tabs) {
    if (/^application$/i.test((tab.textContent || '').trim())) {
      if (!tab.classList.contains('active') && tab.getAttribute('aria-selected') !== 'true') {
        tab.click();
        await delay(1200);
      }
      break;
    }
  }
  // Also handle Ashby's specific tab nav (link-based)
  const appLink = [...document.querySelectorAll('a')].find(a => /^application$/i.test((a.textContent || '').trim()));
  if (appLink && !appLink.classList.contains('active') && window.location.href !== appLink.href) {
    appLink.click();
    await delay(1200);
  }

  // Wait for inputs to appear after tab switch
  let waited = 0;
  while (!document.querySelector('input[type="text"], input[type="email"], textarea') && waited < 4000) {
    await delay(300);
    waited += 300;
  }

  const inputs = document.querySelectorAll("input:not([type='file']):not([type='hidden']), textarea");
  for (const inp of inputs) {
    // The reCAPTCHA textarea Ashby embeds is hidden and named, not labelled.
    if (!canFillField(inp)) continue;
    const lbl = labelText(inp);
    if (isHowHeardQuestion(lbl)) continue;     // fillUniversal: the saved answer only
    // "(name)?" is optional, so /first.*(name)?/ reduced to /first/ — it typed
    // the user's surname into "What was your last compensation?" and their
    // forename into "When did you first hear about us?". Require the word.
    if (/first\s*_?\s*name|given\s*name|forename/i.test(lbl)) fillInput(inp, pack.first_name);
    else if (/last\s*_?\s*name|surname|family\s*name/i.test(lbl)) fillInput(inp, pack.last_name);
    else if (/^name$/i.test(lbl)) fillInput(inp, fullNameOf(pack));
    else if (/email/i.test(lbl)) fillInput(inp, pack.email);
    else if (/phone|mobile/i.test(lbl)) fillPhoneField(inp, pack.phone);
    else if (/linkedin/i.test(lbl)) fillInput(inp, pack.linkedin_url || "");
    else if (/github/i.test(lbl)) fillInput(inp, pack.github_url || "");
    else if (/portfolio|website/i.test(lbl)) fillInput(inp, pack.portfolio_url || "");
    else if (/cover.*letter/i.test(lbl) && inp.tagName === "TEXTAREA") fillInput(inp, pack.cover_letter || "");
  }

  if (pack.ai_answers) {
    await fillEssayQuestions(document, pack);
  }

  return true;
}

// (LinkedIn Easy Apply filler removed — automating LinkedIn violates their
//  User Agreement and risks the user's account; Easy Apply pre-fills natively.)

// (Indeed filler removed — same hands-off policy as LinkedIn: automating
//  Indeed's own pages risks the user's account; external redirects land on the
//  company ATS where the copilot fills normally.)

// ── Location parser + US state map ──────────────────────────────────────────
// Splits "Cincinnati, OH" → { city: "Cincinnati", state: "Ohio", abbr: "OH" }

const US_STATES = {
  'AL':'Alabama','AK':'Alaska','AZ':'Arizona','AR':'Arkansas','CA':'California',
  'CO':'Colorado','CT':'Connecticut','DE':'Delaware','FL':'Florida','GA':'Georgia',
  'HI':'Hawaii','ID':'Idaho','IL':'Illinois','IN':'Indiana','IA':'Iowa',
  'KS':'Kansas','KY':'Kentucky','LA':'Louisiana','ME':'Maine','MD':'Maryland',
  'MA':'Massachusetts','MI':'Michigan','MN':'Minnesota','MS':'Mississippi','MO':'Missouri',
  'MT':'Montana','NE':'Nebraska','NV':'Nevada','NH':'New Hampshire','NJ':'New Jersey',
  'NM':'New Mexico','NY':'New York','NC':'North Carolina','ND':'North Dakota','OH':'Ohio',
  'OK':'Oklahoma','OR':'Oregon','PA':'Pennsylvania','RI':'Rhode Island','SC':'South Carolina',
  'SD':'South Dakota','TN':'Tennessee','TX':'Texas','UT':'Utah','VT':'Vermont',
  'VA':'Virginia','WA':'Washington','WV':'West Virginia','WI':'Wisconsin','WY':'Wyoming',
  'DC':'District of Columbia',
};
// Canadian provinces/territories, read only by pickLocationSuggestion so a
// "London, ON" profile can recognise "London, Ontario, Canada".
const CA_PROVINCES = {
  'AB':'Alberta','BC':'British Columbia','MB':'Manitoba','NB':'New Brunswick',
  'NL':'Newfoundland and Labrador','NS':'Nova Scotia','NT':'Northwest Territories',
  'NU':'Nunavut','ON':'Ontario','PE':'Prince Edward Island','QC':'Quebec',
  'SK':'Saskatchewan','YT':'Yukon',
};

/**
 * The employer of the role the résumé marks as CURRENT (end "Present"/blank),
 * or "" — a finished job is not a current company.
 */
function currentEmployer(pack) {
  const jobs = (pack && Array.isArray(pack.work_experience)) ? pack.work_experience : [];
  const cur = jobs.find((j) => j && j.company &&
    (!String(j.end || j.end_date || '').trim() || /present|current|now|today/i.test(String(j.end || j.end_date))));
  return cur ? String(cur.company).trim() : '';
}

/**
 * Where the applicant LIVES, as the server derived it from their own location
 * — "" when it does not say. Not the country they want jobs in, not their
 * citizenship, and never a default: every handler used to hardcode "United
 * States", so a Toronto profile was filed as a US resident.
 */
function residenceCountry(pack) {
  return String((pack && pack.residence_country) || '').trim();
}

function parseLocation(location) {
  if (!location) return { city: '', state: '', abbr: '' };
  const parts = location.split(',').map(s => s.trim());
  const city = parts[0] || '';
  let stateRaw = (parts[1] || '').replace(/\d{5}(-\d{4})?/, '').trim();
  const abbr = stateRaw.toUpperCase();
  const state = US_STATES[abbr] || stateRaw;
  return { city, state, abbr };
}

// ── Workday ─────────────────────────────────────────────────────────────────

function parseDateString(dateStr) {
  if (!dateStr) return { month: '', monthName: '', year: '' };
  const str = String(dateStr).trim();
  
  // Try YYYY-MM
  let m = str.match(/^(\d{4})-(\d{2})$/);
  if (m) {
    const monthNum = parseInt(m[2], 10);
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    return {
      month: String(monthNum),
      monthName: months[monthNum - 1],
      year: m[1]
    };
  }
  
  // Try MM/YYYY or MM-YYYY
  m = str.match(/^(\d{1,2})[\/\-](\d{4})$/);
  if (m) {
    const monthNum = parseInt(m[1], 10);
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    return {
      month: String(monthNum),
      monthName: months[monthNum - 1],
      year: m[2]
    };
  }

  // Extract 4 digit year
  const yearMatch = str.match(/\b(\d{4})\b/);
  const year = yearMatch ? yearMatch[1] : '';
  
  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const shortMonths = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  
  let month = '';
  let monthName = '';
  for (let i = 0; i < months.length; i++) {
    if (str.toLowerCase().includes(months[i].toLowerCase()) || str.toLowerCase().includes(shortMonths[i].toLowerCase())) {
      month = String(i + 1);
      monthName = months[i];
      break;
    }
  }
  
  return { month, monthName, year };
}

function matchDegree(optionText, targetVal) {
  const opt = optionText.toLowerCase().trim();
  const tgt = targetVal.toLowerCase().trim();
  
  if (opt.includes(tgt) || tgt.includes(opt)) return true;
  
  // Fuzzy matching for degree levels
  const levels = [
    { key: 'master', terms: ['master', 'm.s.', 'ms', 'm.e.', 'me', 'mba'] },
    { key: 'bachelor', terms: ['bachelor', 'b.s.', 'bs', 'b.a.', 'ba', 'b.t.', 'bt', 'btech'] },
    { key: 'doctor', terms: ['doctor', 'phd', 'ph.d.'] },
    { key: 'associate', terms: ['associate', 'a.s.', 'as'] },
    { key: 'diploma', terms: ['diploma', 'high school', 'secondary'] }
  ];
  
  for (const level of levels) {
    const optHas = level.terms.some(t => opt.includes(t));
    const tgtHas = level.terms.some(t => tgt.includes(t));
    if (optHas && tgtHas) return true;
  }
  
  return false;
}

async function selectWorkdayDropdown(buttonEl, value) {
  if (!buttonEl || !value) return false;
  buttonEl.click();
  await delay(600); // wait for dropdown to open
  
  const lowerVal = String(value).toLowerCase().trim();
  const options = Array.from(document.querySelectorAll(
    '[role="option"], [data-automation-id*="option" i], [data-automation-id*="menu" i], ' +
    '.wd-Dropdown-Option, li, [role="menuitem"], [data-automation-label]'
  ));
  
  // 1. Try exact/substring match first
  for (const opt of options) {
    const text = opt.textContent?.toLowerCase().trim();
    if (text && (text === lowerVal || text.includes(lowerVal) || lowerVal.includes(text))) {
      opt.click();
      await delay(400);
      return true;
    }
  }
  
  // 2. Try fuzzy degree match
  for (const opt of options) {
    const text = opt.textContent;
    if (text && matchDegree(text, value)) {
      opt.click();
      await delay(400);
      return true;
    }
  }
  
  // Click again to close if not selected
  try { buttonEl.click(); } catch (_) {}
  return false;
}

// Modern Workday renders each date as a row of spinbutton "sections"
// (id ending -dateSectionMonth / -dateSectionYear). Each section contains a real
// <input>; set THAT via the native value setter (the wrapper div ignores input).
async function setWorkdayDateSection(wrap, kind, value) {
  value = String(value || '').replace(/\D/g, '');
  if (!value) return false;
  const input =
    wrap.querySelector(`input[data-automation-id="dateSection${kind}-input"]`) ||
    wrap.querySelector(`[id$="dateSection${kind}"] input`) ||
    wrap.querySelector(`input[id$="dateSection${kind}-input"]`);
  const section = wrap.querySelector(`[id$="dateSection${kind}"]`);
  const target = input || section;
  if (!target) return false;

  // Respect manual user edits on the date target
  if (target.dataset.spotapplyUserModified === 'true') {
    return false;
  }

  try { target.scrollIntoView({ block: 'center' }); } catch (_) {}
  target.focus();
  
  if (input) {
    // 1. Set values React-compatibly
    fillInput(input, value);
    await delay(30);
  }

  // 2. Simulate complete typing key events on the target (input or wrapper div)
  // to ensure React/Workday state-binding gets triggered.
  for (const ch of value) {
    const kc = 48 + Number(ch);
    const init = { key: ch, code: 'Digit' + ch, keyCode: kc, which: kc, bubbles: true, cancelable: true };
    target.dispatchEvent(new KeyboardEvent('keydown', init));
    target.dispatchEvent(new KeyboardEvent('keypress', init));
    if (input) {
      input.dispatchEvent(new InputEvent('input', { data: ch, inputType: 'insertText', bubbles: true, cancelable: true }));
    }
    target.dispatchEvent(new KeyboardEvent('keyup', init));
    await delay(50);
  }

  target.dispatchEvent(new Event('change', { bubbles: true }));
  target.dispatchEvent(new FocusEvent('blur', { bubbles: true }));
  return true;
}

// Fill Workday's spinbutton date widget for a given date field ('start'/'end').
// Returns true only if the spinbutton widget was found, so callers can fall back
// to the legacy <input>/<select> date handling for older Workday layouts.
async function fillWorkdayDateWidget(container, side, info) {
  if (!container || !info || !info.year) return false;
  const fieldName = side === 'start' ? 'startDate' : 'endDate';
  const wrap = container.querySelector(
    `[data-automation-id="formField-${fieldName}"], [data-fkit-id$="${fieldName}"]`
  );
  if (!wrap) return false;
  if (!wrap.querySelector('[id$="dateSectionMonth"], [id$="dateSectionYear"], input[data-automation-id*="dateSection" i]')) {
    return false; // no spinbutton sections — let the legacy handler try
  }
  if (info.month) await setWorkdayDateSection(wrap, 'Month', String(info.month).padStart(2, '0'));
  await setWorkdayDateSection(wrap, 'Year', info.year);
  console.log('[SpotApply] Filled Workday', side, 'date spinner:', info.month || '?', '/', info.year);
  return true;
}

async function fillWorkdayExperienceAndEducation(pack) {
  // ── Work Experience ──
  // After the board's own resume autofill, the entries it created are its
  // work: this filler cannot merge into a multi-entry section it did not build
  // (it would add duplicates and overwrite parsed dates), so a section that
  // already holds entries is left exactly as parsed — that is the time saved.
  const keepParsed = (what, sel) => {
    if (!_nativePrefillActive || !document.querySelector(sel)) return false;
    console.log(`[SpotApply] Keeping the ${what} entries the site filled from your resume`);
    return true;
  };

  if (pack.work_experience && pack.work_experience.length > 0 &&
      !keepParsed('work experience', 'input[data-automation-id="jobTitle"], input[id*="jobTitle" i]')) {
    // Find the Work Experience section or default to body
    const workSection = document.querySelector('[data-automation-id="workExperienceSection"]') || document.body;
    
    // Find Add button
    let addBtn = workSection.querySelector('button[data-automation-id="Add"], button[data-automation-id="workExperience-add"]');
    if (!addBtn) {
      addBtn = Array.from(workSection.querySelectorAll('button')).find(btn => /add.*experience|add.*another|add.*position/i.test(btn.textContent));
    }
    
    // Find how many job inputs exist right now
    let jobInputs = Array.from(workSection.querySelectorAll('input[data-automation-id="jobTitle"], input[id*="jobTitle" i]'));
    
    if (jobInputs.length === 0 && addBtn) {
      addBtn.click();
      await delay(1200);
      jobInputs = Array.from(workSection.querySelectorAll('input[data-automation-id="jobTitle"], input[id*="jobTitle" i]'));
    }
    
    const targetCount = pack.work_experience.length;
    let attempts = 0;
    while (jobInputs.length < targetCount && addBtn && attempts < 5) {
      addBtn.click();
      await delay(1200);
      jobInputs = Array.from(workSection.querySelectorAll('input[data-automation-id="jobTitle"], input[id*="jobTitle" i]'));
      attempts++;
    }
    
    // Fill each block
    for (let i = 0; i < jobInputs.length; i++) {
      const jobData = pack.work_experience[i];
      if (!jobData) continue;
      
      const jobInput = jobInputs[i];
      const container = findItemContainer(jobInput, 'input[data-automation-id="jobTitle"], input[id*="jobTitle" i]') || workSection;
      
      // Job Title
      fillInput(jobInput, jobData.title);
      
      // Company
      const companyInput = container.querySelector('input[data-automation-id="company"], input[data-automation-id="employer"], input[id*="company" i], input[id*="employer" i]');
      if (companyInput) fillInput(companyInput, jobData.company);
      
      // Location
      const locInput = container.querySelector('input[data-automation-id="location"], input[id*="location" i]');
      if (locInput) fillInput(locInput, jobData.location);
      
      // Description
      const descInput = container.querySelector('textarea[data-automation-id="description"], textarea[id*="description" i], textarea');
      if (descInput) fillInput(descInput, jobData.description);
      
      // Currently Work Here
      const currentCheckbox = container.querySelector('input[type="checkbox"]');
      const isCurrent = String(jobData.end_date).toLowerCase().includes('present') || String(jobData.end_date).toLowerCase().includes('current');
      if (currentCheckbox) {
        currentCheckbox.checked = isCurrent;
        currentCheckbox.dispatchEvent(new Event('change', { bubbles: true }));
      }
      
      // ── Dates ──
      // Modern Workday uses div-based spinbutton sections (handled by
      // fillWorkdayDateWidget); older layouts use real <input>/<select>/<button>
      // widgets, kept here as a fallback when the spinbutton widget isn't found.
      const startInfo = parseDateString(jobData.start_date);
      const startWidgetDone = await fillWorkdayDateWidget(container, 'start', startInfo);
      if (!startWidgetDone) {
        const startFields = Array.from(container.querySelectorAll('input, select, textarea, button'));
        const startMonth = findInteractiveField(startFields, el => {
          const sig = (el.id + ' ' + (el.getAttribute('data-automation-id') || '') + ' ' + (el.name || '') + ' ' + labelText(el)).toLowerCase();
          return (sig.includes('start') || sig.includes('from')) && sig.includes('month');
        });
        const startYear = findInteractiveField(startFields, el => {
          const sig = (el.id + ' ' + (el.getAttribute('data-automation-id') || '') + ' ' + (el.name || '') + ' ' + labelText(el)).toLowerCase();
          return (sig.includes('start') || sig.includes('from')) && sig.includes('year');
        });
        const startDateInput = findInteractiveField(startFields, el => {
          const sig = (el.id + ' ' + (el.getAttribute('data-automation-id') || '') + ' ' + (el.name || '') + ' ' + labelText(el)).toLowerCase();
          return (sig.includes('start') || sig.includes('from')) && !sig.includes('month') && !sig.includes('year') && el.tagName !== 'BUTTON';
        });
        if (startInfo.month && startMonth) {
          if (startMonth.tagName === 'SELECT') {
            selectOption(startMonth, startInfo.monthName || startInfo.month);
          } else if (startMonth.tagName === 'BUTTON') {
            await selectWorkdayDropdown(startMonth, startInfo.monthName || startInfo.month);
          } else {
            fillInput(startMonth, startInfo.month);
          }
        }
        if (startInfo.year && startYear) {
          fillInput(startYear, startInfo.year);
        }
        if (startDateInput && startInfo.year) {
          const monthFormatted = startInfo.month ? String(startInfo.month).padStart(2, '0') : '01';
          fillInput(startDateInput, `${monthFormatted}/${startInfo.year}`);
        }
      }

      // End date
      if (!isCurrent) {
        const endInfo = parseDateString(jobData.end_date);
        const endWidgetDone = await fillWorkdayDateWidget(container, 'end', endInfo);
        if (!endWidgetDone) {
          const endFields = Array.from(container.querySelectorAll('input, select, textarea, button'));
          const endMonth = findInteractiveField(endFields, el => {
            const sig = (el.id + ' ' + (el.getAttribute('data-automation-id') || '') + ' ' + (el.name || '') + ' ' + labelText(el)).toLowerCase();
            return (sig.includes('end') || sig.includes('to')) && sig.includes('month');
          });
          const endYear = findInteractiveField(endFields, el => {
            const sig = (el.id + ' ' + (el.getAttribute('data-automation-id') || '') + ' ' + (el.name || '') + ' ' + labelText(el)).toLowerCase();
            return (sig.includes('end') || sig.includes('to')) && sig.includes('year');
          });
          const endDateInput = findInteractiveField(endFields, el => {
            const sig = (el.id + ' ' + (el.getAttribute('data-automation-id') || '') + ' ' + (el.name || '') + ' ' + labelText(el)).toLowerCase();
            return (sig.includes('end') || sig.includes('to')) && !sig.includes('month') && !sig.includes('year') && el.tagName !== 'BUTTON';
          });
          if (endInfo.month && endMonth) {
            if (endMonth.tagName === 'SELECT') {
              selectOption(endMonth, endInfo.monthName || endInfo.month);
            } else if (endMonth.tagName === 'BUTTON') {
              await selectWorkdayDropdown(endMonth, endInfo.monthName || endInfo.month);
            } else {
              fillInput(endMonth, endInfo.month);
            }
          }
          if (endInfo.year && endYear) {
            fillInput(endYear, endInfo.year);
          }
          if (endDateInput && endInfo.year) {
            const monthFormatted = endInfo.month ? String(endInfo.month).padStart(2, '0') : '01';
            fillInput(endDateInput, `${monthFormatted}/${endInfo.year}`);
          }
        }
      }
    }
  }

  // ── Education ──
  if (pack.education && pack.education.length > 0 &&
      !keepParsed('education', 'input[data-automation-id="school"], input[data-automation-id="institution"], input[id*="school" i], input[id*="institution" i]')) {
    const eduSection = document.querySelector('[data-automation-id="educationSection"]') || document.body;
    
    let addBtn = eduSection.querySelector('button[data-automation-id="Add"], button[data-automation-id="education-add"]');
    if (!addBtn) {
      addBtn = Array.from(eduSection.querySelectorAll('button')).find(btn => /add.*education|add.*degree|add.*school/i.test(btn.textContent));
    }
    
    let schoolInputs = Array.from(eduSection.querySelectorAll('input[data-automation-id="school"], input[data-automation-id="institution"], input[id*="school" i], input[id*="institution" i]'));
    
    if (schoolInputs.length === 0 && addBtn) {
      addBtn.click();
      await delay(1200);
      schoolInputs = Array.from(eduSection.querySelectorAll('input[data-automation-id="school"], input[data-automation-id="institution"], input[id*="school" i], input[id*="institution" i]'));
    }
    
    const targetCount = pack.education.length;
    let attempts = 0;
    while (schoolInputs.length < targetCount && addBtn && attempts < 5) {
      addBtn.click();
      await delay(1200);
      schoolInputs = Array.from(eduSection.querySelectorAll('input[data-automation-id="school"], input[data-automation-id="institution"], input[id*="school" i], input[id*="institution" i]'));
      attempts++;
    }
    
    for (let i = 0; i < schoolInputs.length; i++) {
      const eduData = pack.education[i];
      if (!eduData) continue;
      
      const schoolInput = schoolInputs[i];
      const container = findItemContainer(schoolInput, 'input[data-automation-id="school"], input[data-automation-id="institution"], input[id*="school" i], input[id*="institution" i]') || eduSection;
      
      // School / Institution
      fillInput(schoolInput, eduData.school);
      
      // Degree dropdown button/input
      const degreeWrapper = container.querySelector('[data-automation-id="degree"], [id*="degree" i]');
      let degreeEl = null;
      if (degreeWrapper) {
        const wrapperFields = Array.from(degreeWrapper.querySelectorAll('input, select, textarea, button'));
        degreeEl = findInteractiveField(wrapperFields, () => true) || degreeWrapper;
      } else {
        degreeEl = container.querySelector('[data-automation-id="degree"], select[name*="degree" i], input[name*="degree" i], button[data-automation-id="select-button"]');
      }
      
      if (degreeEl) {
        if (degreeEl.tagName === 'SELECT') {
          selectOption(degreeEl, eduData.degree);
        } else if (degreeEl.tagName === 'BUTTON') {
          await selectWorkdayDropdown(degreeEl, eduData.degree);
        } else {
          fillInput(degreeEl, eduData.degree);
        }
      }
      
      // Field of Study (major)
      const fieldWrapper = container.querySelector('[data-automation-id="fieldOfStudy"], [id*="fieldOfStudy" i], [id*="major" i], [id*="study" i]');
      let fieldEl = null;
      if (fieldWrapper) {
        const wrapperFields = Array.from(fieldWrapper.querySelectorAll('input, select, textarea, button'));
        fieldEl = findInteractiveField(wrapperFields, () => true) || fieldWrapper;
      } else {
        fieldEl = container.querySelector('[data-automation-id="fieldOfStudy"], input[name*="major" i], input[name*="study" i]');
      }
      if (fieldEl) fillInput(fieldEl, eduData.field_of_study || eduData.major || '');
      
      // Graduation Year / Month / Single Date.
      // Use 'graduat' (not 'grad') and exclude GPA/grade-point/result/score
      // fields — otherwise Workday's "gradePointAverage" GPA input matches and
      // gets a date written into it (e.g. "04/2026" in the GPA box).
      const isGpaish = (sig) => /gpa|grade.?point|result|score|average/.test(sig);
      const isDateContext = (sig) => sig.includes('graduat') || sig.includes('completion') || sig.includes('enddate') || /\bend\b/.test(sig);
      const eduFields = Array.from(container.querySelectorAll('input, select, textarea, button'));
      const gradMonth = findInteractiveField(eduFields, el => {
        const sig = (el.id + ' ' + (el.getAttribute('data-automation-id') || '') + ' ' + (el.name || '') + ' ' + labelText(el)).toLowerCase();
        return !isGpaish(sig) && isDateContext(sig) && sig.includes('month');
      });
      const gradYear = findInteractiveField(eduFields, el => {
        const sig = (el.id + ' ' + (el.getAttribute('data-automation-id') || '') + ' ' + (el.name || '') + ' ' + labelText(el)).toLowerCase();
        return !isGpaish(sig) && isDateContext(sig) && sig.includes('year');
      });
      const gradDateInput = findInteractiveField(eduFields, el => {
        const sig = (el.id + ' ' + (el.getAttribute('data-automation-id') || '') + ' ' + (el.name || '') + ' ' + labelText(el)).toLowerCase();
        return !isGpaish(sig) && isDateContext(sig) && !sig.includes('month') && !sig.includes('year') && el.tagName !== 'BUTTON';
      });

      const endInfo = parseDateString(eduData.end_date);
      if (endInfo.month && gradMonth) {
        if (gradMonth.tagName === 'SELECT') {
          selectOption(gradMonth, endInfo.monthName || endInfo.month);
        } else if (gradMonth.tagName === 'BUTTON') {
          await selectWorkdayDropdown(gradMonth, endInfo.monthName || endInfo.month);
        } else {
          fillInput(gradMonth, endInfo.month);
        }
      }
      if (endInfo.year && gradYear) {
        fillInput(gradYear, endInfo.year);
      }
      if (gradDateInput && endInfo.year) {
        const monthFormatted = endInfo.month ? String(endInfo.month).padStart(2, '0') : '01';
        fillInput(gradDateInput, `${monthFormatted}/${endInfo.year}`);
      }
    }
  }
}

async function fillWorkday(pack) {
  await delay(2000); // Workday renders slowly
  const loc = parseLocation(pack.location);

  // Fill Work Experience and Education history
  await fillWorkdayExperienceAndEducation(pack);

  // data-automation-id based — find actual inputs inside or at the element
  const autos = document.querySelectorAll("[data-automation-id]");
  for (const container of autos) {
    const aid = container.getAttribute("data-automation-id") || "";
    // Resolve the actual input: either the element itself or an input within it
    const el = (container.tagName === 'INPUT' || container.tagName === 'TEXTAREA' || container.tagName === 'SELECT')
      ? container
      : container.querySelector('input, textarea, select');
    if (!el) continue;
    if (el.value && el.value.trim() && el.tagName !== 'SELECT' && !nativeMayCorrect(el)) continue;

    // ── Name ──
    if (/firstName|legalFirstName|legalNameSection_firstName/i.test(aid)) fillInput(el, pack.first_name);
    else if (/lastName|legalLastName|legalNameSection_lastName/i.test(aid)) fillInput(el, pack.last_name);
    // ── Email ──
    else if (/email/i.test(aid) && !/confirm|verify/i.test(aid)) fillInput(el, pack.email);
    // ── Phone (ONLY the actual number, NOT extension/device/country code) ──
    else if (/phoneNumber|phone-number/i.test(aid) && !/extension|device|type|code/i.test(aid)) fillPhoneField(el, pack.phone);
    // ── Address ──
    else if (/addressSection_addressLine1|addressLine1/i.test(aid)) {
      if (pack.address) fillInput(el, pack.address);
      // Don't fill city into address line
    }
    else if (/addressSection_city|\bcity\b/i.test(aid) && !/country/i.test(aid)) fillInput(el, loc.city);
    else if (/addressSection_countryRegion|countryDropdown|country/i.test(aid) && el.tagName === 'SELECT') {
      if (residenceCountry(pack)) selectOption(el, residenceCountry(pack));   // never assumed
    }
    else if (/addressSection_stateProvince|stateProvince|\bstate\b/i.test(aid) && !/country|united/i.test(aid)) {
      if (el.tagName === 'SELECT') { selectOption(el, loc.state) || selectOption(el, loc.abbr); }
      else fillInput(el, loc.state);
    }
    else if (/postalCode|zipCode/i.test(aid)) fillInput(el, pack.zip_code || '');
    // ── Other ──
    else if (/coverLetter|coverletterText/i.test(aid)) fillInput(el, pack.cover_letter || '');
    else if (/linkedIn|linkedin/i.test(aid)) fillInput(el, pack.linkedin_url || '');
  }

  // aria-label fallback (only for fields not already filled)
  for (const inp of document.querySelectorAll("input[aria-label], textarea[aria-label]")) {
    if (inp.value && inp.value.trim() && !nativeMayCorrect(inp)) continue;
    const lbl = (inp.getAttribute("aria-label") || "").toLowerCase();
    if (/first.*name/i.test(lbl)) fillInput(inp, pack.first_name);
    else if (/last.*name/i.test(lbl)) fillInput(inp, pack.last_name);
    else if (/\bemail\b/i.test(lbl) && !/confirm/i.test(lbl)) fillInput(inp, pack.email);
    else if (/phone.*number/i.test(lbl) && !/extension|device|country/i.test(lbl)) fillPhoneField(inp, pack.phone);
    else if (/\bcity\b/i.test(lbl) && !/country/i.test(lbl)) fillInput(inp, loc.city);
  }
  return true;
}

// ── Avature ─────────────────────────────────────────────────────────────────
// Used by Accenture, plus many large enterprises (Siemens, KPMG, etc.).
// Avature renders fields inside .avature-field / data-field wrappers and uses
// custom dropdown widgets (not native <select>).

// Detect Avature even on custom domains (Accenture, etc.) via page markers.
function isAvaturePage() {
  return !!(
    document.querySelector("[class*='avature'], [id*='avature'], [data-avature], form[action*='avature']") ||
    /avature/i.test(document.documentElement.innerHTML.slice(0, 5000))
  );
}

async function fillAvature(pack) {
  await delay(1500); // Avature hydrates fields after load

  // 1. Standard inputs — Avature uses id/name like "fieldFirstName", "txtEmail",
  //    or data-field attributes. Cover both plus label matching.
  const inputs = document.querySelectorAll(
    "input:not([type='hidden']):not([type='submit']):not([type='button']):not([type='checkbox']):not([type='radio']), textarea"
  );
  for (const inp of inputs) {
    if (inp.value && inp.value.trim() && !nativeMayCorrect(inp)) continue;
    const ctx = (
      labelText(inp) + " " +
      (inp.getAttribute("name") || "") + " " +
      (inp.id || "") + " " +
      (inp.getAttribute("data-field") || "")
    ).toLowerCase();

    if (isHowHeardQuestion(ctx)) continue;     // fillUniversal: the saved answer only
    if (/first.?name|given.?name|forename/.test(ctx)) fillInput(inp, pack.first_name);
    else if (/last.?name|family.?name|surname/.test(ctx)) fillInput(inp, pack.last_name);
    else if (/full.?name|^name$|candidate.?name/.test(ctx)) fillInput(inp, fullNameOf(pack));
    else if (/\bemail\b|e-?mail/.test(ctx)) fillInput(inp, pack.email);
    else if (/phone|mobile|telephone|contact.?number/.test(ctx)) fillPhoneField(inp, pack.phone);
    else if (/city|town|location|address|where.*based/.test(ctx)) fillInput(inp, pack.location || "");
    else if (/linkedin/.test(ctx)) fillInput(inp, pack.linkedin_url || "");
    else if (/github/.test(ctx)) fillInput(inp, pack.github_url || "");
    else if (/portfolio|personal.*site|website|personal.*url/.test(ctx)) fillInput(inp, pack.portfolio_url || "");
    else if (/cover.?letter/.test(ctx) && inp.tagName === "TEXTAREA") fillInput(inp, pack.cover_letter || "");
    else if (/years?.*experience|experience.*years?/.test(ctx)) fillInput(inp, String(pack.years_experience || ""));
    else if (/current.*title|job.*title|current.*position/.test(ctx)) fillInput(inp, pack.current_title || "");
    else if (/salary|compensation|expected.*pay/.test(ctx)) fillInput(inp, String(pack.salary_min || ""));
  }

  // 2. Native selects (EEOC / country / authorization)
  for (const sel of document.querySelectorAll("select")) {
    if (sel.value && sel.value !== "") continue;
    const ctx = (labelText(sel) + " " + (sel.getAttribute("name") || "") + " " + (sel.id || "")).toLowerCase();
    if (/gender/i.test(ctx)) fillEEOField(sel, pack.gender || 'decline', 'gender');
    else if (/race|ethnic/i.test(ctx)) fillEEOField(sel, pack.ethnicity || 'decline', 'ethnicity');
    else if (/veteran/i.test(ctx)) fillEEOField(sel, pack.veteran_status || 'decline', 'veteran');
    else if (/disability/i.test(ctx)) fillEEOField(sel, pack.disability_status || 'decline', 'disability');
    else if (/country/.test(ctx)) { if (residenceCountry(pack)) selectOption(sel, residenceCountry(pack)); }
    else if (/sponsor|visa|authoriz/.test(ctx)) answerWorkAuthField(sel, pack, ctx);
  }

  // 3. Avature custom dropdowns (div-based, role=combobox/listbox)
  for (const combo of document.querySelectorAll("[role='combobox'], .avature-select, .dropdown-trigger")) {
    const ctx = (labelText(combo) + " " + (combo.getAttribute("aria-label") || "")).toLowerCase();
    let want = null;
    const _isEEO = /gender|race|ethnic|veteran|disability/i.test(ctx);
    const _eeoVal = /gender/i.test(ctx) ? pack.gender : /race|ethnic/i.test(ctx) ? pack.ethnicity
      : /veteran/i.test(ctx) ? pack.veteran_status : pack.disability_status;
    if (_isEEO && !_eeoAutofillEnabled && !eeoStated(_eeoVal)) continue;   // voluntary self-ID — user's call
    if (/gender/i.test(ctx)) want = pack.gender || "decline";
    else if (/race|ethnic/i.test(ctx)) want = pack.ethnicity || "decline";
    else if (/veteran/i.test(ctx)) want = pack.veteran_status || "decline";
    else if (/disability/i.test(ctx)) want = pack.disability_status || "decline";
    else if (/country/.test(ctx)) want = residenceCountry(pack) || null;
    if (!want) continue;
    try {
      combo.click();
      await delay(300);
      const opts = document.querySelectorAll("[role='option'], li[role='option'], .dropdown-option");
      for (const o of opts) {
        if (o.textContent.toLowerCase().includes(want.toLowerCase())) {
          o.click();
          break;
        }
      }
      await delay(150);
    } catch (e) { /* leave for user */ }
  }

  // 4. Essay questions
  await fillEssayQuestions(document, pack);
  return true;
}

// ── Smartrecruiters ───────────────────────────────────────────────────────────

async function fillSmartrecruiters(pack) {
  const map = {
    "#first-name": pack.first_name,
    "#last-name": pack.last_name,
    "#email": pack.email,
    "#phone": pack.phone,
    "input[name='firstName']": pack.first_name,
    "input[name='lastName']": pack.last_name,
    "input[name='email']": pack.email,
    "input[name='phoneNumber']": pack.phone,
  };
  for (const [sel, val] of Object.entries(map)) {
    const el = document.querySelector(sel);
    if (el && val) fillInput(el, val);
  }
  return true;
}

// ── Generic fallback ──────────────────────────────────────────────────────────

async function fillGeneric(pack) {
  const inputs = document.querySelectorAll("input:not([type='hidden']):not([type='submit']):not([type='button']), textarea, select");
  for (const inp of inputs) {
    if (!canFillField(inp)) continue;          // hidden / captcha / honeypot
    const lbl = labelText(inp);
    if (isHowHeardQuestion(lbl)) continue;     // fillUniversal: the saved answer only
    if (/first.*name/i.test(lbl)) fillInput(inp, pack.first_name);
    else if (/last.*name/i.test(lbl)) fillInput(inp, pack.last_name);
    else if (/^(full.?)?name$/i.test(lbl)) fillInput(inp, fullNameOf(pack));
    else if (/\bemail\b/i.test(lbl)) fillInput(inp, pack.email);
    else if (/phone|mobile|tel/i.test(lbl)) fillPhoneField(inp, pack.phone);
    else if (/city|location/i.test(lbl)) { if (!isAutocompleteInput(inp)) fillInput(inp, pack.location || ""); }
    else if (/linkedin/i.test(lbl)) fillInput(inp, pack.linkedin_url || "");
    else if (/github/i.test(lbl)) fillInput(inp, pack.github_url || "");
    else if (/portfolio|personal.*site|website/i.test(lbl)) fillInput(inp, pack.portfolio_url || "");
    else if (/cover.*letter/i.test(lbl) && inp.tagName === "TEXTAREA") fillInput(inp, pack.cover_letter || "");
    else if (/year.*experience/i.test(lbl)) fillInput(inp, String(pack.years_experience || ""));
    else if (inp.tagName === "SELECT") {
      if (/hispanic|latin/i.test(lbl) && !/\brace\b|ethnic/i.test(lbl)) fillEEOField(inp, eeoValueFor(pack, 'hispanic'), 'hispanic');
      else if (/gender/i.test(lbl)) fillEEOField(inp, pack.gender || 'decline', 'gender');
      else if (/race|ethnic/i.test(lbl)) fillEEOField(inp, pack.ethnicity || 'decline', 'ethnicity');
      else if (/veteran/i.test(lbl)) fillEEOField(inp, pack.veteran_status || 'decline', 'veteran');
      else if (/disability/i.test(lbl)) fillEEOField(inp, pack.disability_status || 'decline', 'disability');
    }
  }

  if (pack && pack.ai_answers) await fillEssayQuestions(document, pack);
  return true;
}

// ── Universal signal-based filler ────────────────────────────────────────────
// Gathers every signal a field exposes and matches against canonical field types.
// Runs AFTER platform-specific handlers to catch anything they missed.

async function fillUniversal(pack) {
  // queryAllDeep, not querySelectorAll: a modern ATS (careers-page.com and
  // friends) puts the whole form inside a shadow root, where querySelectorAll
  // finds nothing — the copilot saw a page with one input and gave up.
  const inputs = queryAllDeep(
    "input:not([type='hidden']):not([type='submit']):not([type='button']):not([type='checkbox']):not([type='radio']):not([type='file']):not([type='image']), textarea, select, button[data-automation-id='select-button'], button[aria-haspopup='listbox']"
  );
  let filled = 0, attempted = 0;
  const loc = parseLocation(pack.location);

  for (const inp of inputs) {
    if (!inp.offsetParent) continue; // skip invisible
    if (!canFillField(inp)) continue; // captcha / honeypot / off-page
    
    // For buttons, treat as empty if text is placeholder
    if (inp.tagName === 'BUTTON') {
      const txt = inp.textContent ? inp.textContent.trim() : '';
      if (txt && !/select\b|choose\b|^-$|select\s+option/i.test(txt)) continue; // already filled
    } else {
      // Already filled — unless the board's own resume autofill wrote an
      // identity field, which fillInput then checks against the pack.
      if (inp.value && inp.value.trim() && inp.tagName !== 'SELECT' && !nativeMayCorrect(inp)) continue;
    }

    // Gather ALL signals into one text blob for matching
    const signals = [
      labelText(inp),
      inp.getAttribute('aria-label') || '',
      inp.getAttribute('name') || '',
      inp.id || '',
      inp.getAttribute('data-automation-id') || '',
      inp.getAttribute('data-field') || '',
      inp.getAttribute('placeholder') || '',
      inp.getAttribute('title') || '',
      inp.getAttribute('autocomplete') || '',
    ].join(' ').toLowerCase();

    if (!signals.trim()) continue;

    // An essay prompt is not a field label. Short profile scalars (company,
    // title, salary, location…) must never be written into one — the AI essay
    // path in fillEssayQuestions owns these.
    const labelOnly = labelText(inp) || '';
    const essayPrompt = looksLikeEssayPrompt(labelOnly, inp);

    // Match against canonical field types with broad regex
    // Snapshot before the branch runs so we can tell a real write from a
    // no-op (see the verified count at the bottom of the loop).
    const before = inp.tagName === 'BUTTON'
      ? (inp.textContent || '').trim()
      : String(inp.value || '').trim();
    let matched = true;

    // ── How did you hear about us: the saved profile answer, or the user ──
    // First, so no other rule writes into it ("How did you hear? (LinkedIn,
    // company website…)" matched the LinkedIn and website rules). The saved
    // answer only for how they came to THIS job; the rest of the refusal list
    // ("How did you learn Python?") is left for the applicant.
    if (isHowHeardQuestion(labelOnly) || isHowHeardQuestion(signals)) {
      matched = (isHowHeardFillQuestion(labelOnly, pack.company) ||
                 isHowHeardFillQuestion(signals, pack.company))
        ? await answerHowHeardField(inp, pack) : false;

    // ── Name ──
    } else if (/first.?name|legal.?first|given.?name|forename|\bfname\b/i.test(signals)) {
      fillInput(inp, pack.first_name);
    } else if (/last.?name|legal.?last|family.?name|surname|\blname\b/i.test(signals)) {
      fillInput(inp, pack.last_name);
    // `^name$` anchors the whole signal blob, so it never fired for a field
    // labelled just "Name" (Ashby's _systemfield_name). Check the LABEL alone
    // too — a bare "Name" label is one of the most common single-name fields.
    } else if (/full.?name|candidate.?name|^name$/i.test(signals)
               || /^\s*(full\s+)?name\s*\*?\s*$/i.test(labelOnly)
               || /(^|_)name$/i.test(inp.getAttribute('name') || '')) {
      fillInput(inp, fullNameOf(pack));

    // ── Email (not confirm/verify fields) ──
    } else if (/\bemail\b|e.?mail/i.test(signals) && !/confirm|verify|re.?enter/i.test(signals)) {
      fillInput(inp, pack.email);

    // ── Phone (ONLY actual phone number fields) ──
    // Exclude: extension, device type, country code, phone type
    } else if (/phone.?number|mobile.?number|\btel\b|telephone.?number|contact.?number|cell.?number/i.test(signals)
               && !/extension|ext\b|device|type|country.*code|phone.*code/i.test(signals)) {
      fillPhoneField(inp, pack.phone);
    // Broader phone match but still exclude extension/device/code
    } else if (/\bphone\b|\bmobile\b|\btelephone\b/i.test(signals)
               && !/extension|ext\b|device|type|country.*code|phone.*code|phone.*type/i.test(signals)
               && inp.tagName !== 'SELECT') {
      fillPhoneField(inp, pack.phone);

    // ── URLs ──
    } else if (/linkedin/i.test(signals)) {
      fillInput(inp, pack.linkedin_url || '');
    } else if (/github/i.test(signals)) {
      fillInput(inp, pack.github_url || '');
    } else if (/portfolio|personal.?site|personal.?url|personal.?website/i.test(signals)) {
      fillInput(inp, pack.portfolio_url || '');
    } else if (/website|web.?site|homepage/i.test(signals) && !/linkedin|github/i.test(signals)) {
      fillInput(inp, pack.portfolio_url || '');

    // ── City (parsed from location, not the full "Cincinnati, OH" string) ──
    } else if (/\bcity\b|\btown\b/i.test(signals) && !essayPrompt && !/country/i.test(signals)) {
      // An autocomplete commits only a picked suggestion (Ashby's Location).
      if (isAutocompleteInput(inp)) await fillLocationCombobox(inp, pack);
      else fillInput(inp, loc.city);
    // Location/where-based fields get the full location
    } else if (/location|where.*based|where.*live|current.?city/i.test(signals) && !essayPrompt && !/country/i.test(signals)) {
      if (isAutocompleteInput(inp)) await fillLocationCombobox(inp, pack);
      else fillInput(inp, pack.location || '');

    // ── State (parsed from location) ──
    } else if (/\bstate\b|\bprovince\b|\bregion\b/i.test(signals) && !/country|united/i.test(signals)) {
      if (inp.tagName === 'SELECT') {
        selectOption(inp, loc.state) || selectOption(inp, loc.abbr);
      } else {
        fillInput(inp, loc.state);
      }

    // ── Address (only if pack has actual street address, NOT location fallback) ──
    } else if (/address.?line.?1|street.?address|mailing.?address/i.test(signals)) {
      if (pack.address) fillInput(inp, pack.address);
      else matched = false; // don't put city in address field
    // Word-bounded on purpose: bare /unit/ matched "United States", so
    // "Are you legally authorized to work in the United States?" — the most
    // common work-auth phrasing there is — was classified as address-line-2
    // and skipped on every form. Same trap for /apt/ in "adapt".
    } else if (/address.?line.?2|\bapt\b|\bapartment\b|\bsuite\b|\bunit\b/i.test(signals)) {
      matched = false; // never auto-fill address line 2

    // ── Other fields ──
    } else if (/cover.?letter/i.test(signals) && inp.tagName === 'TEXTAREA') {
      fillInput(inp, pack.cover_letter || '');
    } else if (/years?.*(of\s+)?experience|how.*(many|much).*experience|experience.*years?/i.test(signals)
               && !/start.*date|end.*date|\bdate\b|\bmonth\b|\byear\b/i.test(signals)) {
      // Total tenure only for a GENERIC question: "years of Rust" is not it.
      if (yearsQuestionIsGeneric(labelOnly || inp.getAttribute('aria-label') || '')) {
        fillInput(inp, String(pack.years_experience || ''));
      } else {
        matched = false;
      }
    } else if (/current.?title|job.?title|current.?position|current.?role/i.test(signals) && !essayPrompt) {
      fillInput(inp, pack.current_title || '');
    } else if (/company|employer|organization/i.test(signals) && !essayPrompt
               && !/start.*date|end.*date|\bdate\b|\bmonth\b|\byear\b/i.test(signals)) {
      fillInput(inp, currentEmployer(pack));
    } else if (/salary|compensation|expected.?pay|desired.?pay/i.test(signals) && !essayPrompt) {
      fillInput(inp, String(pack.salary_min || ''));
    } else if (/\bcountry\b/i.test(signals) && inp.tagName === 'SELECT') {
      // Residence country, stated by the user — never assumed (a Toronto
      // profile was told it lives in the United States).
      matched = !!residenceCountry(pack) && !!selectOption(inp, residenceCountry(pack));
    } else if (/hispanic|latin/i.test(signals) && !/\brace\b|ethnic/i.test(signals)) {
      matched = fillEEOField(inp, eeoValueFor(pack, 'hispanic'), 'hispanic');
    } else if (/gender/i.test(signals)) {
      matched = fillEEOField(inp, pack.gender || 'decline', 'gender');
    } else if (/race|ethnic/i.test(signals)) {
      matched = fillEEOField(inp, pack.ethnicity || 'decline', 'ethnicity');
    } else if (/veteran/i.test(signals)) {
      matched = fillEEOField(inp, pack.veteran_status || 'decline', 'veteran');
    } else if (/disability/i.test(signals)) {
      matched = fillEEOField(inp, pack.disability_status || 'decline', 'disability');
    } else if (/sponsor|visa|authoriz/i.test(signals)) {
      matched = answerWorkAuthField(inp, pack, signals);
    } else if (/postal|zip.?code/i.test(signals)) {
      fillInput(inp, pack.zip_code || '');
    } else {
      matched = false;
    }

    // Count only what LANDED. This used to be `if (matched) filled++`, i.e. a
    // count of branches that ran — so a pack full of undefined reported
    // "filled 13 additional fields" over a completely empty form.
    if (matched) {
      const after = inp.tagName === 'BUTTON'
        ? (inp.textContent || '').trim()
        : String(inp.value || '').trim();
      if (after && after !== before) {
        filled++;
        console.log('[SpotApply] Universal filled:', signals.slice(0, 60));
      } else if (_lastWriteSkippedEmpty) {
        // Matched a rule, but the profile has nothing for it. Expected, quiet.
        console.debug('[SpotApply] No profile value for:', signals.slice(0, 60));
      } else if (_lastWriteKept) {
        // The board's own resume autofill already filled it. Expected, quiet.
        console.debug('[SpotApply] Kept the value the site filled from the resume:', signals.slice(0, 60));
      } else {
        attempted++;
        console.warn('[SpotApply] Matched but nothing landed:', signals.slice(0, 60));
      }
    }
  }

  if (attempted > 0) {
    console.warn(`[SpotApply] ${attempted} field(s) matched a rule but stayed empty ` +
                 '(missing profile data, or the site rejected the write)');
  }
  return filled;
}

// ── Cross-form learning: observe & recall ────────────────────────────────────
// When a field is yellow (couldn't auto-fill) and the user types into it,
// observeField() saves the answer on blur, keyed by the field's label.
// On the NEXT form, recallFromMemory() retrieves past answers and auto-fills.

/**
 * The field holds what SpotApply wrote (fillInput records it), not the
 * user's words. fillInput fires blur and change itself, so a box filled after
 * a learner started watching it taught memory our own write (review 2026-10-09).
 */
function _holdsOurWrite(el) {
  const w = el && el.dataset ? el.dataset.spotapplyLastWrite : undefined;
  return w !== undefined && String(el.value || '').trim() === String(w).trim();
}

function observeField(el, pack) {
  if (!packBase(pack) || !pack.auth_token) return;
  if (isAntiBotField(el)) return;               // never learn a captcha / honeypot
  if (el.dataset.spotapplyObserved) return; // already watching
  el.dataset.spotapplyObserved = 'true';

  let saved = false;
  const save = () => {
    if (saved) return;
    const val = el.value?.trim();
    if (!val) return;
    // Our own write is not the user's answer, and an Other box we filled for
    // how they heard is part of that answer: never learned.
    if (_holdsOurWrite(el) || el.dataset.spotapplyHowHeard === 'true') return;
    const label = getFieldSignature(el);
    if (!label || label.length < 3) return;

    // Don't save standard profile fields or extensions — those come from the profile/direct matches
    if (/first.?name|last.?name|email|phone|mobile|linkedin|github|extension|ext\b/i.test(label)) return;
    // Don't save calendar date fields (excluding years of experience etc.)
    if (/year|month|day|date|\bmm\b|\byyyy\b|\bdd\b/i.test(label) && !/experience/i.test(label)) return;
    // Never remember protected self-identification answers.
    if (isDemographicQuestion(label + ' ' + (labelText(el) || ''))) return;
    // Nor how they heard about one job: only the profile's answer is ever used.
    if (isHowHeardQuestion(label + ' ' + (labelText(el) || ''))) return;

    console.log('[SpotApply] Learning field:', label, '->', val.slice(0, 40));
    saved = true;
    apiFetch(`${packBase(pack)}/api/save-answer`, 'POST', pack.auth_token, {
      question: label,
      answer: val,
      app_id: pack.app_id || null,
    });
    // Update highlight to green since user filled it
    highlightField(el, 'green');
  };

  // Not { once: true }: our own write's synthetic blur/change must not use up
  // the listener the user's answer needs.
  el.addEventListener('blur', save);
  el.addEventListener('change', save);
}

// Build a stable signature for a field from all its signals
function getFieldSignature(el) {
  return [
    labelText(el),
    el.getAttribute('aria-label') || '',
    el.getAttribute('placeholder') || '',
    el.getAttribute('name') || '',
  ].filter(Boolean).join(' | ').toLowerCase().trim();
}

async function recallFromMemory(root, pack) {
  if (!packBase(pack) || !pack.auth_token) return 0;

  // Collect labels of all empty visible fields
  const emptyFields = Array.from(root.querySelectorAll(
    'input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="file"]):not([type="checkbox"]):not([type="radio"]), textarea, select, button[data-automation-id="select-button"], button[aria-haspopup="listbox"]'
  )).filter(el => {
    if (!el.offsetParent) return false;
    if (!canFillField(el)) return false;
    // An autocomplete box commits only a picked suggestion; typed text from
    // memory would sit there uncommitted (and be cleared on blur).
    if (isAutocompleteInput(el)) return false;
    if (el.tagName === 'BUTTON') {
      const txt = el.textContent ? el.textContent.trim() : '';
      return !txt || /select\b|choose\b|^-$|select\s+option/i.test(txt);
    }
    return !el.value || !el.value.trim();
  });

  if (!emptyFields.length) return 0;

  const fieldLabels = emptyFields.map(el => getFieldSignature(el)).filter(l => l && l.length >= 3);
  if (!fieldLabels.length) return 0;

  // Ask the backend for any previously learned answers
  const res = await apiFetch(
    `${packBase(pack)}/api/recall-answers`,
    'POST', pack.auth_token,
    { labels: fieldLabels }
  );

  if (!res.ok || !res.data || !res.data.answers) {
    // Stay quiet once we've already surfaced the expired-session notice — the
    // 401 here is just a downstream symptom of that, not a separate problem.
    if (!_authExpired) {
      console.log('[SpotApply] recall-answers: no data or endpoint not available');
    }
    return 0;
  }

  let recalled = 0;
  const answers = res.data.answers; // { "label": "value", ... }

  for (const el of emptyFields) {
    const sig = getFieldSignature(el);
    if (!sig) continue;

    // Ignore calendar date fields in cross-form memory recall
    if (/year|month|day|date|\bmm\b|\byyyy\b|\bdd\b/i.test(sig) && !/experience/i.test(sig)) continue;
    // Protected self-identification: a remembered answer is NOT consent. Only
    // the direct EEO path (fillEEOField) may write these, and only when the
    // user switched it on (audit 2026-09-30: recall set Gender with it OFF).
    const fullLabel = sig + ' ' + (labelText(el) || '');
    if (isDemographicQuestion(fullLabel)) continue;
    // Work authorization / sponsorship have ONE interpreter, fed by the
    // current profile — an answer remembered from another form (or another
    // visa status) must not override it.
    if (/sponsor|authoriz|visa|work permit|right to work/i.test(fullLabel)) continue;
    // How the applicant heard about THIS job: their saved profile answer only
    // (fillUniversal), never one remembered from another form.
    if (isHowHeardQuestion(fullLabel)) continue;

    // Exact question first. A fuzzy match only when nearly all its words
    // agree: "> 0.4" put one question's answer into a different question.
    let answer = answers[sig];
    if (!answer) {
      for (const [key, val] of Object.entries(answers)) {
        if (isDemographicQuestion(key)) continue;
        if (keywordOverlap(sig, key) >= 0.8) { answer = val; break; }
      }
    }

    if (answer) {
      if (answer.trim() === pack.phone && /extension|ext\b/i.test(sig)) {
        // Skip filling phone number into extension fields
        continue;
      }
      fillInput(el, answer);
      console.log('[SpotApply] Recalled from memory:', sig.slice(0, 50), '->', answer.slice(0, 30));
      recalled++;
    }
  }

  return recalled;
}

// ── API helper ──────────────────────────────────────────────────────────────────
// Routes through the background service worker to bypass CORS (content-script
// fetches run in the page origin and get blocked).
// Set once the session token has expired (a 401 from any authed endpoint).
// The fill pack snapshots a single Supabase access token when the user clicks
// "Fill" on the dashboard; it is reused for the whole copilot session and is
// never refreshed, so once it expires EVERY authed call (resume, recall-answers,
// save-answer, answer-question) can only 401. Without this guard the extension
// silently re-hits those endpoints on every page/step, flooding the console.
let _authExpired = false;
let _expiredToken = null;

function notifyAuthExpired(token, res) {
  _expiredToken = token || _expiredToken;
  if (_authExpired) return;
  _authExpired = true;
  // The background worker tells us WHY it couldn't refresh, so the page console
  // shows the actionable cause (no need to open the service-worker console).
  if (res && res.refreshAvailable === false) {
    console.warn(
      "[SpotApply] Session expired AND the fill pack carried no refresh token, so " +
      "the access token can't be renewed. The SpotApply dashboard (server) must be " +
      "redeployed with refresh-token support; then click Fill again."
    );
  } else if (res && res.refreshFailed) {
    console.warn(
      "[SpotApply] Session expired and the refresh token was rejected (it likely " +
      "expired too). Log in again on the SpotApply dashboard, then click Fill."
    );
  } else {
    console.warn(
      "[SpotApply] Session token expired (401). Pausing authed API calls. " +
      "Re-trigger 'Fill' from the SpotApply dashboard to refresh your session."
    );
  }
  try {
    showOverlay(
      "🔒 <b>SpotApply session expired</b><br>" +
      "<small>Your login timed out, so saved answers & tailored-resume upload are paused. " +
      "Go back to the SpotApply dashboard and click <b>Fill</b> again to refresh — " +
      "fields already filled on this page stay filled.</small>",
      [], true
    );
  } catch (e) {}
}

let _lastAuthProbe = 0;

function apiFetch(url, method, token, body) {
  // Once the token has expired, short-circuit authed requests so we don't spam
  // endpoints that can only 401 — but let ONE probe through every 30s: the
  // background worker may have refreshed the token in the meantime, and a
  // succeeding probe lifts the latch (see the out.ok handler below).
  if (_authExpired && token) {
    const now = Date.now();
    if (now - _lastAuthProbe < 30000) {
      return Promise.resolve({ ok: false, status: 401, error: "session expired" });
    }
    _lastAuthProbe = now;
  }
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(
        { type: "API_FETCH", payload: { url, method, token, body } },
        (res) => {
          if (chrome.runtime.lastError) {
            resolve({ ok: false, error: chrome.runtime.lastError.message });
          } else {
            const out = res || { ok: false, error: "no response" };
            if (out.status === 401 && token) notifyAuthExpired(token, out);
            // Self-heal: if a later authed call succeeds (background refreshed
            // the token, or the user logged back in), lift the expired latch so
            // resume upload / saved answers resume without a full re-Fill.
            if (out.ok && token && _authExpired) {
              console.log('[SpotApply] Authed call succeeded again — clearing expired-session latch');
              _authExpired = false;
              _expiredToken = null;
              try { removeOverlay(); } catch (e) {}
            }
            resolve(out);
          }
        }
      );
    } catch (e) {
      resolve({ ok: false, error: e.message });
    }
  });
}

// ── Essay answer filling ───────────────────────────────────────────────────────
// Strategy: cached answers (free) first, then on-demand AI per question (~$0.002
// first time only). Never pre-generates — only calls AI for questions that actually
// appear on THIS form.

async function fillEssayQuestions(root, pack) {
  const textareas = Array.from(root.querySelectorAll("textarea")).filter(ta => {
    if (ta.value && ta.value.trim()) return false; // already filled
    // Never a hidden, captcha or honeypot textarea: Ashby's reCAPTCHA response
    // field was asked about by its name and got an AI reply typed into it.
    if (!canFillField(ta)) return false;
    const q = labelText(ta);
    if (looksLikeFieldIdentifier(q)) return false; // its name, not a question
    return q && q.length >= 8; // skip tiny/unlabeled textareas
  });

  if (!textareas.length) return;

  for (const ta of textareas) {
    const q = labelText(ta);
    // Protected self-identification and work authorization are never
    // AI-written: the first needs consent, the second has ONE interpreter.
    // How the applicant heard about the role is a fact only they hold: their
    // saved profile answer fills it (fillUniversal), never the AI.
    if (isDemographicQuestion(q) || /sponsor|authoriz|visa status|work permit/i.test(q)) continue;
    if (isHowHeardQuestion(q)) continue;
    if (ta.dataset.spotapplyUserModified === 'true') continue;

    // 1. Check pre-cached answers from fill-pack (free, no API call)
    let answer = null;
    if (pack.ai_answers) {
      answer = pack.ai_answers[q];
      if (!answer) {
        for (const [key, val] of Object.entries(pack.ai_answers)) {
          if (keywordOverlap(q, key) > 0.4) { answer = val; break; }
        }
      }
    }

    // 2. If not cached, call /api/answer-question on-demand (~$0.002, cached after)
    let generated = false;
    if (!answer && packBase(pack) && pack.auth_token && pack.app_id) {
      const res = await apiFetch(
        `${packBase(pack)}/api/answer-question`,
        "POST",
        pack.auth_token,
        { question: q, app_id: pack.app_id }
      );
      if (res.ok && res.data) {
        answer = res.data.answer || null;
        // A server too old to name its source may have just generated it.
        generated = !res.data.source || res.data.source === 'generated';
        if (answer) console.log(`[SpotApply] AI answered "${q.slice(0, 60)}…" (cached=${res.data.cached})`);
        else if (res.data.refused) console.log(`[SpotApply] Left for you (${res.data.refused}):`, q.slice(0, 60));
      } else {
        console.warn("[SpotApply] answer-question failed:", res.error || res.status);
      }
    }

    // A reply about the question ("I'd be happy to help, but…") is not an answer.
    // What a model just wrote gets the full test; a remembered answer may be the
    // user's own words, so only the forms a model alone writes are dropped.
    if (answer && (generated ? looksLikeMetaReply(answer) : looksLikeModelOnlyReply(answer))) {
      console.warn('[SpotApply] Discarded a reply that is not an answer for:', q.slice(0, 60));
      answer = null;
    }
    if (answer) fillInput(ta, answer);

    // 3. Always observe — if user edits, save their answer to memory
    observeAnswer(ta, pack);
  }
}

function keywordOverlap(a, b) {
  const stopWords = new Set(['do','you','want','to','the','a','an','is','are','your','this','that','at','for','in','of','and','or','why','what','how','tell','us','about']);
  const wordsA = a.toLowerCase().split(/\W+/).filter(w => w.length > 2 && !stopWords.has(w));
  const wordsB = b.toLowerCase().split(/\W+/).filter(w => w.length > 2 && !stopWords.has(w));
  if (!wordsA.length || !wordsB.length) return 0;
  const setA = new Set(wordsA);
  const matches = wordsB.filter(w => setA.has(w)).length;
  return matches / Math.max(wordsA.length, wordsB.length);
}

function observeAnswer(ta, pack) {
  if (!packBase(pack) || !pack.auth_token) return;
  if (isAntiBotField(ta)) return;               // a captcha token is not an answer
  const origValue = ta.value;
  ta.addEventListener('blur', function handler() {
    const newVal = ta.value.trim();
    if (!newVal || newVal === origValue.trim()) return;
    // A later write of ours (an Other box for how they heard) is not the
    // user's answer, and that box is never learned at all.
    if (_holdsOurWrite(ta) || ta.dataset.spotapplyHowHeard === 'true') return;
    const q = labelText(ta);
    if (!q) return;
    ta.removeEventListener('blur', handler);
    apiFetch(`${packBase(pack)}/api/save-answer`, 'POST', pack.auth_token,
      { question: q, answer: newVal, app_id: pack.app_id });
    console.log('[SpotApply] Saved answer for:', q);
  });
}

// ── Resume file attachment ──────────────────────────────────────────────────────
// Fetches the tailored resume (base64: the one-page PDF, or the .docx when the
// field does not take PDF) via the background worker and sets it on the resume
// file input using a synthetic DataTransfer.
// Returns true when the resume is handled (attached now, or already present),
// false when we tried and couldn't — so the caller retries on a later pass
// instead of wrongly marking it "done".
async function attachResume(root, pack) {
  if (!packBase(pack) || !pack.auth_token || !pack.app_id) return false;

  // The server already told us the resume cannot be built until the user fixes
  // something. Hammering the endpoint three times a page and then failing
  // silently is exactly what made "resume never attaches" so hard to see.
  if (_resumeBlockedReason) {
    setResumeStatus('error', '', '', _resumeBlockedReason);
    showOverlay(
      `📎 <b>Resume not attached</b><br><small style="color:#c4b5fd;font-weight:400">${_resumeBlockedReason}</small>`,
      [], true);
    return false;
  }

  // Include shadow-DOM inputs — some ATS widgets bury the real <input> there.
  const allFileInputs = queryAllDeep('input[type="file"]', root);
  if (!allFileInputs.length) return false; // form may render the field later

  // Field scope and upload markers are shared with the native autofill layer
  // (module-level helpers below); the names here are the ones this function
  // has always used.
  const hasUploadedMarker = _hasUploadedMarker;
  const isUploaded = (fi) => (fi.files && fi.files.length) || hasUploadedMarker(fi);

  // "Autofill from resume" widgets were a TRAP for THIS path. Ashby (and
  // others) put an optional parser upload next to the real Resume field; its
  // container also says "resume", so it matched, we attached to both AFTER
  // filling, and the parser then re-read the .docx and OVERWROTE the identity
  // we had just written — same form, two runs, two different applicants.
  // runNativeAutofill now feeds such a widget FIRST (before any field is
  // written) and the fill afterwards corrects it; by the time this function
  // runs, a widget it used already holds the file and is skipped as uploaded.
  // The penalty below is for the fallback: native autofill off, or a board
  // the native layer does not trust yet — then the parser stays a poor choice.
  const isParserWidget = (fi) => {
    const scope = fi.closest('div, section, fieldset, form');
    const text = ((labelText(fi) || '') + ' ' + (fi.getAttribute('aria-label') || '') + ' ' +
                  (scope ? (scope.textContent || '').slice(0, 400) : '')).toLowerCase();
    return /autofill|auto-fill|fill (?:it |this |the form )?(?:in |out )?(?:from|with)|parse|prefill|pre-fill|populate (?:the )?(?:form|fields)/.test(text);
  };

  // Only skip a parser widget when there is a REAL resume input to use
  // instead. On Rippling the dropzone IS the resume field (and it renders two
  // inputs for the one dropzone), so blanket-skipping parsers meant the
  // required resume never attached at all — trading one failure for another.
  // Pick exactly ONE input to attach to, by SCORING every unattached file
  // input rather than filtering first. The filter-then-pick version could
  // eliminate everything and return silently: on Rippling the dropzone renders
  // two inputs, one looked like a parser so it was skipped, and the other had a
  // generic name and a wrapper div with no "Resume" text — so it matched none
  // of the resume tests, candidates came back empty, and the required upload
  // never happened with no log line either way.
  const resumeCtx = _resumeCtx;

  // Walk several ancestors, not just the immediate div — the "Resume *" label
  // usually sits a couple of levels above the input inside a dropzone.
  const scopeSaysResume = (fi) => {
    let node = fi.parentElement;
    for (let i = 0; node && i < 4; i++, node = node.parentElement) {
      if (saysResume((node.textContent || '').slice(0, 400))) return true;
    }
    return false;
  };

  // A control that asks for a DIFFERENT document is never the résumé — not
  // even as the page's only upload (audit 2026-09-30: the single-input
  // fallback put the résumé into a field labelled "Cover letter").
  const otherDocument = (fi) => {
    const own = resumeCtx(fi);
    if (saysResume(own)) return false;
    let near = '';
    let node = fi.parentElement;
    for (let i = 0; node && i < 3 && near.length < 300; i++, node = node.parentElement) {
      near = (node.textContent || '').slice(0, 300);
      if (saysResume(near)) return false;
      if (_OTHER_DOC_RE.test(near)) return true;
    }
    return _OTHER_DOC_RE.test(own);
  };
  const available = allFileInputs.filter((fi) => !isUploaded(fi) && !otherDocument(fi));
  const scored = available.map((fi) => {
    let s = 0;
    if (saysResume(resumeCtx(fi))) s += 4;
    else if (scopeSaysResume(fi)) s += 3;
    if (isFieldRequired(fi)) s += 2;
    // A parser upload is a poor choice, never an impossible one — on Rippling
    // the dropzone IS the resume field and its copy mentions autofill. The
    // penalty must stay SMALLER than the resume signal, or it cancels it out
    // exactly and the required upload is skipped (which is what happened).
    if (isParserWidget(fi)) s -= 2;
    return { fi, s };
  }).sort((a, b) => b.s - a.s);

  let targets = [];
  if (!scored.length) {
    console.log('[SpotApply] No unattached file input on this page');
  } else if (scored[0].s > 0) {
    targets = [scored[0].fi];
    if (scored.length > 1) {
      console.log(`[SpotApply] Resume target chosen (score ${scored[0].s}) from ` +
                  `${scored.length} file inputs`);
    }
  } else if (available.length === 1) {
    targets = [available[0]];
    console.log('[SpotApply] Single unlabelled file input — treating it as the resume');
  } else {
    // Never fail silently: say which inputs were seen and why none was used.
    console.warn('[SpotApply] Could not identify the resume field among',
                 available.length, 'file inputs —',
                 available.map((fi) => fi.name || fi.id || '(unnamed)').join(', '));
  }

  // Nothing left to attach → done only if something is genuinely uploaded.
  if (!targets.length) return allFileInputs.some(isUploaded);

  // Tell the server what the field takes: it answers with the one-page PDF
  // (the owner's delivered resume) unless the field rules PDF out, then Word.
  // ALWAYS sent ("*" when the field names nothing), so the server can tell
  // this build from the 1.0.0 Store build, which sends no accept at all.
  // ONE download per application and accept, shared with the native autofill
  // layer: the same base64 document goes into whichever control takes it.
  const _accept = String(targets[0].getAttribute('accept') || '').trim() || '*';
  const got = await fetchResumeFile(pack, _accept);
  if (!got.ok) {
    if (got.reason === 'decode_failed') {
      console.warn("[SpotApply] resume decode failed:", got.error);
      reportTelemetry(pack, 'resume_attach_failed', { reason: 'decode_failed' });
      return false;
    }
    // Surface WHY to the user — a silent console.warn here was the main way
    // "resume is not uploading" reports happened with no visible explanation.
    console.warn("[SpotApply] resume fetch failed:", got.status, got.error || '');
    setResumeStatus('error', '', '', got.hint);
    showOverlay(
      `📎 Resume not attached.<br><small style="color:#c4b5fd;font-weight:400">${got.hint}</small>`,
      [], true
    );
    reportTelemetry(pack, 'resume_attach_failed', { reason: got.reason, status: got.status });
    return false;
  }

  const { filename, mime, kind, notice, file } = got;
  if (document.body.innerText.includes(filename)) {
    setResumeStatus('accepted', filename, kind, notice);
    return true; // already on the page
  }

  // The form's own accepted formats: a PDF-only field must not be given a
  // DOCX it will reject (audit 2026-09-30).
  const refused = targets.filter((fi) => !fileMatchesAccept(fi, filename, mime));
  if (refused.length === targets.length) {
    const want = (targets[0].getAttribute('accept') || '').replace(/\s+/g, ' ');
    targets.forEach((fi) => { fi.dataset.spotapplyUpload = 'wrong_format'; });
    setResumeStatus('wrong_format', filename, kind,
      `This form accepts only ${want || 'another format'}; your ${kind} resume is ${filename}. ` +
      'Download it in an accepted format from SpotApply and attach it here.');
    reportTelemetry(pack, 'resume_attach_failed', { reason: 'format_not_accepted' });
    return false;
  }
  targets = targets.filter((fi) => fileMatchesAccept(fi, filename, mime));

  let domSet = false;
  for (const fi of targets) {
    if (fi.dataset.spotapplyUserModified === 'true') continue;   // the user's own file
    if (setFileOnInput(fi, file)) domSet = true;
  }
  if (!domSet) {
    setResumeStatus('failed', filename, kind, '');
    showResumeHint(filename);
    reportTelemetry(pack, 'resume_attach_failed', { reason: 'dom_set_failed' });
    return false;
  }

  // Some ATS (e.g. Ashby drop-zones) silently ignore a programmatically-set
  // file, and others (Greenhouse, Workday) upload it over the network before
  // rendering the file chip — that round-trip regularly takes 1–3s+. Poll up
  // to 6s for evidence the UI registered it instead of a single 800ms check
  // that produced false "attach manually" prompts on slow uploads.
  const registered = await (async () => {
    const deadline = Date.now() + 6000;
    while (Date.now() < deadline) {
      if (document.body.innerText.includes(filename)) return true;
      if (targets.some(hasUploadedMarker)) return true;
      await delay(500);
    }
    return false;
  })();
  if (registered) {
    // `tailored` is false both when the user chose their original resume in
    // Settings and when a tailored draft was withheld, so say which file went
    // in rather than always claiming "tailored".
    console.log(`[SpotApply] Attached ${kind} resume:`, filename);
    targets.forEach((fi) => { fi.dataset.spotapplyUpload = 'accepted'; });
    setResumeStatus('accepted', filename, kind, notice);
    reportTelemetry(pack, 'resume_attached', { source: kind });
    return true;
  }
  // The file is in the input, but the uploader never acknowledged it: that is
  // NOT an attached résumé, and the field audit must not count it as one.
  targets.forEach((fi) => { fi.dataset.spotapplyUpload = 'unconfirmed'; });
  setResumeStatus('unconfirmed', filename, kind, '');
  console.warn("[SpotApply] Resume set but the form didn't register it — asking user to attach manually.");
  showResumeHint(filename);
  reportTelemetry(pack, 'resume_attach_failed', { reason: 'not_registered' });
  return false;
}

// Documents that are not a résumé, by their upload label.
const _OTHER_DOC_RE = /cover.?letter|portfolio|transcript|writing.?sample|work.?sample|reference.?letter|letter of recommendation|certificat|diploma|\bid\b card|photo|headshot/i;

/** Does the input's accept="…" allow this file? No accept = anything. */
function fileMatchesAccept(fi, filename, mime) {
  const accept = String(fi.getAttribute('accept') || '').trim();
  if (!accept) return true;
  const name = String(filename || '').toLowerCase();
  const type = String(mime || '').toLowerCase();
  return accept.split(',').map((a) => a.trim().toLowerCase()).filter(Boolean).some((a) => {
    if (a === '*' || a === '*/*') return true;          // the server's _accept_allows reads these the same
    if (a.startsWith('.')) return name.endsWith(a);
    if (a.endsWith('/*')) return type.startsWith(a.slice(0, -1));
    return type === a;
  });
}

// The résumé's state on this page, kept until it changes so a recount of the
// fields can never wipe an actionable message (a 422's "add your work history"
// used to vanish on the next status refresh).
let _resumeStatus = null;
function setResumeStatus(state, filename, kind, message) {
  _resumeStatus = { state, filename: filename || '', kind: kind || '', message: message || '' };
}

// Non-blocking nudge when we can't auto-attach the resume (custom uploaders).
function showResumeHint(filename) {
  showOverlay(
    `📎 Please attach your resume.<br><small style="color:#c4b5fd;font-weight:400">This site's upload box blocks auto-attach. Click its upload button and pick your file${filename ? `: <b>${filename}</b>` : ''}.</small>`,
    [], true
  );
}

// ── Resume document: one download, two takers ───────────────────────────────
// attachResume and runNativeAutofill put the SAME file into different
// controls, so the download and the decode live here and the result is kept
// for the application: the second taker never re-fetches, and a failure is
// explained once, by attachResume, which owns the user-facing messages.
let _resumeFileCache = null;

/**
 * The applicant's resume for this application as a File, or why not:
 * { ok, filename, mime, kind, notice, file } / { ok: false, status, reason, hint, error }.
 */
async function fetchResumeFile(pack, accept) {
  const appId = pack && pack.app_id;
  const _acc = String(accept || '*');
  if (_resumeFileCache && _resumeFileCache.ok && _resumeFileCache.app_id === appId &&
      _resumeFileCache.accept === _acc) return _resumeFileCache;
  const res = await apiFetch(
    `${packBase(pack)}/api/fill-pack/${appId}/resume?accept=${encodeURIComponent(_acc)}`,
    "GET", pack.auth_token, null
  );
  if (!res.ok || !res.data || !res.data.base64) {
    const status = res.status || 0;
    let reason, hint;
    if (status === 401) {
      reason = 'auth_expired';
      hint = "Your SpotApply login timed out. Open the dashboard, sign in, then click Fill again.";
    } else if (status === 422) {
      // Not transient — the server is telling us exactly what the profile is
      // missing. Show that instead of retrying into the void, and stop trying.
      reason = 'profile_incomplete';
      hint = (res.data && res.data.detail) ||
             "Your profile is missing information needed to build a resume.";
      _resumeBlockedReason = hint;
    } else if (status === 503) {
      reason = 'tailoring_failed';
      hint = "Your tailored resume isn't generated yet. Open this application on the SpotApply dashboard, generate the resume, then return here.";
    } else {
      reason = 'fetch_failed';
      hint = "Couldn't download your resume from SpotApply (network/server). I'll keep retrying — you can also attach it manually.";
    }
    return { ok: false, status, reason, hint, error: res.error || '' };
  }
  const { filename, mime, base64 } = res.data;
  const kind = res.data.tailored === false ? "original" : "tailored";
  // The server substituted the base resume (tailoring limit, a withheld
  // draft): say so instead of attaching it silently.
  const notice = res.data.notice ? String(res.data.notice) : '';
  let file;
  try {
    const bin = atob(base64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    file = new File([bytes], filename, { type: mime });
  } catch (e) {
    return { ok: false, status: res.status || 200, reason: 'decode_failed', hint: '', error: e.message };
  }
  _resumeFileCache = { ok: true, app_id: appId, accept: _acc, filename, mime, kind, notice, file };
  return _resumeFileCache;
}

/** Put a File into a file input the way a user's pick would arrive: the files
 *  list, then input + change so the site's uploader notices. True if it took. */
function setFileOnInput(fi, file) {
  try {
    const dt = new DataTransfer();
    dt.items.add(file);
    fi.files = dt.files;
    fi.dispatchEvent(new Event("input", { bubbles: true }));
    fi.dispatchEvent(new Event("change", { bubbles: true }));
    return !!(fi.files && fi.files.length);
  } catch (e) {
    console.warn("[SpotApply] Could not set file input:", e.message);
    return false;
  }
}

// The "field-sized" container around a control: the nearest ancestor small
// enough to plausibly be this one field's wrapper. The old broad
// closest('div,section,fieldset') matched page-level wrappers, so a Remove
// button on an unrelated field (education entry, cover letter) marked the
// resume as already-uploaded and it was silently skipped forever. A wider
// block holding a SECOND file input is another field's, so the walk stops.
function _fileFieldScope(el) {
  let n = el.parentElement, best = el.parentElement, depth = 0;
  while (n && depth < 6) {
    if ((n.textContent || '').length > 600) break;
    if (depth > 0 && n.querySelectorAll('input[type="file"]').length > 1) break;
    best = n;
    n = n.parentElement; depth++;
  }
  return best;
}

/** Has the site's uploader acknowledged a file in this field (a Remove/Delete
 *  control or a success note beside it)? */
function _hasUploadedMarker(fi) {
  const c = _fileFieldScope(fi);
  return !!(c && (
    c.querySelector('[data-automation-id*="delete" i], button[aria-label*="delete" i], [aria-label*="remove" i]') ||
    /successfully uploaded/i.test(c.textContent || '')
  ));
}

/** Everything a file input is named by — label, name, id, aria, automation id. */
function _resumeCtx(fi) {
  return (labelText(fi) + " " + (fi.name || "") + " " + (fi.id || "") + " " +
          (fi.getAttribute("aria-label") || "") + " " +
          (fi.getAttribute("data-automation-id") || "")).toLowerCase();
}

// ── Native autofill: the board's own "autofill from resume" goes first ───────
// Several boards parse the uploaded resume and fill the application
// themselves: Workday's "Autofill with Resume", Ashby's autofill card,
// SmartRecruiters' "Autofill from resume", Lever's parsing upload, newer
// Greenhouse forms. Where one is offered it is used FIRST — it builds the
// multi-entry history sections this filler cannot — and only once it has
// settled does fillCurrentPage fill what it left empty or got wrong. Feeding
// such a widget AFTER our fill was the Ashby incident (the parser rewrote the
// identity we had just written), so this layer owns the ordering.
//
// Nothing here submits or advances a page: the human reviews and clicks.
//
// Boards whose native autofill is trusted. A board not listed takes the normal
// path even when its page says "autofill": the label matcher below is
// deliberately permissive, this gate is not.
const NATIVE_AUTOFILL_ATS = new Set(['workday', 'greenhouse', 'lever', 'ashby', 'smartrecruiters']);

// A control is native autofill only when its wording ties a resume/CV to the
// act of filling or parsing — "Autofill with Resume", "Upload your resume to
// prefill the form", "we'll parse your CV". A plain "Upload resume", "Attach
// resume/CV" or "Resume/CV *" is an ordinary upload and never matches, nor
// does an "autofill" with no resume in the same sentence (Chrome's own, a
// footnote). One line: tests/test_extension_rules.py extracts it by statement.
const _NATIVE_AUTOFILL_RE = /\b(?:auto-?fill|pre-?fill|pre-?populate|populate|pars(?:e|es|ed|ing)|fill(?:\s+(?:it|this|the\s+form|in|out))*\s+(?:from|with|using))\w*\b[^.!?]{0,80}?\b(?:resume|cv|curriculum vitae)\b|\b(?:resume|cv|curriculum vitae)\b[^.!?]{0,80}?\b(?:auto-?fill|pre-?fill|pre-?populate|populate|pars(?:e|es|ed|ing)|fill(?:\s+(?:it|this|the\s+form|in|out))*\s+(?:from|with|using))/i;

// The applicant's own details: the ONE class of field a wrong parse may be
// corrected in, because the pack is their canonical data. Everything else the
// parser read (company, title, dates, history entries) is theirs to review.
const _NATIVE_AUTOFILL_IDENTITY = new Set(['first_name', 'last_name', 'full_name', 'email', 'phone', 'linkedin', 'location']);

// How long the board gets to parse: quiet for `quietMs` with no spinner, at
// least `minMs` in all (an upload round-trip precedes any parsing, and a form
// that has not changed yet is not a form that is done), never past `maxMs`.
const _NATIVE_SETTLE = { quietMs: 1500, minMs: 2500, maxMs: 20000 };

let _nativeAutofillOnPage = null;    // location.href the layer already ran on
let _nativeAutofillOutcome = null;   // what happened on this page (reply + telemetry)
let _nativePrefillActive = false;    // the board filled from the resume: fill only empty/conflicting
let _nativeChooserPending = null;    // { ats, ts } after we clicked a chooser option

/** True when the wording offers to fill or parse the application FROM a resume. */
function nativeAutofillLabelMatches(text) {
  const t = deaccent(String(text || '')).replace(/\s+/g, ' ').trim();
  return !!t && _NATIVE_AUTOFILL_RE.test(t);
}

/** One comparable form of a value, by the kind of field that holds it. */
function _normValue(kind, v) {
  const s = deaccent(String(v == null ? '' : v)).toLowerCase().trim();
  if (kind === 'phone') {
    const d = s.replace(/\D/g, '');
    // A national number and the same number with its +1 are one number.
    return d.length === 11 && d.startsWith('1') ? d.slice(1) : d;
  }
  if (kind === 'email') return s;
  if (kind === 'linkedin' || kind === 'url') {
    return s.replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/[?#].*$/, '').replace(/\/+$/, '');
  }
  return s.replace(/[^\p{L}\p{N}@+.]+/gu, ' ').replace(/\s+/g, ' ').trim();
}

/** Do two values say the same thing, allowing for formatting? A location is
 *  the same place at a coarser grain too: a City field the board filled with
 *  "San Francisco" is not in conflict with the pack's "San Francisco, CA". */
function valuesEquivalent(kind, a, b) {
  const x = _normValue(kind, a), y = _normValue(kind, b);
  if (!x || !y) return false;
  if (x === y) return true;
  if (kind === 'location') return (' ' + x + ' ').includes(' ' + y + ' ') || (' ' + y + ' ').includes(' ' + x + ' ');
  return false;
}

/**
 * After the board's own autofill: write `wanted` over `current`? An empty
 * field is filled; one that already says the same thing is kept, in the
 * board's own formatting; a DIFFERENT value is corrected only when the field
 * is the applicant's identity (_NATIVE_AUTOFILL_IDENTITY) — a wrong parse of
 * their own email is wrong, a parsed company is theirs to review.
 */
function shouldOverwrite(kind, current, wanted) {
  const want = String(wanted == null ? '' : wanted).trim();
  if (!want) return false;
  const cur = String(current == null ? '' : current).trim();
  if (!cur) return true;
  if (valuesEquivalent(kind, cur, want)) return false;
  return _NATIVE_AUTOFILL_IDENTITY.has(String(kind || ''));
}

/**
 * Which of the applicant's own details a field holds — first_name, last_name,
 * full_name, email, phone, linkedin, location — or null for anything else. A
 * field inside a work-history or education entry is never identity: that
 * entry's "Location" is the job's, and the entry is the parser's work.
 */
function identityKindOf(el) {
  if (!el || !el.getAttribute) return null;
  try {
    if (el.closest('[data-automation-id*="workExperience" i], [data-automation-id*="education" i], ' +
                   '[data-automation-id*="-item" i], [class*="experience" i], [class*="education" i], ' +
                   '[class*="work-history" i], [class*="employment" i]')) return null;
  } catch (_) {}
  const type = String(el.getAttribute('type') || '').toLowerCase();
  if (type === 'email') return 'email';
  if (type === 'tel') return 'phone';
  // Ids and automation ids join words with "_" and "-", which \b treats as
  // word characters: "addressSection_city" must still read as "city".
  const sig = [labelText(el), el.getAttribute('aria-label'), el.getAttribute('name'), el.id,
               el.getAttribute('data-automation-id'), el.getAttribute('placeholder'),
               el.getAttribute('autocomplete')]
    .filter(Boolean).join(' ').toLowerCase().replace(/[_\-]+/g, ' ');
  if (!sig.trim()) return null;
  if (/first.?name|legal.?first|given.?name|forename|\bfname\b/.test(sig)) return 'first_name';
  if (/last.?name|legal.?last|family.?name|surname|\blname\b/.test(sig)) return 'last_name';
  if (/full.?name|candidate.?name|legal.?name|(^|[\s|])name([\s*|]|$)/.test(sig)) return 'full_name';
  if (/\bemail\b|\be[\s-]?mail\b/.test(sig) && !/confirm|verify|re.?enter/.test(sig)) return 'email';
  if (/\bphone\b|\bmobile\b|\btelephone\b|\btel\b/.test(sig) && !/extension|\bext\b|device|type|code/.test(sig)) return 'phone';
  if (/linkedin/.test(sig)) return 'linkedin';
  if (/\bcity\b|\btown\b|\blocation\b|where.*(based|live)|\baddress\b|\bstate\b|\bprovince\b|postal|\bzip\b/.test(sig)) return 'location';
  return null;
}

/** May a non-empty field be re-checked against the pack? Only after the
 *  board's own autofill, and only an identity field (fillInput then decides). */
function nativeMayCorrect(el) {
  return _nativePrefillActive && identityKindOf(el) !== null;
}

/** Which board renders this page, for the native-autofill gate: by host, else
 *  by the vendor's own markup (custom career domains), else 'generic'. */
function nativeAutofillAts() {
  const h = location.hostname;
  if (hostIs(h, 'myworkdayjobs.com') || hostIs(h, 'workday.com') || hostIs(h, 'myworkdaysite.com')) return 'workday';
  if (hostIs(h, 'greenhouse.io')) return 'greenhouse';
  if (hostIs(h, 'lever.co')) return 'lever';
  if (hostIs(h, 'ashbyhq.com')) return 'ashby';
  if (hostIs(h, 'smartrecruiters.com')) return 'smartrecruiters';
  const has = (sel) => { try { return !!document.querySelector(sel); } catch (_) { return false; } };
  if (has('[data-automation-id="legalNameSection"], [data-automation-id="autofillWithResume"], ' +
          '[data-automation-id="bottom-navigation-next-button"], [data-automation-id="file-upload-input-ref"]')) return 'workday';
  if (has('input[name^="_systemfield_"], [data-ashby-id], [class*="ashby-" i]')) return 'ashby';
  if (has('form#application_form, input[name^="job_application["], iframe[src*="greenhouse.io"]')) return 'greenhouse';
  if (has('input[name="urls[LinkedIn]"], form.application-form input[name="resume"]')) return 'lever';
  return 'generic';
}

/** Is the element, or the field around it, drawn on the page? A file input is
 *  usually visually hidden behind a styled button, so its surroundings decide. */
function _renderedNear(el) {
  if (!el) return false;
  try {
    if (el.offsetParent !== null || (el.getClientRects && el.getClientRects().length)) return true;
    let node = el.parentElement;
    for (let depth = 0; node && depth < 6; depth++, node = node.parentElement) {
      if (node.getClientRects && node.getClientRects().length) return true;
    }
  } catch (_) {}
  return false;
}

/** The wording a file input is presented with: its own label and attributes
 *  plus the field-sized block around it — never the whole form, whose other
 *  fields would bleed into the match. */
function _nativeWidgetText(fi) {
  const parts = [labelText(fi), fi.getAttribute('aria-label'), fi.getAttribute('title'),
                 fi.getAttribute('placeholder'), fi.name, fi.id];
  const scope = _fileFieldScope(fi);
  if (scope) parts.push((scope.textContent || '').slice(0, 600));
  return parts.filter(Boolean).join(' ');
}

/**
 * The board's own autofill-from-resume control on this page, or null:
 * { ats, kind: 'input' | 'button', element, input, via }.
 *   input  — a file input whose wording (or vendor attribute) says the upload
 *            fills the application; the resume goes straight into it.
 *   button — an option that reveals the upload (Workday's "Autofill with
 *            Resume"); `input` is a file input already beside it, if any.
 * Stable vendor attributes decide first, then visible wording near a file
 * input or on a button (nativeAutofillLabelMatches). A plain resume upload
 * with no such wording is NOT native autofill — attachResume owns those.
 */
function detectNativeAutofill() {
  const ats = nativeAutofillAts();
  const ours = (el) => { try { return !!el.closest('[id^="hp-"], [id^="spotapply-"]'); } catch (_) { return false; } };
  const fileInputs = queryAllDeep('input[type="file"]').filter((fi) =>
    !ours(fi) && !(fi.files && fi.files.length) && fi.dataset.spotapplyNativeTried !== 'true');
  const asInput = (fi, via) => ({ ats, kind: 'input', element: fi, input: fi, via });
  // The option that reveals or starts the flow: vendor attribute first, then
  // wording on a button or link (a chooser option, not a paragraph).
  const findButton = () => {
    const byAttr = queryAllDeep(
      '[data-automation-id="autofillWithResume"], #resume_autofill, [data-autofill-resume], ' +
      'button[data-testid*="autofill" i], button[name*="autofill" i]'
    ).find((el) => !ours(el) && _renderedNear(el) && !(el.tagName === 'INPUT' && el.type === 'file'));
    if (byAttr) return byAttr;
    return queryAllDeep('button, a, [role="button"]').find((el) => {
      if (ours(el) || !_renderedNear(el) || el.tagName === 'INPUT' || el.closest('label')) return false;
      const text = (el.textContent || '') + ' ' + (el.getAttribute('aria-label') || '');
      return text.trim().length <= 80 && nativeAutofillLabelMatches(text);
    }) || null;
  };
  // An upload that is not displayed yet is reached through the option that
  // reveals it, when there is one — that click is what a user does, and some
  // widgets only start parsing once their flow was chosen (Workday).
  const viaButtonIfHidden = (fi, via) => {
    if (fi.offsetParent !== null) return asInput(fi, via);
    const btn = findButton();
    return btn ? { ats, kind: 'button', element: btn, input: fi, via } : asInput(fi, via);
  };
  const withNearbyInput = (el) => {
    // A file input the option controls, or one inside its own block, is the
    // upload it would reveal — set directly if the click does not show it.
    let input = null;
    try {
      const controls = el.getAttribute('aria-controls');
      const target = controls && document.getElementById(controls);
      if (target) input = target.matches('input[type="file"]') ? target : target.querySelector('input[type="file"]');
      if (!input) {
        const scope = _fileFieldScope(el);
        input = (scope && Array.from(scope.querySelectorAll('input[type="file"]'))
          .find((f) => !(f.files && f.files.length))) || null;
      }
    } catch (_) {}
    return { ats, kind: 'button', element: el, input, via: 'label' };
  };

  // 0. A chooser option we clicked moments ago (Workday): the upload that
  //    followed IS the autofill upload, whatever the page around it says.
  if (_nativeChooserPending && Date.now() - _nativeChooserPending.ts < 120000) {
    const fi = fileInputs.find(_renderedNear);
    if (fi) return asInput(fi, 'chooser');
  }

  // 1. Vendor attributes.
  const attrInput = fileInputs.find((fi) => /autofill|auto-fill|prefill|pre-fill|parse/i.test(
    [fi.name, fi.id, fi.getAttribute('data-automation-id'), fi.getAttribute('data-testid'),
     fi.getAttribute('aria-label')].filter(Boolean).join(' ')));
  if (attrInput) return viaButtonIfHidden(attrInput, 'attribute');
  if (ats === 'lever') {
    // Lever parses whatever lands in its resume field and fills the form from
    // it: the upload IS the autofill, so it goes in before any field is written.
    const fi = fileInputs.find((f) => f.name === 'resume' && _renderedNear(f));
    if (fi) return asInput(fi, 'attribute');
  }

  // 2. Wording near a file input.
  for (const fi of fileInputs) {
    if (!_renderedNear(fi)) continue;
    if (_OTHER_DOC_RE.test(_resumeCtx(fi))) continue;
    if (nativeAutofillLabelMatches(_nativeWidgetText(fi))) return viaButtonIfHidden(fi, 'label');
  }

  // 3. The option alone (a chooser with no upload on this page yet).
  const btn = findButton();
  if (btn) return withNearbyInput(btn);
  return null;
}

/** A click a React/Workday button recognises: pointer events, then click(). */
function _pressElement(el) {
  try { if (el.focus) el.focus(); } catch (_) {}
  for (const type of ['mousedown', 'mouseup']) {
    try { el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window })); } catch (_) {}
  }
  try { el.click(); } catch (_) {}
}

/** After clicking an autofill option: the file input it revealed — new on the
 *  page, or newly drawn — within `maxMs`; a known hidden one after a grace
 *  (a hidden input still takes a file; the click may only have styled it). */
async function _waitForRevealedFileInput(before, wasShown, known, maxMs) {
  const start = Date.now();
  while (Date.now() - start < maxMs) {
    await delay(200);
    const now = queryAllDeep('input[type="file"]').filter((fi) => !(fi.files && fi.files.length));
    const fresh = now.find((fi) => !before.has(fi) && _renderedNear(fi));
    if (fresh) return fresh;
    const shown = now.find((fi) => before.has(fi) && !wasShown.get(fi) && fi.offsetParent !== null);
    if (shown) return shown;
    if (known && Date.now() - start >= 1500 && document.contains(known)) return known;
  }
  return null;
}

/** Values of every text-like control, to measure what the site's autofill wrote. */
function _fieldValueSnapshot() {
  const m = new Map();
  for (const el of queryAllDeep('input, textarea, select')) {
    if (['file', 'hidden', 'submit', 'button', 'checkbox', 'radio', 'image'].includes(el.type)) continue;
    m.set(el, String(el.value || '').trim());
  }
  return m;
}

/** Controls empty (or absent) before and holding a value now. */
function _countPrefilled(before) {
  let n = 0;
  for (const [el, v] of _fieldValueSnapshot()) if (v && !(before.get(el) || '')) n++;
  return n;
}

/** Everything a parser could change, as one string: values, files, checks. */
function _formStateSignature() {
  const parts = [];
  for (const el of queryAllDeep('input, textarea, select')) {
    if (el.type === 'file') parts.push('f' + (el.files ? el.files.length : 0));
    else if (el.type === 'checkbox' || el.type === 'radio') parts.push(el.checked ? '1' : '0');
    else parts.push(String(el.value || ''));
  }
  return parts.length + '|' + parts.join('\u0001');
}

// What a board shows while it parses: ARIA busy/progress, a spinner or
// loading class that is actually drawn, or "Parsing…"/"Uploading…" copy inside
// the widget's own block. Any of them means more changes are coming.
const _BUSY_SEL = '[aria-busy="true"], [role="progressbar"], [class*="spinner" i], [class*="loading" i], ' +
                  '[data-automation-id*="loading" i], [data-automation-id*="progress" i]';
function _pageLooksBusy(widget) {
  try {
    if (document.body.getAttribute('aria-busy') === 'true') return true;
    const drawn = (el) => el !== document.body && !el.closest('[id^="hp-"]') &&
      (el.offsetParent !== null || (el.getClientRects && el.getClientRects().length));
    if (queryAllDeep(_BUSY_SEL).some(drawn)) return true;
    // innerText, not textContent: a "Parsing…" note that is display:none is
    // not showing, and reading it as busy held the wait to its 20 s cap.
    const scope = widget && _fileFieldScope(widget);
    return !!scope && /\b(parsing|uploading|processing|importing|reading your)\b/i.test(String(scope.innerText || '').slice(0, 600));
  } catch (_) {
    return false;
  }
}

/** Wait until the board has stopped changing the form (see _NATIVE_SETTLE). */
async function _waitForNativeAutofillToSettle(widget, { quietMs, minMs, maxMs }) {
  const start = Date.now();
  let last = _formStateSignature(), lastChange = start;
  for (;;) {
    await delay(250);
    const now = Date.now();
    const sig = _formStateSignature();
    if (sig !== last) { last = sig; lastChange = now; }
    if (_pageLooksBusy(widget)) lastChange = now;
    if (now - start >= maxMs) return { ms: now - start, timedOut: true };
    if (now - start >= minMs && now - lastChange >= quietMs) return { ms: now - start, timedOut: false };
  }
}

/** The outcome in the shape every DO_FILL reply and telemetry event carries. */
function nativeAutofillOutcome() {
  const o = _nativeAutofillOutcome || {};
  return {
    ats: o.ats || nativeAutofillAts(),
    used: o.used === true,
    reason: o.reason || 'not_run',
    settled_ms: o.settled_ms || 0,
    fields_prefilled: o.fields_prefilled || 0,
  };
}

/**
 * Use the board's own autofill-from-resume, once per page, BEFORE our fill:
 * detect it, feed it the same resume document attachResume would attach,
 * wait for the parse to settle, and record what happened. Reasons:
 *   disabled · ats_not_enabled · no_widget · resume_unavailable ·
 *   input_not_revealed · format_not_accepted · user_file · dom_set_failed ·
 *   no_response (took the file, changed nothing) · settled · settled_timeout.
 * Sets _nativePrefillActive when the board did fill something, which switches
 * fillInput to "only empty or conflicting" for the rest of this application.
 */
async function runNativeAutofill(pack) {
  const pageKey = location.href;
  if (_nativeAutofillOnPage === pageKey) return nativeAutofillOutcome();
  _nativeAutofillOnPage = pageKey;
  const ats = nativeAutofillAts();
  const done = (fields, widgetKind) => {
    _nativeAutofillOutcome = Object.assign(
      { ats, used: false, reason: 'no_widget', settled_ms: 0, fields_prefilled: 0 }, fields);
    const o = nativeAutofillOutcome();
    if (widgetKind) {
      // Only a page that OFFERED a widget is worth a server-side event; the
      // event name carries the verdict (a *_failed event is passed=false).
      reportTelemetry(pack, o.used ? 'native_autofill_used' : 'native_autofill_failed',
                      Object.assign({ kind: widgetKind }, o));
      console.log(`[SpotApply] Native autofill (${o.ats}): ${o.reason}` +
                  (o.used ? ` — the site filled ${o.fields_prefilled} field(s) in ${o.settled_ms} ms` : ''));
    } else {
      console.debug(`[SpotApply] Native autofill (${o.ats}): ${o.reason}`);
    }
    return o;
  };

  if (!_nativeAutofillEnabled) return done({ reason: 'disabled' });
  if (!NATIVE_AUTOFILL_ATS.has(ats)) return done({ reason: 'ats_not_enabled' });
  const widget = detectNativeAutofill();
  if (!widget) return done({ reason: 'no_widget' });
  if (!packBase(pack) || !pack.auth_token || !pack.app_id || _resumeBlockedReason) {
    return done({ reason: 'resume_unavailable' }, widget.kind);
  }

  showOverlay('⚡ <b>Using the site\'s own resume autofill first</b><br>' +
              '<small>Your SpotApply resume is going in. Anything it misses gets filled right after.</small>',
              [], false);

  const got = await fetchResumeFile(pack);
  if (!got.ok) return done({ reason: 'resume_unavailable' }, widget.kind);   // attachResume explains why

  // The upload control: offered outright, or revealed by the option we click.
  let input = widget.kind === 'input' ? widget.input : null;
  if (!input) {
    const before = new Set(queryAllDeep('input[type="file"]'));
    const wasShown = new Map(Array.from(before).map((fi) => [fi, fi.offsetParent !== null]));
    _pressElement(widget.element);
    input = await _waitForRevealedFileInput(before, wasShown, widget.input, 8000);
    if (!input) {
      // The option may have navigated instead (Workday: a sign-in, or its
      // upload step): the next page's detection takes over via this flag.
      _nativeChooserPending = { ats, ts: Date.now() };
      return done({ reason: 'input_not_revealed' }, widget.kind);
    }
  }
  _nativeChooserPending = null;
  input.dataset.spotapplyNativeTried = 'true';
  if (input.dataset.spotapplyUserModified === 'true') return done({ reason: 'user_file' }, widget.kind);
  if (!fileMatchesAccept(input, got.filename, got.mime)) return done({ reason: 'format_not_accepted' }, widget.kind);

  // Is this upload also the application's resume field? Workday: yes, the one
  // upload. Ashby: a parser card beside the real Resume field — when another
  // upload on the page is named "resume", THAT is the application's resume
  // and this widget only reads the file.
  const others = queryAllDeep('input[type="file"]').filter((fi) => fi !== input);
  const namedResume = (fi) => saysResume(_resumeCtx(fi)) ||
    saysResume(((_fileFieldScope(fi) || {}).textContent || '').slice(0, 400));
  const isResumeField = !others.some(namedResume) && (namedResume(input) || others.length === 0);
  const snapshot = _fieldValueSnapshot();
  if (!setFileOnInput(input, got.file)) return done({ reason: 'dom_set_failed' }, widget.kind);

  const settle = await _waitForNativeAutofillToSettle(input, _NATIVE_SETTLE);
  const prefilled = _countPrefilled(snapshot);
  const registered = prefilled > 0 || document.body.innerText.includes(got.filename) || _hasUploadedMarker(input);

  if (!registered) {
    // It took the file and nothing happened. The resume field keeps the file
    // and the audit asks the user to confirm it, as attachResume would; a
    // separate parser is emptied again so attachResume still reaches the
    // real resume field — never a file stranded in a widget that ignored it.
    if (isResumeField) {
      input.dataset.spotapplyUpload = 'unconfirmed';
      setResumeStatus('unconfirmed', got.filename, got.kind, '');
    } else {
      try { input.value = ''; } catch (_) {}
    }
    return done({ reason: 'no_response', settled_ms: settle.ms }, widget.kind);
  }

  _nativePrefillActive = true;
  if (isResumeField) {
    input.dataset.spotapplyUpload = 'accepted';
    setResumeStatus('accepted', got.filename, got.kind, got.notice);
    _resumeAttachedOnPage = pageKey;              // attachResume: nothing left to do here
    reportTelemetry(pack, 'resume_attached', { source: got.kind, via: 'native_autofill' });
  }
  return done({ used: true, reason: settle.timedOut ? 'settled_timeout' : 'settled',
                settled_ms: settle.ms, fields_prefilled: prefilled }, widget.kind);
}

// ── Router ────────────────────────────────────────────────────────────────────
// Copilot mode: fill what we can, highlight gaps in yellow, wait for user
// to click Next, then repeat on the next page. User interaction at every step.

let _copilotActive = false;
let _copilotPack = null;
let _fillingInProgress = false;
let _resumeAttachedOnPage = null;
// True when the last fillInput bailed because the pack had no value for it.
let _lastWriteSkippedEmpty = false;
// True when the last write was withheld because the board's own resume
// autofill had already filled the field (see runNativeAutofill).
let _lastWriteKept = false;
// Set when the server says the resume can't be built for a reason the user must
// fix (422). Retrying is pointless until they do, so we stop and keep saying why.
let _resumeBlockedReason = null;
let _lastFillTimestamp = 0;

/**
 * Fill this page for the application in ``fillPack``. Returns what actually
 * happened — the popup and the DO_FILL reply show it, so an aborted fill is
 * never reported as "Done".
 */
async function fillForm(fillPack) {
  if (!HP_FRAME_ACTIVE) return { ok: false, reason: 'inactive frame' }; // all_frames: true
  let pack = fillPack;

  // LinkedIn + Indeed: hands-off, always. Their native apply flows pre-fill
  // from the user's own account, and automating their pages violates their
  // terms — risking the USER'S account. We open the job and track the
  // application; the user picks their resume and clicks through natively.
  // (If the posting redirects to a company ATS, the copilot fills there.)
  if (/(^|\.)(linkedin|indeed)\.com$/i.test(window.location.hostname)) {
    const site = /indeed/i.test(window.location.hostname) ? 'Indeed' : 'LinkedIn';
    console.log(`[SpotApply] ${site} page — staying hands-off (native apply pre-fills)`);
    try {
      showOverlay(
        `💼 <b>${site} application</b><br>` +
        `<small>${site} fills your details from your ${site} account automatically — ` +
        'just choose your resume and click through. SpotApply stays hands-off here to ' +
        'keep your account safe, and will still track this application. If the job ' +
        'redirects to a company site, SpotApply auto-fills there as usual.</small>',
        [], true
      );
    } catch (e) {}
    return { ok: false, handsOff: true, reason: `${site} is filled by ${site} itself` };
  }

  // A fresh token means the user re-triggered "Fill" from the dashboard after a
  // timeout — clear the expired-session guard so authed calls resume.
  if (fillPack?.auth_token && fillPack.auth_token !== _expiredToken) {
    _authExpired = false;
  }

  // Try to fetch the latest pack from the API to pick up any profile/db changes
  let refreshNote = '';
  if (pack && packBase(pack) && pack.auth_token && pack.app_id) {
    const res = await apiFetch(
      `${packBase(pack)}/api/fill-pack/${pack.app_id}`,
      "GET", pack.auth_token, null
    );
    if (res.ok && res.data) {
      const fresh = res.data;
      // One-click submit is approved ONCE, by the dashboard click (?submit=1),
      // and the server reserved the day's allowance then. This routine refresh
      // is a plain GET, so it answers "not_requested" — carry the click's
      // verdict over. A real refusal (kill switch, setting turned off since)
      // is honoured: only "not_requested" is the artefact of the refresh.
      if (fillPack && fillPack.auto_submit === true && fresh.auto_submit !== true &&
          fresh.auto_submit_reason === 'not_requested' &&
          String(fillPack.app_id) === String(fresh.app_id)) {
        fresh.auto_submit = true;
        fresh.auto_submit_reason = fillPack.auto_submit_reason || 'ok';
        if (!Array.isArray(fresh.auto_submit_hosts) || !fresh.auto_submit_hosts.length) {
          fresh.auto_submit_hosts = Array.isArray(fillPack.auto_submit_hosts) ? fillPack.auto_submit_hosts : [];
        }
      }
      pack = fresh;
    } else if (res.timedOut) {
      // Keep going with what we have, and say so — never a silent stall.
      refreshNote = 'SpotApply was slow to answer, so this fill uses the details you opened the job with.';
      console.warn('[SpotApply] fill-pack refresh timed out — filling from the launch pack');
    }
  }

  // HARD STOP on a pack with no profile data. Filling from one wrote the string
  // "undefined undefined" into name fields and left everything else blank while
  // still reporting success — the worst outcome for an apply tool, because a
  // user trusting the green badge submits a blank application. Say what is
  // wrong instead of writing garbage.
  if (!packIsFillable(pack)) {
    console.warn('[SpotApply] Fill aborted — pack carries no profile data:', _packSummary(pack));
    try {
      showOverlay(
        '⚠️ <b>SpotApply isn\'t connected to this job</b><br>' +
        '<small>No profile data reached the extension, so nothing was filled. ' +
        'Open this job from your SpotApply dashboard and click <b>Auto-Fill &amp; Apply</b> ' +
        '(or use <b>Fill This Form Now</b> in the extension popup).</small>',
        [], true
      );
    } catch (e) {}
    return { ok: false, aborted: true, reason: 'No profile data reached the extension — nothing was filled.' };
  }

  _copilotPack = pack;
  _copilotActive = true;
  _lastUrl = location.href;

  // Bind THIS tab to the application so it survives navigations in this tab
  // (and only this tab). Resumed by the load handler below.
  chromeCall(() => chrome.runtime.sendMessage({ type: 'BIND_THIS_TAB', pack }, () => {
    void chrome.runtime.lastError;
  }));

  // Decide: are we on a real application FORM, or just a job description page?
  // A description page (e.g. accenture.com/.../jobdetails) has search boxes and
  // cookie inputs but no application fields — so we must find & click Apply first.
  if (!hasApplicationForm()) {
    // A challenge or a sign-in BEFORE the form is the site's own step: hand it
    // to the human (overlay + telemetry → dashboard bell) and press nothing.
    // Clicking "Apply" here used to skip the handoff entirely.
    if (isCaptcha() || isLoginWall()) {
      const paused = await runCopilotStep();
      return paused || { ok: true, state: 'waiting' };
    }
    findAndClickApply(pack);
    return { ok: true, state: 'opening_form', reason: 'Looking for the application form on this page.' };
  }
  const result = await runCopilotStep();
  if (result && refreshNote) result.note = refreshNote;
  return result || { ok: true, state: 'waiting' };
}

// True only if the page looks like an actual application form (not a JD page).
function hasApplicationForm() {
  // Shadow-DOM aware throughout — a form rendered inside a shadow root is
  // still an application form, and querySelectorAll cannot see it.
  if (queryAllDeep("input[type='email'], input[type='file']").length) return true;
  // A captcha's hidden response textarea sits on job DESCRIPTION pages too; it
  // is not an application field.
  const named = queryAllDeep(
    "input[name*='first' i], input[name*='last' i], input[name*='name' i]," +
    "input[id*='first' i], input[id*='last' i], textarea"
  ).filter((el) => !isAntiBotField(el));
  if (named.length >= 2) return true;
  // Fallback: many visible text inputs usually means a form
  const visibleText = queryAllDeep("input[type='text'], input:not([type])")
    .filter(el => el.offsetParent !== null || (el.getClientRects && el.getClientRects().length));
  return visibleText.length >= 3;
}

// ── Step runner ───────────────────────────────────────────────────────────────

async function runCopilotStep() {
  if (!HP_FRAME_ACTIVE) return; // inert in non-ATS iframes (all_frames: true)
  if (!_copilotActive || !_copilotPack) return;
  // Prevent re-entrant calls (MutationObserver can fire during fill)
  if (_fillingInProgress) {
    console.log('[SpotApply] runCopilotStep skipped — fill already in progress');
    return;
  }
  const pack = _copilotPack;

  // Detect login wall or CAPTCHA — pause and guide user. Both are HANDOFFS to
  // the human, never worked around: the extension fills the account email on
  // a sign-in / create-account page (passwords stay with Chrome), names the
  // verification code the site emailed, and tells the dashboard (telemetry →
  // notification) so a user who switched tabs learns the form is waiting.
  // A verification-code page has no password box, so it is not a "wall" by
  // the rule above — but it is still the site's own step, not a form of ours:
  // one code field and no application form = hand it to the human.
  const codeField = verificationCodeField();
  if (isLoginWall() || (codeField && !hasApplicationForm())) {
    const code = codeField;
    const emailed = prefillAccountEmail(pack);
    if (code) {
      showOverlay('📬 <b>Enter the verification code</b><br><small>' + escapeHtml(location.hostname) +
                  ' emailed you a code — check your inbox (and spam), paste it here, and I\'ll continue once you\'re in.</small>', [], false);
      reportHandoff(pack, 'verification_code_needed', {});
    } else {
      showOverlay('🔐 <b>Sign in or create your account to continue</b><br><small>' +
                  (emailed ? 'Your email is filled in; ' : '') +
                  'passwords stay with Chrome (use its "suggest strong password"). I\'ll auto-resume once you\'re in.</small>', [], false);
      reportHandoff(pack, 'login_needed', { email_prefilled: emailed ? 'yes' : 'no' });
    }
    watchForFormAppearance();
    return { ok: true, state: 'waiting', paused: code ? 'verification_code' : 'login',
             reason: code ? 'Waiting for the verification code the site emailed you.' : 'Waiting for you to sign in.' };
  }
  if (isCaptcha()) {
    showOverlay('🤖 Please solve the CAPTCHA.<br><small>I\'ll continue automatically after.</small>', [], false);
    reportHandoff(pack, 'captcha_needed', {});
    watchForFormAppearance();
    return { ok: true, state: 'waiting', paused: 'captcha', reason: 'Waiting for you to solve the CAPTCHA.' };
  }

  // Lock to prevent re-entrant calls
  _fillingInProgress = true;
  try {
    // The board's own resume autofill goes FIRST, when it offers one: it fills
    // whole history sections we cannot, and feeding it AFTER our fill is how a
    // parser once overwrote the identity we had just written. Once it has
    // settled, fillCurrentPage only fills what it left empty or got wrong.
    try {
      await runNativeAutofill(pack);
    } catch (e) {
      console.warn('[SpotApply] native autofill error:', e.message);
    }

    // Run the fill
    const result = await fillCurrentPage(pack);
    showStepOverlay(result, pack);

    // Attach resume once per page — but only mark it done when the attach
    // ACTUALLY succeeded, so a failed/blocked attach retries on the next pass
    // instead of falsely logging "already attached".
    const pageKey = location.href;
    if (_resumeAttachedOnPage !== pageKey) {
      try {
        const attached = await attachResume(document, pack);
        if (attached) _resumeAttachedOnPage = pageKey;
      } catch (e) {
        console.warn('[SpotApply] attachResume error:', e.message);
      }
    } else {
      console.log('[SpotApply] Resume already attached on this page, skipping');
    }
  } finally {
    _fillingInProgress = false;
    _lastFillTimestamp = Date.now();
  }

  // The resume attach and the AI essay answers finish AFTER the first overlay
  // render, so recount now that everything has landed — and keep it live while
  // the user works through the yellow fields.
  const finalResult = refreshStepOverlay(pack);
  startStatusRefresh(pack);

  // One-click submit: the server said this click approved the submission
  // (pack.auto_submit). Press the form's own Submit only when the audit above
  // left nothing for the user; otherwise stop and say what needs them.
  let autoSubmit = null;
  if (pack && pack.auto_submit) {
    try {
      autoSubmit = await maybeAutoSubmit(pack, finalResult);
    } catch (e) {
      console.warn('[SpotApply] one-click submit error:', e.message);
      autoSubmit = { requested: true, attempted: false, reason: 'error' };
    }
  }

  // Watch for user advancing to next page
  watchForPageAdvance(pack);
  return summarizeStep(finalResult, autoSubmit);
}

/** The DO_FILL reply / popup message: counts, never an unconditional "Done". */
function summarizeStep(r, autoSubmit) {
  // Whether the board's own resume autofill was used on this page travels
  // with every reply, so the dashboard can measure how often it is offered,
  // taken and useful (fields_prefilled) without a second round-trip.
  const native = nativeAutofillOutcome();
  const auto = autoSubmit || { requested: false, attempted: false, reason: 'not_requested' };
  if (!r) return { ok: true, state: 'filled', native_autofill: native, auto_submit: auto };
  return {
    ok: true,
    state: auto.attempted ? 'submitting' : (r.needUser || r.failed ? 'needs_review' : 'ready_for_review'),
    filled: r.filled || 0,
    needUser: r.needUser || 0,
    failed: r.failed || 0,
    problems: (r.problems || []).slice(0, 6),
    native_autofill: native,
    auto_submit: auto,
  };
}

// ── One-click submit ──────────────────────────────────────────────────────────
// Founder decision 2026-10-11 (docs/AUTO_APPLY_RESEARCH.md §5). The dashboard's
// "Apply & Submit" click is the user's approval of ONE application; the server
// turned it into pack.auto_submit after its own checks (setting on, login-free
// allow-list, daily cap). This layer presses the form's own Submit button —
// the same control the user would click — and only when nothing is left for
// a human: no sign-in wall, no visible CAPTCHA, no unfilled required field,
// browser validation satisfied. Everything else is a HANDOFF: the tab stays
// open with the overlay naming what is missing, and the dashboard is told.
// The attempt itself goes through noteSubmitAttempt, so "Submitted" is still
// only ever written on the employer's confirmation page or the user's Yes.
function escapeHtml(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
}
const AUTO_SUBMIT_BLOCK_TEXT = {
  host_not_allowed: 'this site is not on the one-click list',
  different_page: 'this page is not the job you approved',
  login_wall: 'the site asks you to sign in',
  captcha: 'the site shows a CAPTCHA',
  fields_need_you: 'some fields still need your answer',
  no_submit_button: 'no Submit button was found on this page',
  submit_disabled: 'the Submit button is disabled',
  validation: 'the site rejected a field',
  cancelled_by_user: 'you stopped it',
  already_attempted: 'it was already submitted from this tab',
};
const _autoSubmitDone = new Set();

/** A challenge the one-click gate must stop at. isCaptcha() is page-level and
 * answers false whenever an application form is present, so it cannot see a
 * checkbox or image challenge sitting INSIDE the form (Greenhouse's visual
 * reCAPTCHA, Lever's hCaptcha). This looks at the widgets themselves: a
 * visible widget container or challenge frame, or the board's own "complete
 * the CAPTCHA" error. The hidden iframes Ashby embeds are not visible. */
function captchaBlocksSubmit() {
  const shown = (el) => {
    if (!el || !el.getBoundingClientRect) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 10 && el.offsetParent !== null;
  };
  const widgets = queryAllDeep('.g-recaptcha, .h-captcha, .cf-turnstile, .frc-captcha, #challenge-stage, ' +
                               'iframe[src*="recaptcha"][src*="bframe"], iframe[src*="hcaptcha"][src*="challenge"]');
  if (widgets.some(shown)) return true;
  const text = String(document.body && document.body.innerText || '');
  return /\b(complete|solve|finish) the (re)?captcha\b|\bverify (that )?you(?:'re| are) (a )?human\b|\bprove you(?:'re| are) (a )?human\b/i.test(text);
}

/** Is this page the approved posting's own? Same host and the same first path
 * segment (the board's company slug on Greenhouse/Lever/Ashby/SmartRecruiters),
 * so a tab that wandered to another employer's form is never submitted. */
function samePosting(applyUrl, pageUrl) {
  try {
    const a = new URL(String(applyUrl || ''));
    const b = new URL(String(pageUrl || location.href));
    if (a.hostname.toLowerCase() !== b.hostname.toLowerCase()) return false;
    const seg = (u) => u.pathname.split('/').filter(Boolean)[0] || '';
    return seg(a).toLowerCase() === seg(b).toLowerCase();
  } catch (_) {
    return false;
  }
}

/** Exact host or a real subdomain of a server allow-listed suffix. */
function autoSubmitAllowedHost(host, hosts) {
  const list = Array.isArray(hosts) ? hosts : [];
  return list.some((d) => typeof d === 'string' && d && hostIs(host, d.toLowerCase()));
}

/** The application form's own Submit control, or null. Never a sign-in form's. */
function findSubmitControl() {
  const visible = (el) => el && el.offsetParent !== null && !el.disabled &&
    el.getAttribute('aria-disabled') !== 'true';
  const text = (el) => String(el.value || el.textContent || el.getAttribute('aria-label') || '')
    .replace(/\s+/g, ' ').trim();
  const NEGATIVE = /\b(cancel|back|previous|next|continue|proceed|save|draft|sign ?in|log ?in|create account|register|search|subscribe|remove|delete|withdraw)\b/i;
  const inLogin = (el) => { const f = el.closest && el.closest('form'); return !!(f && isLoginForm(f)); };
  const all = queryAllDeep('button, input[type="submit"], input[type="button"], [role="button"]')
    .filter((el) => visible(el) && !inLogin(el) && !NEGATIVE.test(text(el)));
  // 1. A real submit control inside an application form, worded as one.
  const typed = all.filter((el) => (el.tagName === 'INPUT' && el.type === 'submit') ||
                                    (el.tagName === 'BUTTON' && (el.type === 'submit' || !el.getAttribute('type'))))
                   .filter((el) => el.closest && el.closest('form') && formLooksLikeApplication(el.closest('form')));
  const worded = (list) => list.find((el) => /\bsubmit\b/i.test(text(el))) ||
                           list.find((el) => /^(apply( now)?|send application|apply for this job)$/i.test(text(el)));
  // 2. A board whose Submit sits outside the <form> (React forms): only when
  //    the page has an application form, and only a control that SAYS submit —
  //    a job page's "Apply now" opens a form, it submits nothing.
  const outside = hasApplicationForm() ? all.find((el) => /\bsubmit\b/i.test(text(el))) : null;
  return worded(typed) || outside || null;
}

async function maybeAutoSubmit(pack, audit) {
  const key = String(pack.app_id) + '|' + location.href.split('#')[0];
  const done = (attempted, reason, extra) => {
    const out = Object.assign({ requested: true, attempted, reason }, extra || {});
    if (attempted) {
      reportTelemetry(pack, 'auto_submit_attempted', { host: location.hostname });
    } else {
      reportTelemetry(pack, 'auto_submit_blocked', Object.assign({ reason }, extra || {}));
      const why = AUTO_SUBMIT_BLOCK_TEXT[reason] || reason;
      const list = (audit && audit.problems || []).slice(0, 4).map((p) => '<li>' + escapeHtml(p) + '</li>').join('');
      showOverlay('✋ <b>Filled, but not submitted:</b> ' + escapeHtml(why) + '.<br>' +
                  (list ? '<ul style="margin:6px 0 0 14px;padding:0;font-size:12px">' + list + '</ul>' : '') +
                  '<small>Finish it here and click Submit yourself — SpotApply will record it when the site confirms.</small>',
                  [], true);
      console.log('[SpotApply] One-click submit held back:', reason);
    }
    return out;
  };
  if (_autoSubmitDone.has(key)) return { requested: true, attempted: false, reason: 'already_attempted' };
  if (!autoSubmitAllowedHost(location.hostname, pack.auto_submit_hosts)) return done(false, 'host_not_allowed');
  if (!samePosting(pack.apply_url, location.href)) return done(false, 'different_page');
  if (isLoginWall()) return done(false, 'login_wall');
  if (isCaptcha() || captchaBlocksSubmit()) return done(false, 'captcha');
  if (!audit || audit.needUser > 0 || audit.failed > 0) return done(false, 'fields_need_you');
  // Our own resume upload must have been acknowledged on a form that asks for one.
  const fileInputs = queryAllDeep('input[type="file"]');
  if (fileInputs.length && !fileInputs.some((fi) => (fi.files && fi.files.length) || fi.dataset.spotapplyUpload === 'accepted')) {
    return done(false, 'fields_need_you', { detail: 'resume not attached' });
  }
  const btn = findSubmitControl();
  if (!btn) return done(false, 'no_submit_button');
  if (btn.disabled) return done(false, 'submit_disabled');
  const form = btn.closest && btn.closest('form');
  if (form && typeof form.checkValidity === 'function' && !form.checkValidity()) {
    try { form.reportValidity(); } catch (_) {}
    return done(false, 'validation');
  }
  _autoSubmitDone.add(key);
  // Human pacing: never in a tab the user cannot see, and a 5 s countdown the
  // user can stop — with the Stop button or by touching the form themselves.
  const go = await submitCountdown(pack);
  if (!go) { _autoSubmitDone.delete(key); return done(false, 'cancelled_by_user'); }
  if (isCaptcha() || captchaBlocksSubmit()) { _autoSubmitDone.delete(key); return done(false, 'captcha'); }
  showOverlay('🚀 <b>Submitting your application' + (pack.company ? ' to ' + escapeHtml(pack.company) : '') + '…</b><br>' +
              '<small>SpotApply marks it Submitted only when the site confirms.</small>', [], false);
  noteSubmitAttempt('one_click');          // SUBMIT_ATTEMPTED + the confirmation watch
  try { btn.scrollIntoView({ block: 'center' }); } catch (_) {}
  btn.click();
  return done(true, 'clicked');
}

const AUTO_SUBMIT_DWELL_SECONDS = 5;
/** "Submitting to {company} in 5… [Stop]": resolves true when the countdown
 * ran out, false when the user stopped it (button, or their own trusted click
 * or keystroke in the page). Waits while the tab is hidden — a submission
 * never happens in a tab the user is not looking at. */
function submitCountdown(pack) {
  return new Promise((resolve) => {
    let left = AUTO_SUBMIT_DWELL_SECONDS;
    let finished = false;
    const finish = (ok) => {
      if (finished) return;
      finished = true;
      clearInterval(tick);
      document.removeEventListener('mousedown', onUser, true);
      document.removeEventListener('keydown', onUser, true);
      resolve(ok);
    };
    const onUser = (e) => {
      if (!e.isTrusted) return;
      const root = document.getElementById('hp-copilot-overlay');
      if (root && e.composedPath && e.composedPath().includes(root)) return;   // the overlay's own Stop handles itself
      finish(false);
    };
    const render = () => {
      showOverlay('🚀 <b>Submitting your application' + (pack.company ? ' to ' + escapeHtml(pack.company) : '') +
                  ' in ' + left + '…</b><br><small>Everything is filled. Click Stop, or anywhere in the form, to submit it yourself.</small>' +
                  '<div style="margin-top:8px"><button data-hp-stop="1" style="background:rgba(255,255,255,.14);color:#fff;border:0;border-radius:8px;padding:6px 12px;font-weight:700;cursor:pointer">Stop</button></div>',
                  [], false);
      const root = document.getElementById('hp-copilot-overlay');
      const scope = (root && root.shadowRoot) || document;
      const stop = scope.querySelector('[data-hp-stop="1"]');
      if (stop) stop.addEventListener('click', () => finish(false));
    };
    document.addEventListener('mousedown', onUser, true);
    document.addEventListener('keydown', onUser, true);
    render();
    const tick = setInterval(() => {
      if (document.visibilityState !== 'visible') return;   // hold while the tab is hidden
      left -= 1;
      if (left <= 0) { finish(true); return; }
      render();
    }, 1000);
  });
}

/** A sign-in or create-account page: fill the account EMAIL (and a "confirm
 * email" twin) from the profile, never a password. Returns true if it wrote. */
function prefillAccountEmail(pack) {
  const email = String(pack && pack.email || '').trim();
  if (!email) return false;
  let wrote = false;
  const candidates = queryAllDeep('input[type="email"], input[autocomplete="email"], input[autocomplete="username"], ' +
    'input[name*="email" i], input[id*="email" i], input[data-automation-id*="email" i], input[name*="username" i]')
    .filter((el) => el.offsetParent !== null && el.type !== 'password' && !String(el.value || '').trim());
  for (const el of candidates) {
    try {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
      if (setter && setter.set) setter.set.call(el, email); else el.value = email;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dataset.spotapplyFilled = 'true';
      wrote = true;
    } catch (_) {}
  }
  return wrote;
}

/** The field for an emailed one-time code, when the page is asking for one. */
function verificationCodeField() {
  const byAttr = queryAllDeep('input[autocomplete="one-time-code"], input[name*="otp" i], input[id*="otp" i], ' +
                              'input[name*="verification" i], input[id*="verification" i], input[name*="passcode" i]')
    .find((el) => el.offsetParent !== null);
  if (byAttr) return byAttr;
  return queryAllDeep('input:not([type="hidden"]):not([type="password"])').find((el) => {
    if (el.offsetParent === null) return false;
    const lbl = (labelText(el) || el.getAttribute('aria-label') || el.placeholder || '');
    return /\b(verification|security|confirmation|one[- ]time|6[- ]digit)\b.*\bcode\b|\bcode\b.*\b(email|sent)\b/i.test(lbl);
  }) || null;
}

/** A handoff to the human, once per page: the dashboard bell learns of it. */
const _handoffReported = new Set();
function reportHandoff(pack, event, meta) {
  const key = event + '|' + location.href.split('#')[0];
  if (_handoffReported.has(key)) return;
  _handoffReported.add(key);
  reportTelemetry(pack, event, Object.assign({ host: location.hostname }, meta || {}));
}

// Re-audit and re-render the status widget. Cheap (one querySelectorAll pass),
// and it never re-fills anything — it only recounts what is already there.
function refreshStepOverlay(pack) {
  if (!_copilotActive || _fillingInProgress) return null;
  try {
    const r = auditPageFields(pack, false);
    showStepOverlay(r, pack);
    return r;
  } catch (e) {
    console.debug('[SpotApply] status refresh skipped:', e.message);
    return null;
  }
}

let _statusRefreshBound = false;
function startStatusRefresh(pack) {
  if (_statusRefreshBound) return;
  _statusRefreshBound = true;
  let t = null;
  const debounced = () => {
    clearTimeout(t);
    t = setTimeout(() => refreshStepOverlay(pack), 700);
  };
  // A user typing into a yellow field should see the count move.
  ['input', 'change'].forEach((ev) =>
    document.addEventListener(ev, debounced, { capture: true, passive: true }));
}

// ── Fill current page ─────────────────────────────────────────────────────────

async function fillCurrentPage(pack) {
  const host = window.location.hostname;
  let platformFilled = false;

  // Step 1: Platform-specific handler (for special cases)
  try {
    if (hostIs(host, 'greenhouse.io'))       platformFilled = await fillGreenhouse(pack);
    else if (hostIs(host, 'lever.co'))       platformFilled = await fillLever(pack);
    else if (hostIs(host, 'ashbyhq.com'))    platformFilled = await fillAshby(pack);
    // linkedin.com intentionally absent — SpotApply never automates LinkedIn (see fillForm guard)
    // indeed.com intentionally absent — same hands-off policy as LinkedIn (see fillForm guard)
    else if (hostIs(host, 'myworkdayjobs.com') || hostIs(host, 'workday.com'))
                                              platformFilled = await fillWorkday(pack);
    else if (hostIs(host, 'smartrecruiters.com')) platformFilled = await fillSmartrecruiters(pack);
    else if (hostIs(host, 'avature.net') || isAvaturePage()) platformFilled = await fillAvature(pack);
    else                                      platformFilled = await fillGeneric(pack);
  } catch (e) {
    console.warn('[SpotApply] platform fill error:', e.message);
  }

  // Step 2: Universal signal-based filler — catches anything platform handlers missed
  try {
    const universalCount = await fillUniversal(pack);
    // Voluntary self-ID on custom dropdowns (Greenhouse's React selects,
    // Workday listboxes): the synchronous writers only reach <select>/radio.
    try {
      const eeoCustom = await fillEEOCustomDropdowns(pack);
      if (eeoCustom) console.log('[SpotApply] Answered', eeoCustom, 'self-identification dropdown(s) from your profile');
    } catch (e) { console.warn('[SpotApply] EEO dropdowns:', e.message); }
    if (universalCount > 0) console.log('[SpotApply] Universal filler filled', universalCount, 'additional fields');
  } catch (e) {
    console.warn('[SpotApply] universal fill error:', e.message);
  }

  // Step 3: Recall from cross-form memory (previously learned answers)
  try {
    const recalledCount = await recallFromMemory(document, pack);
    if (recalledCount > 0) console.log('[SpotApply] Recalled', recalledCount, 'fields from memory');
  } catch (e) {
    console.warn('[SpotApply] recall error:', e.message);
  }

  // Step 3b: Yes/No screening radios, straight from the profile. Deliberately
  // BEFORE the AI step: these are deterministic facts, not something to spend
  // a model call on, and they were the single largest gap (14 unanswered
  // required radios on one form).
  try {
    answerScreeningRadios(pack);
  } catch (e) {
    console.warn('[SpotApply] screening radio error:', e.message);
  }
  // Same rules for Yes/No BUTTON pairs (Ashby has no radios for these).
  try {
    answerYesNoButtons(pack);
  } catch (e) {
    console.warn('[SpotApply] yes/no button error:', e.message);
  }
  // "How did you hear about us?" as radios or an option list: the answer the
  // user saved in their profile, or nothing.
  try {
    await answerHowHeardChoices(pack);
  } catch (e) {
    console.warn('[SpotApply] how-heard choice error:', e.message);
  }

  // Step 4: Fill essay questions via AI
  await fillEssayQuestions(document, pack);

  // Step 5: Audit all form fields — classify as filled / unfilled / unknown
  return auditPageFields(pack, platformFilled);
}

/**
 * Count and highlight what is filled vs outstanding. Split out of the fill
 * so it can be re-run: the overlay used to be rendered before the resume
 * attach and the AI essay answers landed, so it went stale the moment those
 * completed ("5 filled" while seven fields held values).
 */
function auditPageFields(pack, platformFilled) {
  // Visibility, but not naively. A resume file input and custom-styled radios
  // are almost always the real input hidden behind a styled label, so
  // `offsetParent !== null` dropped them from BOTH sides of the tally — which
  // is why two required radio questions and the resume stayed invisible to the
  // count. For those, fall back to whether their LABEL or container is visible.
  // Rippling proved the label-visibility fallback was not enough: its real
  // file and radio inputs sit OUTSIDE the styled label's subtree, so they
  // still reported offsetParent === null and vanished from the tally — on a
  // form where the browser itself does not block submit, leaving this widget
  // as the user's only pre-submit signal. For proxied input types, ask whether
  // anything the user can actually click is rendered nearby.
  const shownVia = (el) => {
    if (el.offsetParent !== null) return true;
    const doc = el.getRootNode() || document;
    const id = el.id;
    const lbl = (id && doc.querySelector && doc.querySelector(`label[for="${CSS.escape(id)}"]`))
      || el.closest('label');
    if (lbl && lbl.getClientRects && lbl.getClientRects().length) return true;
    // Walk up until something has a box. A visually-hidden input inside a
    // rendered dropzone/fieldset is present to the user even though it is not.
    let node = el.parentElement;
    for (let depth = 0; node && depth < 6; depth++, node = node.parentElement) {
      if (node.getClientRects && node.getClientRects().length) return true;
    }
    return false;
  };
  const allInputs = queryAllDeep(
    'input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="image"]),' +
    'textarea, select, button[data-automation-id="select-button"], button[aria-haspopup="listbox"]'
  ).filter((el) => {
    // A captcha response box or a honeypot is not a question for anyone.
    if (isAntiBotField(el)) return false;
    const proxied = el.type === 'file' || el.type === 'radio' || el.type === 'checkbox';
    return proxied ? shownVia(el) : el.offsetParent !== null;
  });
  // Yes/No BUTTON pairs (Ashby) are questions too: missing from this tally,
  // two required ones were blank while the widget counted three. Any input
  // inside one of their fields belongs to the pair, not to a second question.
  const ynGroups = yesNoButtonGroups(document).filter((g) => g.box.getClientRects().length);
  const inYesNoField = (el) => ynGroups.some((g) => (g.entry || g.box).contains(el));

  let filled = 0, needUser = 0, skipped = 0, failed = 0;
  const needUserEls = [];
  const problems = [];
  // Why a question was left for the user, when we know (shown in the widget).
  const notes = [];
  const noteWorkAuth = (question) => {
    const msg = pack && pack.work_auth_note;
    if (msg && /authoriz|eligible to work|right to work|legally/i.test(question || '') &&
        !/sponsor/i.test(question || '') && !notes.includes(msg)) notes.push(msg);
  };
  const seenRadioGroups = new Set();
  const nameOf = (el) => (labelText(el) || el.getAttribute('aria-label') || el.name || el.id || 'a field')
    .replace(/\s+/g, ' ').trim().slice(0, 60);
  const flag = (el, why) => {
    needUser++; needUserEls.push(el); failed++;
    highlightField(el, 'red');
    problems.push(`${nameOf(el)}: ${why}`);
  };

  for (const el of allInputs) {
    if ((el.type === 'radio' || el.type === 'checkbox') && inYesNoField(el)) continue;
    // File inputs: a file IN the input is not an upload. Ours count only once
    // the uploader acknowledged them (attachResume marks the outcome); a file
    // the user picked themselves is theirs and counts.
    if (el.type === 'file') {
      const ours = el.dataset.spotapplyUpload;
      if (ours === 'unconfirmed') { flag(el, 'the upload was not confirmed by the site — attach it again'); continue; }
      if (ours === 'wrong_format') { flag(el, 'this field does not accept that file format'); continue; }
      if (el.files && el.files.length) { filled++; highlightField(el, 'green'); }
      else if (isFieldRequired(el)) {
        needUser++; needUserEls.push(el); highlightField(el, 'red');
      } else { skipped++; }
      continue;
    }
    if (el.type === 'radio') {
      // A radio group is ONE question: count it once, answered if any member
      // is checked.
      const key = el.name || el.id || '';
      if (el.name && seenRadioGroups.has(key)) { continue; }
      if (el.name) seenRadioGroups.add(key);
      const group = el.name
        ? document.querySelectorAll(`input[type="radio"][name="${CSS.escape(el.name)}"]`)
        : [el];
      if (Array.from(group).some((g) => g.checked)) { skipped++; continue; }
      if (isFieldRequired(el)) {
        needUser++; needUserEls.push(el); highlightField(el, 'red');
        noteWorkAuth(radioGroupQuestion(el));
      } else { skipped++; }
      continue;
    }
    if (el.type === 'checkbox') {
      // Checkboxes are NOT a group: two individually required boxes that share
      // a name ("I agree…", "I confirm…") both have to be ticked.
      if (el.checked) { skipped++; continue; }
      if (el.required || el.getAttribute('aria-required') === 'true') {
        needUser++; needUserEls.push(el); highlightField(el, 'red');
      } else { skipped++; }
      continue;
    }

    let val = el.value ? el.value.trim() : '';
    if (el.tagName === 'BUTTON') {
      const txt = el.textContent ? el.textContent.trim() : '';
      if (!txt || /select\b|choose\b|^-$|select\s+option/i.test(txt)) {
        val = '';
      } else {
        val = txt;
      }
    }

    if (val) {
      // Present is not the same as valid: an email the browser rejects, a
      // number under its minimum, or a field the site flagged as an error.
      const invalid = (el.validity && el.validity.valid === false) ||
                      el.getAttribute('aria-invalid') === 'true';
      if (invalid) {
        flag(el, (el.validationMessage || 'the site says this value is not valid').slice(0, 80));
        continue;
      }
      filled++;
      highlightField(el, 'green');
    } else {
      needUser++;
      needUserEls.push(el);
      const isReq = isFieldRequired(el);
      highlightField(el, isReq ? 'red' : 'yellow');
      if (isReq) noteWorkAuth(labelText(el));
      // Observe unfilled fields for cross-form learning
      observeField(el, pack);
    }
  }

  for (const g of ynGroups) {
    if (yesNoChoice(g)) { filled++; highlightField(g.box, 'green'); continue; }
    if (yesNoRequired(g)) {
      needUser++; needUserEls.push(g.box); highlightField(g.box, 'red');
      noteWorkAuth(g.question);
    } else { skipped++; }
  }

  // A how-did-you-hear option list drawn as buttons or ARIA options (Ashby)
  // is a question too; radio groups are already counted above.
  for (const g of howHeardChoiceGroups(document, pack && pack.company)) {
    if (g.kind === 'radio') continue;
    if (g.options.some(_choiceOn)) { filled++; highlightField(g.box, 'green'); continue; }
    needUser++; needUserEls.push(g.box);
    highlightField(g.box, g.label && labelMarksRequired(g.label) ? 'red' : 'yellow');
  }

  // The résumé's own outcome survives every recount until it changes.
  if (_resumeStatus && ['error', 'failed'].includes(_resumeStatus.state) &&
      !problems.some((p) => /resume/i.test(p))) {
    failed++;
    problems.push('Resume: ' + (_resumeStatus.message || 'could not be attached — attach it yourself'));
  }

  return { filled, needUser, needUserEls, platformFilled, failed, problems, notes };
}

function isFieldRequired(el) {
  if (!el) return false;
  try {
    if (el.required || el.getAttribute('required') !== null || el.getAttribute('aria-required') === 'true') {
      return true;
    }
  } catch (e) {}
  
  const lbl = labelText(el);
  if (lbl.includes('*') || lbl.includes('(required)') || lbl.includes('required')) {
    return true;
  }
  
  try {
    const labelledby = el.getAttribute('aria-labelledby');
    if (labelledby) {
      const lblEl = document.getElementById(labelledby);
      if (lblEl) {
        const txt = lblEl.textContent.toLowerCase();
        if (txt.includes('*') || txt.includes('required')) return true;
      }
    }
  } catch (e) {}

  // A label marked required by class or a CSS "*" (Ashby), and a required
  // group around a radio.
  try {
    if (fieldLabelElements(el).some(labelMarksRequired)) return true;
    if (el.closest && el.closest('[role="radiogroup"][aria-required="true"], [role="group"][aria-required="true"]')) return true;
  } catch (e) {}

  return false;
}

// ── Field highlighting ────────────────────────────────────────────────────────

function highlightField(el, color) {
  el.style.transition = 'box-shadow 0.3s ease, border-color 0.3s ease';
  if (color === 'green') {
    el.style.boxShadow = '0 0 0 2px rgba(16,185,129,0.5)';
    el.style.borderColor = 'rgba(16,185,129,0.7)';
  } else if (color === 'red') {
    el.style.boxShadow = '0 0 0 2px rgba(239,68,68,0.7)';
    el.style.borderColor = 'rgba(239,68,68,0.9)';
    el.dataset.spotapply = 'needs-fill-required';
    el.addEventListener('input', () => {
      if (String(el.value || '').trim()) highlightField(el, 'green');
    }, { once: true });
  } else {
    el.style.boxShadow = '0 0 0 2px rgba(245,158,11,0.6)';
    el.style.borderColor = 'rgba(245,158,11,0.8)';
    el.dataset.spotapply = 'needs-fill';
    el.addEventListener('input', () => {
      if (String(el.value || '').trim()) highlightField(el, 'green');
    }, { once: true });
  }
}

function clearHighlights() {
  document.querySelectorAll('[data-spotapply]').forEach(el => {
    el.style.boxShadow = '';
    el.style.borderColor = '';
    delete el.dataset.spotapply;
  });
}

// ── Step overlay ──────────────────────────────────────────────────────────────

function showStepOverlay(result, pack) {
  if (_confirmPromptOpen) return;   // the "did it go through?" question stays until answered
  const { filled, needUser } = result;
  const failed = result.failed || 0;
  const stepText = detectStepText();
  const esc = (x) => String(x || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  let statusHtml = '';
  if (filled > 0) statusHtml += `<span style="color:#10b981;font-weight:700">✅ ${filled} filled</span>`;
  if (needUser > 0) statusHtml += `${filled > 0 ? ' &nbsp;·&nbsp; ' : ''}<span style="color:#f59e0b;font-weight:700">⚠️ ${needUser} need you</span>`;
  const nothingHere = filled === 0 && needUser === 0;
  if (nothingHere) statusHtml = '<span style="color:#94a3b8">No fields to fill on this page</span>';

  const stepLabel = stepText ? `<div style="color:#94a3b8;font-size:11px;margin-bottom:6px">${stepText}</div>` : '';

  // "No fields found" + "All fields filled!" used to render together, which
  // read as a contradiction in one toast. Three distinct states now.
  // "…then click Next" only where there IS a Next: on a single-page form
  // (Ashby, 2026-10-09) the next step is the user's own review and Submit.
  const multiStep = hasNextStepButton();
  const nextStep = multiStep ? 'then click Next' : 'then review the whole form and submit it yourself';
  const instructions = nothingHere
    ? `<div style="font-size:11px;color:#94a3b8;margin-top:6px">Nothing to fill here. I'll pick up on the application form.</div>`
    : needUser > 0
      ? `<div style="font-size:11px;color:#cbd5e1;margin-top:6px">Fill the <span style="color:#f59e0b;font-weight:600">highlighted fields</span> above, ${nextStep}.</div>`
      : `<div style="font-size:11px;color:#cbd5e1;margin-top:6px">All fields filled. Review them, ${nextStep}.</div>`;

  // The résumé line: which file, and what the site did with it.
  let resumeHtml = '';
  const rs = _resumeStatus;
  if (rs) {
    const label = { accepted: '✅ Resume attached', unconfirmed: '⚠️ Resume not confirmed',
                    wrong_format: '⚠️ Resume format not accepted', failed: '⚠️ Resume not attached',
                    error: '⚠️ Resume not attached' }[rs.state] || '📎 Resume';
    const file = rs.filename ? ` — ${esc(rs.filename)}${rs.kind ? ` (${esc(rs.kind)})` : ''}` : '';
    const msg = rs.message ? `<br><span style="color:#cbd5e1">${esc(rs.message)}</span>` : '';
    resumeHtml = `<div style="font-size:11px;margin-top:6px">${label}${file}${msg}</div>`;
  }
  const probs = (result.problems || []).filter((p) => !/^Resume:/.test(p) || !rs).slice(0, 4);
  const probHtml = probs.length
    ? `<div style="font-size:11px;color:#fca5a5;margin-top:6px">${probs.map(esc).join('<br>')}</div>` : '';
  const notes = (result.notes || []).slice(0, 2);
  const noteHtml = notes.length
    ? `<div style="font-size:11px;color:#c4b5fd;margin-top:6px">${notes.map(esc).join('<br>')}</div>` : '';
  // "Ready to review" means the form looks complete to US — never that the
  // employer accepted anything.
  const finalInstr = (!nothingHere && needUser === 0 && failed === 0)
    ? `<div style="font-size:11px;color:#cbd5e1;margin-top:6px">Ready for your review. Check every field, ${multiStep ? 'then click Next' : 'then submit it yourself'}.</div>`
    : instructions;

  showOverlay(`${stepLabel}${statusHtml}${finalInstr}${resumeHtml}${probHtml}${noteHtml}`, [], true);
}

/** Does this page lead to another step (Next / Continue), or is it the whole form? */
function hasNextStepButton() {
  const NEXT = /^(next|continue|save (?:and|&) continue|save (?:and|&) next|next step|proceed)\b/i;
  return queryAllDeep('button, input[type="submit"], input[type="button"], a[role="button"], [role="button"]')
    .some((b) => {
      const host = b.getRootNode && b.getRootNode().host;
      if (host && host.id === 'hp-copilot-overlay') return false;
      if (!b.getClientRects || !b.getClientRects().length) return false;
      const t = String(b.textContent || b.value || (b.getAttribute && b.getAttribute('aria-label')) || '')
        .replace(/\s+/g, ' ').trim();
      return NEXT.test(t) || (b.getAttribute && /^(next|continue)/i.test(b.getAttribute('data-automation-id') || '') );
    });
}

// ── Pause overlay (login / captcha) ──────────────────────────────────────────

function showOverlay(html, _unused, dismissable) {
  removeOverlay();
  // Rendered inside a SHADOW ROOT. Injected straight into the page it inherited
  // the site's CSS — an aggressive global line-height or `* { position }` rule
  // collapsed the lines on top of each other ("Next" printed over "Fill the
  // yellow fields above, then click"). A shadow root is the only reliable way
  // to keep our own UI readable on an arbitrary site.
  const host = document.createElement('div');
  host.id = 'hp-copilot-overlay';
  // `all: initial` FIRST — it resets every property, so anything set before it
  // would be wiped. The host carries only positioning; all visual style lives
  // inside the shadow root, out of reach of the page's CSS.
  Object.assign(host.style, {
    all: 'initial',
    position: 'fixed', bottom: '20px', right: '20px', zIndex: '2147483647',
  });

  let root;
  try {
    root = host.attachShadow({ mode: 'open' });
  } catch (_) {
    root = host;   // very old engines — degrade to the previous behaviour
  }
  root.innerHTML = `
    <style>
      :host, * { box-sizing: border-box; }
      .card {
        display: flex; align-items: flex-start; gap: 10px;
        background: linear-gradient(135deg,rgba(15,23,42,0.97),rgba(30,41,59,0.97));
        border: 1px solid rgba(99,102,241,0.4); border-radius: 16px;
        padding: 14px 16px; max-width: 320px; min-width: 220px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.5), 0 0 0 1px rgba(99,102,241,0.1);
        font-family: system-ui, sans-serif; font-size: 13px; line-height: 1.5;
        color: #e2e8f0; backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px);
      }
      .bolt { font-size: 20px; flex-shrink: 0; line-height: 1.2; }
      .body { flex: 1; line-height: 1.5; min-width: 0; }
      .body b, .body strong { color: #f1f5f9; }
      .body small { display: block; margin-top: 4px; line-height: 1.5; color: #cbd5e1; }
      .close {
        background: none; border: none; color: #64748b; cursor: pointer;
        font-size: 16px; padding: 0 4px; line-height: 1; flex-shrink: 0;
      }
      .close:hover { color: #e2e8f0; }
    </style>
    <div class="card">
      <span class="bolt">⚡</span>
      <div class="body">${html}</div>
      ${dismissable ? '<button data-hp-close class="close" title="Dismiss">✕</button>' : ''}
    </div>`;

  document.body.appendChild(host);
  // Attach the dismiss handler via addEventListener — inline onclick="" is
  // blocked by strict CSP on sites like LinkedIn, which is why the ✕ used to
  // do nothing there.
  if (dismissable) {
    root.querySelector('[data-hp-close]')?.addEventListener('click', () => host.remove());
    setTimeout(() => host?.remove(), 30000);  // auto-hide
  }
}

function removeOverlay() {
  document.getElementById('hp-copilot-overlay')?.remove();
}

// ── Detect step text (e.g. "Step 2 of 4") ────────────────────────────────────

function detectStepText() {
  // The bare "N / M" form used to be matched anywhere on the page, so the
  // widget cheerfully reported a follower count or a date as the wizard step
  // ("831/58783", "04/30"). Keep it, but only as a plausible step counter:
  // the text node must be essentially just the counter, and N <= M <= 30.
  const plausibleRatio = (txt) => {
    // No leading zeros: "04/30" is a date, "4/30" would be step 4 of 30.
    const m = txt.match(/^\D{0,6}?([1-9]\d?)\s*\/\s*([1-9]\d?)\D{0,6}$/);
    if (!m) return null;
    const a = +m[1], b = +m[2];
    return b >= 2 && b <= 20 && a <= b ? `${a}/${b}` : null;
  };
  const patterns = [
    /step\s+\d+\s+of\s+\d+/i,
    /page\s+\d+\s+of\s+\d+/i,
    /\d+\s+of\s+\d+\s+steps/i,
  ];

  // 1. Check aria-current="step" or similar active page elements first
  try {
    const currentEl = document.querySelector('[aria-current="step"], [aria-current="page"], .wd-active, .active-step');
    if (currentEl) {
      const txt = currentEl.textContent?.trim();
      if (txt) {
        for (const p of patterns) {
          const m = txt.match(p);
          if (m) return m[0];
        }
        const r = plausibleRatio(txt);
        if (r) return r;
      }
    }
  } catch (e) {}

  // 2. Walk text nodes and collect matches
  const matches = [];
  try {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      const t = node.textContent.trim();
      if (t.length > 60) continue;   // prose, not a step indicator
      let hit = null;
      for (const p of patterns) {
        const m = t.match(p);
        if (m) { hit = m[0]; break; }
      }
      if (!hit) hit = plausibleRatio(t);
      if (hit) matches.push({ text: t.slice(0, 50), matchedPattern: hit });
    }
  } catch (e) {}

  if (matches.length === 0) return null;

  // 3. Prefer a match containing "current", "active", "now", or "selected"
  const currentMatch = matches.find(item => /current|active|now|selected/i.test(item.text));
  if (currentMatch) return currentMatch.matchedPattern;

  // 4. Exclude matches containing "completed", "done", "previous", "passed" if there are other candidates
  const activeCandidates = matches.filter(item => !/completed|done|previous|passed/i.test(item.text));
  if (activeCandidates.length > 0) {
    return activeCandidates[0].matchedPattern;
  }

  return matches[0].matchedPattern;
}

// ── Login / CAPTCHA detection ─────────────────────────────────────────────────

function isLoginWall() {
  const shown = (el) => !!el && el.offsetParent !== null;
  // 1. A VISIBLE password field is a sign-in form (a hidden one in a header
  //    dropdown is not).
  if (queryAllDeep('input[type="password"]').some(shown)) return true;
  // 2. Workday OAuth gateway pages (wday/authgwy) are login walls even without
  //    a visible password field — they redirect to SSO then back. By path
  //    SEGMENT: the bare substring /sso/ matched ".../assistant-profeSSOr".
  if (/(^|[\/_.-])(authgwy|auth-gateway|saml2?|sso)([\/_.?-]|$)/i.test(window.location.pathname)) return true;
  // 3. An application form, or a job page's own Apply button, is not a wall.
  if (queryAllDeep('input[type="text"], input[type="email"], input:not([type]), textarea')
        .some((el) => shown(el) && !isAntiBotField(el))) return false;
  if (pageHasApplyControl()) return false;
  // 4. Sign-in wording on the page's CONTROLS and headings, as whole words —
  //    never the job description. The whole body text was searched, so the
  //    Horizon3 posting's "deSIGN INtegration schemas" read as "sign in" and the
  //    Ashby job page was reported as a login wall (live test, 2026-10-09).
  return queryAllDeep('button, a, [role="button"], h1, h2, h3, legend, label')
    .filter(shown)
    .some((el) => {
      const t = String(el.textContent || el.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
      return t.length <= 60 &&
        /\b(sign[ -]?in|log[ -]?in|create an? account|register to apply)\b/i.test(t);
    });
}

/** A visible Apply control: the page is a job posting, not a sign-in wall. */
function pageHasApplyControl() {
  return queryAllDeep("a, button, [role='button'], input[type='button'], input[type='submit']")
    .some((el) => {
      if (el.offsetParent === null) return false;
      const t = String(el.textContent || el.value || el.getAttribute('aria-label') || '')
        .replace(/\s+/g, ' ').trim();
      return t.length <= 60 && /\bapply\b/i.test(t) && !/\bwith (linkedin|indeed)\b/i.test(t);
    });
}

function isCaptcha() {
  if (hasApplicationForm()) return false;

  // Only treat as CAPTCHA if the challenge element is actually visible.
  // Ashby embeds hCaptcha iframes in the DOM even when not triggered — checking
  // visibility prevents false positives that block autofill unnecessarily.
  const selectors = [
    'iframe[src*="recaptcha"]',
    'iframe[src*="hcaptcha"]',
    '.cf-turnstile',
    '#challenge-stage',
  ];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el) {
      const rect = el.getBoundingClientRect();
      const visible = rect.width > 0 && rect.height > 10 && rect.top >= 0;
      if (visible) return true;
    }
  }
  return document.body.innerText.toLowerCase().includes('prove you are human');
}

// ── Watch for page advance (user clicked Next) ────────────────────────────────

let _advanceObserver = null;
let _lastUrl = location.href;

function watchForPageAdvance(pack) {
  if (_advanceObserver) { _advanceObserver.disconnect(); _advanceObserver = null; }

  // Strategy 1: URL change (standard navigations)
  const urlPoll = setInterval(() => {
    if (!_copilotActive) { clearInterval(urlPoll); return; }
    if (location.href !== _lastUrl) {
      _lastUrl = location.href;
      _resumeAttachedOnPage = null; // reset resume guard on new page
      _nativeAutofillOnPage = null;
      clearInterval(urlPoll);
      if (_advanceObserver) { _advanceObserver.disconnect(); _advanceObserver = null; }
      clearHighlights();
      removeOverlay();
      setTimeout(() => runCopilotStep(), 1500); // wait for new page content
    }
  }, 400);

  // Strategy 2: Major DOM change on same URL (SPA / Workday / React)
  // Take the snapshot AFTER a short delay so our own fill doesn't get
  // included in the baseline count.
  let mutationTimer = null;
  const _FIELD_SEL = 'input, textarea, select, button[data-automation-id="select-button"], button[aria-haspopup="listbox"]';
  const _countVisible = () =>
    Array.from(document.querySelectorAll(_FIELD_SEL)).filter((e) => e.offsetParent).length;
  const snapshot = document.querySelectorAll(_FIELD_SEL).length;
  // Track VISIBLE fields too. A tabbed form (Recruitee, and any "Job details /
  // Application" split) has the whole application panel in the DOM but hidden,
  // so revealing it changes nothing about the total count — the copilot never
  // re-ran and every field skipped for invisibility stayed empty forever.
  let visibleSnapshot = _countVisible();
  const stepAtStart = detectStepText();
  _advanceObserver = new MutationObserver(() => {
    // Skip if we're in the middle of filling
    if (_fillingInProgress) return;

    // A Workday "Save and Continue" advances the wizard WITHOUT a URL change and
    // sometimes WITHOUT a big field-count delta (e.g. the sparse Resume step), so
    // treat a change in the "Step X of Y" indicator as an instant page advance.
    const stepNow = detectStepText();
    const stepChanged = !!stepNow && stepNow !== stepAtStart;

    if (stepChanged) {
      clearTimeout(mutationTimer);
      mutationTimer = setTimeout(() => {
        if (!_copilotActive) return;
        if (_fillingInProgress) return;
        if (location.href === _lastUrl) {
          _resumeAttachedOnPage = null;
          _nativeAutofillOnPage = null;
          clearHighlights();
          removeOverlay();
          runCopilotStep();
        }
      }, 500);
      return;
    }

    // Cooldown check for fieldsChanged only, to prevent feedback loop during autofill
    if (Date.now() - _lastFillTimestamp < 1500) return;

    const now = document.querySelectorAll(_FIELD_SEL).length;
    const fieldsChanged = now !== snapshot && Math.abs(now - snapshot) >= 4;
    // A reveal (tab switch, accordion, "show more") adds visible fields without
    // adding nodes. Re-baseline either way so one reveal fires one re-run.
    const nowVisible = _countVisible();
    const revealed = nowVisible - visibleSnapshot >= 2;
    if (revealed) visibleSnapshot = nowVisible;
    if (fieldsChanged || revealed) {
      clearTimeout(mutationTimer);
      mutationTimer = setTimeout(() => {
        if (!_copilotActive) return;
        if (_fillingInProgress) return;
        if (Date.now() - _lastFillTimestamp < 1500) return;
        if (location.href === _lastUrl) { // only if URL didn't change (handled above)
          _resumeAttachedOnPage = null; // new page section, allow resume again
          _nativeAutofillOnPage = null;
          clearHighlights();
          removeOverlay();
          runCopilotStep();
        }
      }, 1200);
    }
  });
  // attributeFilter, not blanket attributes: a reveal is a style/class/hidden
  // flip, and watching those keeps the callback off our own data-spotapply-*
  // writes (which would feed back into the fill loop).
  _advanceObserver.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['style', 'class', 'hidden', 'aria-hidden'],
  });
}

// ── Watch for form appearance (after login / captcha) ─────────────────────────

function watchForFormAppearance() {
  const startUrl = location.href;
  const check = setInterval(() => {
    if (!_copilotActive) { clearInterval(check); return; }

    // If the URL changed (login redirect), the content script on the NEW page
    // handles it. But for SPA navigations within the same page:
    if (location.href !== startUrl) {
      clearInterval(check);
      removeOverlay();
      console.log('[SpotApply] URL changed during login watch:', location.href);
      // Re-read this tab's session (the background keeps it fresh).
      getTabPack((tabPack) => {
        const freshPack = tabPack || _copilotPack;
        if (freshPack) {
          _copilotPack = freshPack;
          setTimeout(() => runCopilotStep(), 1500);
        }
      });
      return;
    }

    if (!isLoginWall() && !isCaptcha()) {
      clearInterval(check);
      removeOverlay();
      console.log('[SpotApply] Login/captcha cleared — resuming copilot');
      setTimeout(() => runCopilotStep(), 1000);
    }
  }, 1500);
}

// ── Apply button finder ───────────────────────────────────────────────────────
// Used when the extension is on a job description page, not a form yet.

function findAndClickApply(pack) {
  const clickables = Array.from(
    document.querySelectorAll("a, button, [role='button'], input[type='button'], input[type='submit']")
  ).filter(el => el.offsetParent !== null);

  const labelOf = (el) => ((el.textContent || '') + ' ' + (el.getAttribute('aria-label') || '')).trim();

  // The board's own "Autofill with Resume" option (Workday's chooser) comes
  // first while native autofill is on: it fills the history sections we cannot
  // and the next step feeds it the resume. "Apply Manually" was preferred
  // before, which left every field to us. Never the LinkedIn/Indeed shortcuts.
  if (_nativeAutofillEnabled && NATIVE_AUTOFILL_ATS.has(nativeAutofillAts())) {
    const native = detectNativeAutofill();
    if (native && native.kind === 'button') {
      _nativeChooserPending = { ats: native.ats, ts: Date.now() };
      _pressElement(native.element);
      console.log('[SpotApply] Clicked the site\'s own resume autofill option (' + native.ats + ')');
      showOverlay('⚡ Using the site\'s own resume autofill first…<br><small style="color:#94a3b8">Your SpotApply resume goes in next; anything it misses gets filled after. If a sign-in appears, log in — I\'ll resume.</small>', [], false);
      watchForFormAppearance();
      return true;
    }
  }

  // Workday "Start Your Application" chooser: "Apply Manually" when its own
  // autofill is off or not offered, so we control the fill (never the
  // LinkedIn flow).
  const chooser = clickables.find(el => /apply\s*manually/i.test(labelOf(el)));
  if (chooser) {
    chooser.click();
    console.log('[SpotApply] Clicked "Apply Manually" (Workday chooser)');
    showOverlay('🖱️ Starting application…<br><small style="color:#94a3b8">If a sign-in appears, log in — I\'ll resume.</small>', [], false);
    watchForFormAppearance();
    return true;
  }

  const isApply = (el) => {
    const href = (el.getAttribute('href') || '');
    const label = labelOf(el);
    // Avoid LinkedIn/social apply shortcuts — we want the native form
    if (/with\s+linkedin|with\s+indeed/i.test(label)) return false;
    
    if (label.length > 0 && label.length <= 150) {
      const cleanLabel = label.toLowerCase();
      // Exclude legal / terms of service / cookie consent text
      if (/terms|conditions|privacy|policy|cookie|consent|agree|by\s+applying|learn\s+more/i.test(cleanLabel)) return false;
      // Look for action verbs / apply signals
      if (/\b(apply|submit\s+application|start\s+application|apply\s+manually|apply\s+now|apply\s+online)\b/i.test(cleanLabel)) return true;
    }

    if (/\/apply\b|applynow|apply-now/i.test(href)) return true;
    return false;
  };
  const candidates = clickables.filter(isApply);

  if (candidates.length > 0) {
    candidates[0].click();
    console.log('[SpotApply] Clicked Apply button:', labelOf(candidates[0]));
    showOverlay('🖱️ Clicked <strong>Apply</strong>. Waiting for the form to load…', [], false);
    watchForFormAppearance();
    return true;
  }
  // No apply button found — guide the user
  showOverlay(
    '👆 I couldn\'t find the <strong>Apply</strong> button automatically.<br>' +
    '<small style="color:#94a3b8">Please click it yourself — I\'ll take over once the form loads.</small>',
    [], true
  );
  watchForFormAppearance();
  return false;
}

// ── Banner (legacy, used only if copilot not active) ─────────────────────────

function showBanner(msg) {
  const existing = document.getElementById('spotapply-ext-banner');
  if (existing) existing.remove();
  const banner = document.createElement('div');
  banner.id = 'spotapply-ext-banner';
  banner.style.cssText = [
    'position:fixed','top:0','left:0','right:0','z-index:2147483647',
    'padding:12px 20px','display:flex','align-items:center','gap:12px',
    'background:linear-gradient(135deg,#4f46e5,#7c3aed)',
    'color:white','font-family:system-ui,sans-serif','font-size:13px','font-weight:500',
    'box-shadow:0 2px 20px rgba(79,70,229,0.4)',
  ].join(';');
  banner.innerHTML = `<span style="font-size:18px">🚀</span><span style="flex:1">${msg}</span>` +
    `<button data-hp-close style="background:rgba(255,255,255,0.2);border:none;color:white;cursor:pointer;padding:4px 10px;border-radius:8px;font-size:12px">✕</button>`;
  document.body.prepend(banner);
  // addEventListener (not inline onclick) so the ✕ works under strict CSP.
  banner.querySelector('[data-hp-close]')?.addEventListener('click', () => banner.remove());
  setTimeout(() => banner?.remove(), 12000);
}

// ── Extension context guard ───────────────────────────────────────────────────
// If the extension is reloaded while a tab is open, the content script becomes
// orphaned and chrome.* calls throw "Extension context invalidated".
function chromeCall(fn) {
  try { return fn(); } catch (e) {
    if (e?.message?.includes('Extension context invalidated')) {
      console.warn('[SpotApply] Extension was reloaded — please refresh this tab.');
      
      // Close any open loading modals or overlays to prevent stuck states
      document.getElementById('hp-email-scanner-modal')?.remove();
      
      if (!document.getElementById('hp-context-invalidated-banner')) {
        const banner = document.createElement('div');
        banner.id = 'hp-context-invalidated-banner';
        banner.style.cssText = `
          position: fixed;
          top: 24px;
          right: 24px;
          z-index: 9999999;
          background: rgba(239, 68, 68, 0.95);
          color: #ffffff;
          backdrop-filter: blur(12px);
          -webkit-backdrop-filter: blur(12px);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 16px;
          padding: 16px 20px;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
          font-size: 13px;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 12px;
          animation: hpBannerFadeIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        `;
        banner.innerHTML = `
          <span style="font-size: 18px;">⚠️</span>
          <div>
            <div style="font-weight: 800; margin-bottom: 2px;">Extension reloaded</div>
            <div style="font-weight: 400; opacity: 0.9; font-size: 11px;">Please refresh this tab to reconnect.</div>
          </div>
          <button data-hp-reload style="
            background: #ffffff;
            color: #ef4444;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            font-weight: 700;
            font-size: 11px;
            cursor: pointer;
            margin-left: 8px;
            transition: all 0.2s;
          ">Refresh</button>
        `;
        
        // Add entry animation if not present
        if (!document.getElementById('hp-banner-style')) {
          const style = document.createElement('style');
          style.id = 'hp-banner-style';
          style.innerHTML = `
            @keyframes hpBannerFadeIn {
              from { opacity: 0; transform: translateY(-16px) scale(0.95); }
              to { opacity: 1; transform: translateY(0) scale(1); }
            }
          `;
          document.head.appendChild(style);
        }
        document.body.appendChild(banner);
        // addEventListener (not inline onclick) — CSP-safe.
        banner.querySelector('[data-hp-reload]')?.addEventListener('click', () => window.location.reload());
      }
    } else {
      console.error('[SpotApply]', e);
    }
  }
}

// ── Message listener ──────────────────────────────────────────────────────────

chromeCall(() => chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'DO_FILL') {
    // Every frame receives this; only a frame that can fill answers, so an
    // inert ad iframe can never be the reply the popup shows.
    if (!HP_FRAME_ACTIVE) return false;
    console.log('[SpotApply] DO_FILL received, starting copilot for:', msg.fillPack?.job_title);
    fillForm(msg.fillPack).then(
      (r) => sendResponse(r || { ok: false, reason: 'nothing happened' }),
      (e) => sendResponse({ ok: false, reason: String(e && e.message || e) }));
    return true;
  }
  // Popup "Copy diagnostic report" — describe what the copilot can see on THIS
  // page and what it actually wrote, so a failed fill on a real posting can be
  // diagnosed from the report alone instead of guessed at from a screenshot.
  if (msg.type === 'DIAGNOSTIC_REPORT') {
    try { sendResponse(buildDiagnosticReport()); }
    catch (e) { sendResponse({ error: String(e && e.message || e) }); }
    return true;
  }
  if (msg.type === 'DASHBOARD_REFRESH') {
    console.log('[SpotApply] DASHBOARD_REFRESH received, clearing pending apply and reloading dashboard page');
    try {
      localStorage.removeItem('hp_pending_apply');
    } catch (_) {}
    window.location.reload();
    sendResponse({ ok: true });
    return true;
  }
}));

// ── Diagnostic report ────────────────────────────────────────────────────────
// Everything needed to explain a fill on a real posting: whether the host is
// recognised, whether a session was live, and — per field — the signals the
// matcher saw, whether the field was visible when we ran, and whether the value
// in it came from US or from the browser/site. Values themselves are NEVER
// included (this gets pasted into chat/issues): only lengths and a redacted
// shape, so a wrong-value bug is still visible without leaking PII.
function _redactShape(v) {
  return String(v || '')
    .replace(/[A-Za-z]/g, 'a').replace(/\d/g, '9')
    .slice(0, 24);
}

function buildDiagnosticReport() {
  const fields = [];
  const nodes = document.querySelectorAll(
    "input:not([type='hidden']):not([type='submit']):not([type='button']):not([type='image']), textarea, select, [role='combobox']");
  for (const el of nodes) {
    const signals = [
      (typeof labelText === 'function' ? labelText(el) : ''),
      el.getAttribute && (el.getAttribute('aria-label') || ''),
      el.getAttribute && (el.getAttribute('name') || ''),
      el.id || '',
      el.getAttribute && (el.getAttribute('data-automation-id') || ''),
      el.getAttribute && (el.getAttribute('placeholder') || ''),
    ].filter(Boolean).join(' ').trim().slice(0, 140);
    const isFile = el.tagName === 'INPUT' && el.type === 'file';
    fields.push({
      tag: el.tagName.toLowerCase(),
      type: el.getAttribute ? (el.getAttribute('type') || '') : '',
      id: (el.id || '').slice(0, 60),
      name: (el.getAttribute && (el.getAttribute('name') || '') || '').slice(0, 80),
      signals: signals,
      visible: !!el.offsetParent,
      required: !!(el.required || el.getAttribute?.('aria-required') === 'true'),
      filledBySpotApply: el.dataset ? el.dataset.spotapplyFilled === 'true' : false,
      userModified: el.dataset ? el.dataset.spotapplyUserModified === 'true' : false,
      valueLen: isFile ? (el.files ? el.files.length : 0) : String(el.value || '').length,
      shape: isFile ? (el.files && el.files[0] ? 'file:' + el.files[0].name.slice(-12) : 'file:none')
                    : _redactShape(el.value),
      options: el.tagName === 'SELECT'
        ? Array.from(el.options || []).slice(0, 8).map(o => (o.text || '').slice(0, 40)) : undefined,
    });
  }
  return {
    generated: new Date().toISOString(),
    url: location.href.split('?')[0],
    host: location.hostname,
    isKnownATS: typeof isKnownATS === 'function' ? isKnownATS() : null,
    frame: window.top === window ? 'top' : 'iframe',
    frameActive: typeof HP_FRAME_ACTIVE !== 'undefined' ? HP_FRAME_ACTIVE : null,
    fieldCount: fields.length,
    filledCount: fields.filter(f => f.filledBySpotApply).length,
    nativeAutofill: nativeAutofillOutcome(),
    emptyRequired: fields.filter(f => f.required && !f.valueLen).map(f => f.signals.slice(0, 60)),
    fields,
  };
}

// ── Bridge: dashboard postMessage → background.js → new tab ──────────────────
// Only the SpotApply dashboard may drive the extension. This content script
// runs on every site, so without these checks ANY page could post
// SPOTAPPLY_INIT_EXTENSION with attacker-controlled auth endpoints or force
// tabs open via SPOTAPPLY_LOAD_PACK.
//
// hirepath.dev is deliberately NOT trusted: the product moved to spotapply.ai
// and an expired domain that can drive the extension is a real hijack risk.
const _DASHBOARD_ORIGIN_RE = /^https:\/\/([a-z0-9-]+\.)?spotapply\.ai$|^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i;

// Message names were HIREPATH_*; the dashboard now sends SPOTAPPLY_*. Accept
// both so a cached older dashboard page still drives a fresh install, and
// answer in the same dialect the caller used.
const _MSG = {
  ping: ['SPOTAPPLY_EXT_PING', 'HIREPATH_EXT_PING'],
  loadPack: ['SPOTAPPLY_LOAD_PACK', 'HIREPATH_LOAD_PACK'],
  init: ['SPOTAPPLY_INIT_EXTENSION', 'HIREPATH_INIT_EXTENSION'],
};
const _isMsg = (type, kind) => _MSG[kind].includes(type);
// Replies go out under both names: the listener on the other side belongs to
// whichever dashboard build is loaded, and duplicate replies are idempotent
// (they only set a flag / hide a banner).
function _replyToDashboard(suffix) {
  window.postMessage({ type: `SPOTAPPLY_EXT_${suffix}` }, '*');
  window.postMessage({ type: `HIREPATH_EXT_${suffix}` }, '*');
}

window.addEventListener('message', (e) => {
  if (e.source !== window) return;
  if (!_DASHBOARD_ORIGIN_RE.test(e.origin || '')) return;
  const _type = e.data?.type;
  // Dashboard liveness probe: reply so the "install the extension" banner hides
  // and the Fill buttons know the extension is alive (dashboard pings every 20s).
  if (_isMsg(_type, 'ping')) {
    let alive = false;
    try { chrome.runtime.sendMessage({ type: 'PING' }, () => {}); alive = true; } catch (_) {}
    if (alive) _replyToDashboard('PING_OK');
    return;
  }
  if (_isMsg(_type, 'loadPack') && e.data?.pack) {
    console.log('[SpotApply] Received LOAD_PACK from dashboard, forwarding to background');
    // Test extension context first with a PING
    let ctxOk = false;
    try { chrome.runtime.sendMessage({ type: 'PING' }, () => {}); ctxOk = true; } catch (_) {}
    if (!ctxOk) {
      console.warn('[SpotApply] Extension context invalidated');
      _replyToDashboard('RELOAD');
      return;
    }
    try {
      chrome.runtime.sendMessage({ type: 'OPEN_AND_FILL', payload: e.data.pack }, (res) => {
        if (chrome.runtime.lastError) {
          console.warn('[SpotApply] Background error:', chrome.runtime.lastError.message);
          _replyToDashboard('RELOAD');
        } else {
          console.log('[SpotApply] Background opened tab, sending ACK to dashboard');
          _replyToDashboard('ACK');
        }
      });
    } catch (err) {
      console.warn('[SpotApply] Extension context error:', err.message);
      _replyToDashboard('RELOAD');
    }
  }

  if (_isMsg(_type, 'init') && e.data?.pack) {
    console.log('[SpotApply] Received INIT_EXTENSION from dashboard, initializing background');
    let ctxOk = false;
    try { chrome.runtime.sendMessage({ type: 'PING' }, () => {}); ctxOk = true; } catch (_) {}
    if (!ctxOk) return;
    try {
      chrome.runtime.sendMessage({ type: 'INIT_EXTENSION', payload: e.data.pack });
    } catch (err) {
      console.warn('[SpotApply] Extension init error:', err.message);
    }
  }
});

// ── Auto-fill on page load ────────────────────────────────────────────────────
// Only a tab SpotApply is filling (its own session in background.js) resumes.
// Any other tab — whatever its host — gets at most the manual Fill button.
chromeCall(() => HP_FRAME_ACTIVE && getTabPack((pack, info) => {
    const host = window.location.hostname;
    // A submit was attempted on the previous page of this tab: this page may
    // be the employer's confirmation. (Before the dashboard check: only a tab
    // with a session carries an attempt, and local test forms live on 127.0.0.1.)
    if (pack && info && info.attempt && Date.now() - (info.attempt.ts || 0) < SUBMIT_CONFIRM_WINDOW_MS) {
      setTimeout(() => {
        if (detectApplicationConfirmed()) confirmSubmitted(pack, 'employer_confirmation');
        else watchForConfirmation(pack, info.attempt.ts);
      }, 1500);
      // Just submitted: this page is the site's answer (a confirmation, or the
      // form back with errors). Re-filling it now would bury that answer; the
      // user can still press Fill.
      if (Date.now() - (info.attempt.ts || 0) < 2 * 60 * 1000) return;
    }
    const onDashboard = /(^|\.)spotapply\.ai$/i.test(host) || host === 'localhost' || host === '127.0.0.1';
    if (onDashboard && HP_IS_TOP) { console.log('[SpotApply] On dashboard — skipping auto-fill'); return; }

    // LinkedIn + Indeed: hands-off on EVERY page. Their native apply flows
    // pre-fill from the user's own account, and automating their pages
    // violates their terms — the user's account carries the ban risk. The
    // LinkedIn profile-import card (separate module) is unaffected.
    if (/(^|\.)(linkedin|indeed)\.com$/i.test(host)) {
      console.log('[SpotApply] LinkedIn/Indeed — staying hands-off (native apply pre-fills)');
      return;
    }

    console.log('[SpotApply] Tab session on', host, ':', pack ? _packSummary(pack) : 'none',
                '| launched:', !!(info && info.launched), '| isKnownATS:', isKnownATS());

    if (pack) {
      // Resume where the application left off (login redirects, multi-step
      // forms, a cross-domain hop to the ATS — all inside this tab).
      setTimeout(() => {
        if (_copilotActive) return;
        if (isLoginWall()) {
          console.log('[SpotApply] Login wall detected — waiting for user to log in');
          _copilotActive = true;
          _copilotPack = pack;
          showOverlay('🔐 Please log in to continue.<br><small>I\'ll auto-resume once you\'re in.</small>', [], false);
          watchForFormAppearance();
          return;
        }
        if (isActionablePage()) {
          console.log('[SpotApply] Actionable page — resuming copilot');
          fillForm(pack);
        } else {
          // Maybe a SPA that needs more time (e.g. Workday loading)
          setTimeout(() => {
            if (_copilotActive) return;
            if (isLoginWall()) {
              _copilotActive = true;
              _copilotPack = pack;
              showOverlay('🔐 Please log in to continue.<br><small>I\'ll auto-resume once you\'re in.</small>', [], false);
              watchForFormAppearance();
            } else if (isActionablePage()) {
              fillForm(pack);
            }
          }, 3000);
        }
      }, 2000);
      return;
    }

    // No application in this tab: a manual button that names the job it would
    // use, so filling an unrelated tab is always the user's deliberate choice.
    setTimeout(() => {
      if (_copilotActive) return;
      if (isActionablePage()) injectFillButton();
    }, 2000);
  }
));

// ── Floating manual "Fill" button ─────────────────────────────────────────────

function injectFillButton() {
  if (document.getElementById('hp-fill-btn')) return;
  // Never show the form-fill button on blocked/everyday sites or email clients.
  if (isBlockedHost()) return;
  const _h = window.location.hostname;
  if (_h === 'mail.google.com' || _h === 'outlook.live.com' || _h === 'outlook.office.com') return;
  // Respect a previous dismissal: once the user closes the button on this host,
  // don't show it again — persists across page reloads.
  chromeCall(() => chrome.storage.local.get(['spotapply_dismissed'], (d) => {
    const dismissed = d.spotapply_dismissed || {};
    if (dismissed[_h]) {
      console.log('[SpotApply] Fill button dismissed for', _h, '— not showing');
      return;
    }
    _renderFillButton(_h);
  }));
}

function _renderFillButton(host) {
  if (document.getElementById('hp-fill-btn')) return;
  const wrap = document.createElement('div');
  wrap.id = 'hp-fill-btn';
  Object.assign(wrap.style, {
    position: 'fixed', bottom: '20px', left: '20px', zIndex: '2147483647',
    display: 'flex', alignItems: 'stretch',
    background: 'linear-gradient(135deg,#4f46e5,#7c3aed)', color: '#fff',
    borderRadius: '14px', boxShadow: '0 8px 24px rgba(79,70,229,0.45)',
    fontFamily: 'system-ui,sans-serif', overflow: 'hidden',
  });

  const fill = document.createElement('button');
  fill.textContent = '⚡ Fill with SpotApply';
  Object.assign(fill.style, {
    padding: '12px 14px 12px 18px', border: 'none', cursor: 'pointer',
    background: 'transparent', color: '#fff', fontSize: '13px', fontWeight: '700',
  });

  // ✕ — dismiss and remember the dismissal for this host.
  const close = document.createElement('button');
  close.textContent = '✕';
  close.title = 'Hide on this site';
  Object.assign(close.style, {
    padding: '0 12px', border: 'none', cursor: 'pointer',
    background: 'rgba(0,0,0,0.18)', color: '#fff', fontSize: '12px', fontWeight: '700',
  });
  close.addEventListener('click', (e) => {
    e.stopPropagation();
    wrap.remove();
    chromeCall(() => chrome.storage.local.get(['spotapply_dismissed'], (d) => {
      const dismissed = d.spotapply_dismissed || {};
      dismissed[host] = Date.now();
      chrome.storage.local.set({ spotapply_dismissed: dismissed });
    }));
  });

  fill.addEventListener('click', () => {
    fill.textContent = '⏳ Loading…';
    fill.disabled = true;
    // The job last opened from SpotApply — shown on the button before this
    // click, so the user knows which application they are filling here.
    chromeCall(() => chrome.storage.local.get(['spotapply_fill_pack'], (data) => {
      wrap.remove();
      const freshPack = data.spotapply_fill_pack || null;
      if (freshPack) {
        document.querySelectorAll('input, textarea, select').forEach(el => {
          delete el.dataset.spotapplyUserModified;
        });
        console.log('[SpotApply] Fill button clicked — filling for', freshPack.job_title);
        fillForm(freshPack);
      } else {
        showOverlay(
          '⚠️ No job loaded yet.<br><small style="color:#c4b5fd;font-weight:400">Go to your <b>SpotApply dashboard</b>, find the job, and click <b>Auto Fill</b>. SpotApply will open the application here and fill it automatically.</small>',
          [], true
        );
      }
    }));
  });
  chromeCall(() => chrome.storage.local.get(['spotapply_fill_pack'], (d) => {
    const p = d && d.spotapply_fill_pack;
    if (p && p.job_title) {
      fill.textContent = '⚡ Fill for ' + String(p.job_title).slice(0, 40) +
        (p.company ? ' · ' + String(p.company).slice(0, 30) : '');
      fill.title = 'Fill this form with your SpotApply details for this job';
    }
  }));

  wrap.appendChild(fill);
  wrap.appendChild(close);
  document.body.appendChild(wrap);
}

// ── Page classification helpers ───────────────────────────────────────────────

function isKnownATS() {
  return isTrustedATSHost(window.location.hostname) || isAvaturePage();
}

// Everyday sites where the fill UI must NEVER appear. Prevents the "Fill with
// SpotApply" button from popping up on Google, YouTube, social media, etc.
const _BLOCKED_HOST_PARTS = [
  'google.', 'youtube.', 'gmail.', 'facebook.', 'instagram.', 'twitter.',
  'x.com', 'reddit.', 'netflix.', 'spotify.', 'tiktok.', 'wikipedia.',
  'bing.com', 'yahoo.com', 'duckduckgo.', 'amazon.', 'whatsapp.',
  'chatgpt.com', 'openai.com', 'claude.ai',
];
function isBlockedHost() {
  const h = window.location.hostname.toLowerCase();
  return _BLOCKED_HOST_PARTS.some(part => h.includes(part));
}

function isActionablePage() {
  // Never on everyday/blocked sites. Otherwise require a real application form
  // (or a known ATS). A stray "Apply" link or a lone search box no longer
  // counts — that used to cause false pop-ups on non-job pages.
  if (isBlockedHost()) return false;
  return isKnownATS() || hasApplicationForm();
}

// ── Email Scanning Module (Gmail & Outlook) ───────────────────────────────────
// Self-contained IIFE: only activates on mail.google.com, outlook.live.com, or
// outlook.office.com. Inert on every other hostname.

(function spotapplyEmailScanner() {
  const _host = window.location.hostname;
  const _isGmail = _host === 'mail.google.com';
  const _isOutlook = _host === 'outlook.live.com' || _host === 'outlook.office.com'
    || _host === 'outlook.office365.com';
  if (!_isGmail && !_isOutlook) return;

  console.log('[SpotApply] Email scanner activated on', _host, '· extension v1.1.1 (paginated scan)');

  // ── Job-related keyword filter ────────────────────────────────────────────
  const _JOB_KEYWORDS = /application|applied|applying|position|role|candidate|interview|offer|unfortunately|regret|selected|rejected|next steps|hiring|recruiter|talent|assessment|coding challenge|hackerrank|codility|phone screen|availability|thank you for your interest/i;

  function isJobRelated(subject, snippet) {
    return _JOB_KEYWORDS.test(subject || '') || _JOB_KEYWORDS.test(snippet || '');
  }

  // ── Company name guessing ─────────────────────────────────────────────────
  function guessCompany(senderEmail, senderName) {
    // Try domain first: "alice@greenhouse.stripe.com" → "stripe"
    if (senderEmail) {
      const atIdx = senderEmail.indexOf('@');
      if (atIdx !== -1) {
        const domain = senderEmail.slice(atIdx + 1).toLowerCase();
        // Strip common email provider domains
        if (!/gmail|yahoo|hotmail|outlook|protonmail|icloud|aol|mail\.com/i.test(domain)) {
          const parts = domain.split('.');
          // Remove TLD suffixes (.com, .io, .co, .org, .net, .co.uk, etc.)
          while (parts.length > 1 && /^(com|io|co|org|net|uk|us|dev|ai|app|xyz|jobs|careers)$/.test(parts[parts.length - 1])) {
            parts.pop();
          }
          if (parts.length > 0) {
            const name = parts[parts.length - 1];
            if (name.length >= 2) return name.charAt(0).toUpperCase() + name.slice(1);
          }
        }
      }
    }
    // Fall back to display name: "Alice from Stripe" → "Stripe"
    if (senderName) {
      const fromMatch = senderName.match(/from\s+(.+)/i);
      if (fromMatch) return fromMatch[1].trim();
      const atMatch = senderName.match(/at\s+(.+)/i);
      if (atMatch) return atMatch[1].trim();
      // If display name looks like a company (no spaces, or Title Case)
      if (!/\s/.test(senderName.trim()) && senderName.length >= 2) return senderName.trim();
    }
    return null;
  }

  // ── Inject styles (once) ──────────────────────────────────────────────────
  function injectScannerStyles() {
    if (document.getElementById('hp-email-scanner-styles')) return;
    const style = document.createElement('style');
    style.id = 'hp-email-scanner-styles';
    style.textContent = `
      /* ── CSS custom properties for glassmorphism theme ── */
      :root {
        --hp-glass-bg: rgba(15, 23, 42, 0.85);
        --hp-glass-border: rgba(99, 102, 241, 0.4);
        --hp-glass-blur: 16px;
        --hp-accent: #6366f1;
        --hp-accent-hover: #818cf8;
        --hp-text: #e2e8f0;
        --hp-text-muted: #94a3b8;
        --hp-success: #10b981;
        --hp-error: #ef4444;
        --hp-warning: #f59e0b;
      }

      /* ── Entry animation ── */
      @keyframes hp-slide-up-fade {
        from { opacity: 0; transform: translateY(20px); }
        to   { opacity: 1; transform: translateY(0); }
      }
      @keyframes hp-pulse-ring {
        0%   { box-shadow: 0 0 0 0 rgba(99, 102, 241, 0.5); }
        70%  { box-shadow: 0 0 0 10px rgba(99, 102, 241, 0); }
        100% { box-shadow: 0 0 0 0 rgba(99, 102, 241, 0); }
      }
      @keyframes hp-spin {
        to { transform: rotate(360deg); }
      }

      /* ── Floating sync button ── */
      #hp-email-sync-btn {
        position: fixed;
        bottom: 24px;
        right: 24px;
        z-index: 999999;
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 12px 20px;
        border: 1px solid var(--hp-glass-border);
        border-radius: 16px;
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.92), rgba(30, 41, 59, 0.92));
        backdrop-filter: blur(var(--hp-glass-blur));
        -webkit-backdrop-filter: blur(var(--hp-glass-blur));
        color: var(--hp-text);
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 13px;
        font-weight: 700;
        cursor: pointer;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4),
                    0 0 0 1px rgba(99, 102, 241, 0.15),
                    inset 0 1px 0 rgba(255, 255, 255, 0.05);
        animation: hp-slide-up-fade 0.4s ease-out, hp-pulse-ring 2.5s ease-out 1s 3;
        transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
        user-select: none;
      }
      #hp-email-sync-btn:hover {
        transform: translateY(-2px);
        border-color: var(--hp-accent-hover);
        box-shadow: 0 12px 40px rgba(99, 102, 241, 0.3),
                    0 0 0 1px rgba(99, 102, 241, 0.3);
      }
      #hp-email-sync-btn:active {
        transform: translateY(0);
      }
      #hp-email-sync-btn .hp-icon {
        font-size: 18px;
        line-height: 1;
      }

      /* ── Modal overlay ── */
      #hp-email-scanner-modal {
        position: fixed;
        inset: 0;
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(0, 0, 0, 0.5);
        backdrop-filter: blur(4px);
        -webkit-backdrop-filter: blur(4px);
        animation: hp-slide-up-fade 0.25s ease-out;
      }
      #hp-email-scanner-modal .hp-modal-card {
        position: relative;
        width: 360px;
        max-width: calc(100vw - 40px);
        padding: 28px 24px 24px;
        border-radius: 20px;
        border: 1px solid var(--hp-glass-border);
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.97), rgba(30, 41, 59, 0.97));
        backdrop-filter: blur(var(--hp-glass-blur));
        -webkit-backdrop-filter: blur(var(--hp-glass-blur));
        box-shadow: 0 24px 64px rgba(0, 0, 0, 0.6),
                    0 0 0 1px rgba(99, 102, 241, 0.15),
                    inset 0 1px 0 rgba(255, 255, 255, 0.05);
        font-family: system-ui, -apple-system, sans-serif;
        color: var(--hp-text);
        animation: hp-slide-up-fade 0.35s ease-out;
      }
      #hp-email-scanner-modal .hp-modal-close {
        position: absolute;
        top: 12px;
        right: 14px;
        background: none;
        border: none;
        color: var(--hp-text-muted);
        font-size: 18px;
        cursor: pointer;
        padding: 4px 6px;
        line-height: 1;
        border-radius: 6px;
        transition: color 0.15s, background 0.15s;
      }
      #hp-email-scanner-modal .hp-modal-close:hover {
        color: var(--hp-text);
        background: rgba(255, 255, 255, 0.08);
      }
      #hp-email-scanner-modal h3 {
        margin: 0 0 6px;
        font-size: 17px;
        font-weight: 700;
      }
      #hp-email-scanner-modal .hp-desc {
        color: var(--hp-text-muted);
        font-size: 12.5px;
        margin-bottom: 18px;
        line-height: 1.4;
      }
      #hp-email-scanner-modal .hp-range-group {
        display: flex;
        gap: 8px;
        margin-bottom: 20px;
      }
      #hp-email-scanner-modal .hp-range-opt {
        flex: 1;
        padding: 10px 6px;
        border-radius: 10px;
        border: 1px solid rgba(99, 102, 241, 0.25);
        background: rgba(99, 102, 241, 0.06);
        color: var(--hp-text-muted);
        font-size: 12px;
        font-weight: 600;
        text-align: center;
        cursor: pointer;
        transition: all 0.15s ease;
      }
      #hp-email-scanner-modal .hp-range-opt:hover {
        border-color: var(--hp-accent);
        color: var(--hp-text);
        background: rgba(99, 102, 241, 0.12);
      }
      #hp-email-scanner-modal .hp-range-opt.hp-selected {
        border-color: var(--hp-accent);
        background: rgba(99, 102, 241, 0.2);
        color: #fff;
        box-shadow: 0 0 12px rgba(99, 102, 241, 0.2);
      }
      #hp-email-scanner-modal .hp-scan-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        width: 100%;
        padding: 12px;
        border-radius: 12px;
        border: none;
        background: linear-gradient(135deg, #4f46e5, #7c3aed);
        color: #fff;
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
        transition: opacity 0.15s, transform 0.1s;
      }
      #hp-email-scanner-modal .hp-scan-btn:hover:not(:disabled) {
        opacity: 0.9;
        transform: translateY(-1px);
      }
      #hp-email-scanner-modal .hp-scan-btn:disabled {
        opacity: 0.6;
        cursor: wait;
      }
      #hp-email-scanner-modal .hp-scan-btn .hp-spinner {
        width: 16px;
        height: 16px;
        border: 2px solid rgba(255,255,255,0.3);
        border-top-color: #fff;
        border-radius: 50%;
        animation: hp-spin 0.6s linear infinite;
      }

      /* ── Toast notification ── */
      .hp-email-toast {
        position: fixed;
        bottom: 24px;
        right: 24px;
        z-index: 999999;
        padding: 14px 18px;
        border-radius: 14px;
        border: 1px solid var(--hp-glass-border);
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.97), rgba(30, 41, 59, 0.97));
        backdrop-filter: blur(var(--hp-glass-blur));
        -webkit-backdrop-filter: blur(var(--hp-glass-blur));
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 13px;
        color: var(--hp-text);
        max-width: 340px;
        line-height: 1.5;
        animation: hp-slide-up-fade 0.3s ease-out;
      }
    `;
    document.head.appendChild(style);
  }

  // ── Toast helper ──────────────────────────────────────────────────────────
  function showScannerToast(html, durationMs) {
    document.querySelectorAll('.hp-email-toast').forEach(t => t.remove());
    const toast = document.createElement('div');
    toast.className = 'hp-email-toast';
    toast.innerHTML = html;
    document.body.appendChild(toast);
    setTimeout(() => toast?.remove(), durationMs || 8000);
  }

  // ── Gmail DOM scraper ─────────────────────────────────────────────────────
  // Gmail only renders ~50 rows per page (virtualized list). To cover a full
  // date range we scrape the visible page, then click "Older" and repeat until
  // we pass the cutoff date or run out of pages.
  async function scrapeGmailEmails(dayRange, selfEmail) {
    selfEmail = String(selfEmail || '').toLowerCase();
    const results = [];
    const seen = new Set();
    const cutoff = Date.now() - (dayRange * 24 * 60 * 60 * 1000);
    const MAX_PAGES = 40;  // safety cap (~2000 emails)

    // Scrape the currently rendered page into `results`.
    // Returns true if this page contained an email older than the cutoff
    // (meaning every subsequent page is older too → stop paginating).
    function scrapePage() {
      let reachedCutoff = false;
      const rows = document.querySelectorAll('div[role="main"] tr.zA, table.F tr');
      console.log(`[SpotApply] Gmail scraper: found ${rows.length} email rows on page`);

      rows.forEach(row => {
        try {
          const subjectEl = row.querySelector('.y6 span[data-thread-id]')
            || row.querySelector('.y6 span')
            || row.querySelector('.bog span');
          const subject = subjectEl?.textContent?.trim() || '';

          // A thread the user replied to lists them first ("me"): take the
          // first participant that is NOT the user, or the server would read
          // "me" as a company and match it to any employer containing "me".
          const spans = Array.from(row.querySelectorAll('.yW span[email]'));
          const senderSpan = spans.find(sp => {
            const e = (sp.getAttribute('email') || '').toLowerCase();
            const nm = (sp.getAttribute('name') || sp.textContent || '').trim().toLowerCase();
            return e && e !== selfEmail && nm !== 'me';
          }) || spans[0] || row.querySelector('.zF');
          const senderEmail = senderSpan?.getAttribute('email') || '';
          const senderName = senderSpan?.getAttribute('name')
            || senderSpan?.textContent?.trim() || '';

          const snippetEl = row.querySelector('.y2')
            || row.querySelector('.xW span.y2');
          const snippet = snippetEl?.textContent?.replace(/^\s*[-–—]\s*/, '').trim() || '';

          const dateEl = row.querySelector('.xW span[title]')
            || row.querySelector('td.xW span');
          const dateStr = dateEl?.getAttribute('title')
            || dateEl?.textContent?.trim() || '';

          // Date filtering — Gmail's title attr is like "Tue, Jun 24, 2025, 3:42 PM".
          // Recent rows only show a time (e.g. "10:39") which isn't parseable —
          // those are today's emails, so we keep them.
          if (dateStr) {
            const parsed = Date.parse(dateStr);
            if (!isNaN(parsed) && parsed < cutoff) { reachedCutoff = true; return; }
          }

          if (!isJobRelated(subject, snippet)) return;

          // Dedupe across pages by thread id (or subject+sender fallback)
          const threadId = subjectEl?.getAttribute('data-thread-id')
            || row.getAttribute('data-legacy-thread-id') || '';
          const key = threadId || `${senderEmail}|${subject}|${dateStr}`;
          if (seen.has(key)) return;
          seen.add(key);

          results.push({
            subject,
            sender: senderEmail || senderName,
            sender_name: senderName,
            thread_id: threadId,
            body: snippet,
            date: dateStr,
            company_guess: guessCompany(senderEmail, senderName),
          });
        } catch (e) {
          console.warn('[SpotApply] Gmail row parse error:', e);
        }
      });
      return reachedCutoff;
    }

    // Find Gmail's "Older" (next page) button if it's enabled.
    function getOlderButton() {
      const candidates = document.querySelectorAll(
        'div[role="button"][aria-label="Older"], [aria-label="Older"][role="button"],'
        + ' div[data-tooltip="Older"], [data-tooltip="Older"], [aria-label="Older"]'
      );
      for (const el of candidates) {
        if (el.getAttribute('aria-disabled') === 'true') continue;
        // Gmail greys out the arrow with class 'aZo' (disabled) — skip those.
        if (el.className && /\baZo\b/.test(el.className)) continue;
        return el;
      }
      return null;
    }

    // Gmail's pagination toolbar shows the current range, e.g. "1–50 of 195".
    // When it changes (to "51–100 of 195") we know the next page loaded.
    function getRangeText() {
      const els = document.querySelectorAll('div[role="main"] span, .Dj, .ts, .amH');
      for (const el of els) {
        const t = (el.textContent || '').trim();
        if (/^\d[\d,]*\s*[–-]\s*\d[\d,]*\s+of\s+[\d,]+$/.test(t)) return t;
      }
      return '';
    }

    // Click a Gmail control with a full mouse-event sequence — a synthetic
    // .click() alone often doesn't trigger Gmail's handlers.
    function realClick(el) {
      const opts = { bubbles: true, cancelable: true, view: window };
      el.dispatchEvent(new MouseEvent('mousedown', opts));
      el.dispatchEvent(new MouseEvent('mouseup', opts));
      el.dispatchEvent(new MouseEvent('click', opts));
    }

    for (let page = 0; page < MAX_PAGES; page++) {
      const reachedCutoff = scrapePage();
      if (reachedCutoff) {
        console.log('[SpotApply] Gmail scraper: reached cutoff date — stopping pagination');
        break;
      }

      const older = getOlderButton();
      if (!older) {
        console.log('[SpotApply] Gmail scraper: no Older button — last page reached');
        break;
      }

      const rangeBefore = getRangeText();
      realClick(older);

      // Wait for the page range to advance (e.g. "1–50" -> "51–100"), max ~5s.
      let advanced = false;
      for (let i = 0; i < 50; i++) {
        await new Promise(r => setTimeout(r, 100));
        const now = getRangeText();
        if (now && now !== rangeBefore) { advanced = true; break; }
      }
      if (!advanced) {
        console.log(`[SpotApply] Gmail scraper: page did not advance (range "${rangeBefore}") — stopping`);
        break;
      }
      // Settle delay so the new rows fully paint before scraping.
      await new Promise(r => setTimeout(r, 400));
    }

    console.log(`[SpotApply] Gmail scraper: collected ${results.length} job emails across pages`);
    return results;
  }

  // ── Outlook DOM scraper ───────────────────────────────────────────────────
  async function scrapeOutlookEmails(dayRange) {
    const results = [];
    const cutoff = Date.now() - (dayRange * 24 * 60 * 60 * 1000);

    // Outlook Web uses role="option" items inside a role="listbox",
    // or div[data-convid] inside scrollable containers
    const items = document.querySelectorAll(
      'div[role="listbox"] div[role="option"], div.customScrollBar div[data-convid]'
    );
    console.log(`[SpotApply] Outlook scraper: found ${items.length} email items`);

    items.forEach(item => {
      try {
        // Subject: aria-label often contains the full preview,
        // or dedicated subject element classes
        const subjectEl = item.querySelector('.hcptT')
          || item.querySelector('.lvHighlightSubjectClass')
          || item.querySelector('[class*="SubjectLine"]');
        let subject = subjectEl?.textContent?.trim() || '';
        if (!subject) {
          // Fall back to aria-label
          const ariaLabel = item.getAttribute('aria-label') || '';
          // aria-label is usually "Sender, Subject, Preview, Date"
          const parts = ariaLabel.split(',');
          if (parts.length >= 2) subject = parts[1].trim();
        }

        // Sender
        const senderEl = item.querySelector('.lPC')
          || item.querySelector('.OZZZK')
          || item.querySelector('[class*="SenderName"]');
        const senderName = senderEl?.textContent?.trim() || '';
        const senderEmail = senderEl?.getAttribute('title') || '';

        // Snippet / preview
        const snippetEl = item.querySelector('.n_a')
          || item.querySelector('.IjQyBf')
          || item.querySelector('[class*="PreviewText"]');
        const snippet = snippetEl?.textContent?.trim() || '';

        // Date — Outlook sometimes puts date in a <span> with timestamp attr
        const dateEl = item.querySelector('span[aria-label*="/"]')
          || item.querySelector('[class*="DateTimeText"]')
          || item.querySelector('time');
        const dateStr = dateEl?.getAttribute('aria-label')
          || dateEl?.getAttribute('datetime')
          || dateEl?.textContent?.trim() || '';

        if (dateStr) {
          const parsed = Date.parse(dateStr);
          if (!isNaN(parsed) && parsed < cutoff) return;
        }

        if (!isJobRelated(subject, snippet)) return;

        results.push({
          subject,
          sender: senderEmail || senderName,
          sender_name: senderName,
          body: snippet,
          date: dateStr,
          company_guess: guessCompany(senderEmail, senderName),
        });
      } catch (e) {
        console.warn('[SpotApply] Outlook item parse error:', e);
      }
    });

    return results;
  }

  // ── Classify results for stats ────────────────────────────────────────────
  function classifyResults(emails) {
    let rejections = 0;
    let interviews = 0;
    const rejectionRe = /unfortunately|regret|not.*selected|rejected|not.*moving|decided.*not|other.*candidates/i;
    const interviewRe = /interview|schedule.*call|next.*round|meet.*team|phone.*screen|on-?site/i;

    for (const e of emails) {
      const text = (e.subject || '') + ' ' + (e.body || '');
      if (rejectionRe.test(text)) rejections++;
      if (interviewRe.test(text)) interviews++;
    }
    return { rejections, interviews };
  }

  // ── Scan execution & POST to backend ──────────────────────────────────────
  async function executeScan(dayRange) {
    // The pack first: the scraper needs the user's own address to skip "me".
    const pack = await new Promise((resolve) => {
      chromeCall(() => {
        chrome.storage.local.get(['spotapply_copilot_pack', 'spotapply_fill_pack'],
          (data) => resolve((data && (data.spotapply_copilot_pack || data.spotapply_fill_pack)) || null));
      });
    });
    const scraper = _isGmail ? scrapeGmailEmails : scrapeOutlookEmails;
    const emails = await scraper(dayRange, pack && pack.email);
    console.log(`[SpotApply] Scan complete: ${emails.length} job emails found`);

    if (emails.length === 0) {
      showScannerToast(
        '<span style="font-size:16px">📭</span> <b>No job-related emails found</b>' +
        '<br><span style="color:#94a3b8;font-size:11px">Try a wider date range or scroll down in your inbox to load more emails.</span>',
        6000
      );
      return;
    }

    // POST to backend
    return new Promise((resolve) => {
      (async () => {
            if (!pack || !packBase(pack)) {
              console.log('[SpotApply] executeScan: no active pack/connection found in storage.');
              showScannerToast(
                '<span style="color:#ef4444;font-weight:700">⚠️ Not connected</span>' +
                '<br><span style="color:#94a3b8;font-size:11px">Open your SpotApply dashboard first to connect.</span>',
                6000
              );
              resolve(false);
              return;
            }

            console.log('[SpotApply] executeScan: active pack found, URL:', packBase(pack));
            try {
              console.log('[SpotApply] executeScan: sending apiFetch POST to /api/sync-emails');
              const res = await apiFetch(
                `${packBase(pack)}/api/sync-emails`,
                'POST',
                pack.auth_token,
                { emails, source: _isGmail ? 'gmail' : 'outlook', day_range: dayRange }
              );
              console.log('[SpotApply] executeScan: apiFetch response:', res);

              const stats = classifyResults(emails);
              const d = (res && res.data) || {};
              const matched = d.matched || 0;
              const importedN = d.imported || 0;
              const tracked = matched + importedN;
              const rej = (d.rejections != null) ? d.rejections : stats.rejections;
              const intv = (d.interviews != null) ? d.interviews : stats.interviews;

              if (res && res.ok) {
                showScannerToast(
                  `<span style="font-size:16px">✅</span> <b>Synced ${emails.length} job email${emails.length !== 1 ? 's' : ''}</b>` +
                  `<br><span style="color:#94a3b8;font-size:11px">` +
                  `${tracked} now tracked in your dashboard · ` +
                  `${rej} rejection${rej !== 1 ? 's' : ''}, ` +
                  `${intv} interview signal${intv !== 1 ? 's' : ''}.</span>` +
                  `<br><span style="color:#a5b4fc;font-size:11px">Open your SpotApply dashboard to review them.</span>`,
                  9000
                );
              } else {
                showScannerToast(
                  `<span style="color:#ef4444;font-weight:700">❌ Sync failed</span>` +
                  `<br><span style="color:#94a3b8;font-size:11px">${res?.error || 'Server error. Please try again.'}</span>`,
                  6000
                );
              }
              resolve(res?.ok || false);
            } catch (err) {
              console.error('[SpotApply] Email sync error:', err);
              showScannerToast(
                '<span style="color:#ef4444;font-weight:700">❌ Sync error</span>' +
                `<br><span style="color:#94a3b8;font-size:11px">${err.message || 'Network error'}</span>`,
                6000
              );
              resolve(false);
            }
      })();
    });
  }

  // ── Range picker modal ────────────────────────────────────────────────────
  function showScannerModal() {
    // Remove existing modal if open
    document.getElementById('hp-email-scanner-modal')?.remove();

    const overlay = document.createElement('div');
    overlay.id = 'hp-email-scanner-modal';
    overlay.innerHTML = `
      <div class="hp-modal-card">
        <button class="hp-modal-close" title="Close">&times;</button>
        <h3>📬 Scan Job Emails</h3>
        <div class="hp-desc">Scan your inbox for job application updates — rejections, interviews, offers, and more.</div>
        <div class="hp-range-group">
          <button class="hp-range-opt hp-selected" data-days="7">Last 7 days</button>
          <button class="hp-range-opt" data-days="30">Last 30 days</button>
          <button class="hp-range-opt" data-days="90">Last 90 days</button>
        </div>
        <button class="hp-scan-btn">🔍 Scan Now</button>
      </div>
    `;
    document.body.appendChild(overlay);

    let selectedDays = 7;

    // Close button
    overlay.querySelector('.hp-modal-close').addEventListener('click', () => overlay.remove());

    // Click outside card to close
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) overlay.remove();
    });

    // Escape key to close
    const escHandler = (e) => {
      if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', escHandler); }
    };
    document.addEventListener('keydown', escHandler);

    // Range selection
    overlay.querySelectorAll('.hp-range-opt').forEach(btn => {
      btn.addEventListener('click', () => {
        overlay.querySelectorAll('.hp-range-opt').forEach(b => b.classList.remove('hp-selected'));
        btn.classList.add('hp-selected');
        selectedDays = parseInt(btn.dataset.days, 10);
      });
    });

    // Scan Now button
    const scanBtn = overlay.querySelector('.hp-scan-btn');
    scanBtn.addEventListener('click', async () => {
      scanBtn.disabled = true;
      scanBtn.innerHTML = '<div class="hp-spinner"></div> Scanning…';

      await executeScan(selectedDays);

      overlay.remove();
      document.removeEventListener('keydown', escHandler);
    });
  }

  // ── Inject floating sync button ───────────────────────────────────────────
  function injectSyncButton() {
    if (document.getElementById('hp-email-sync-btn')) return;

    injectScannerStyles();

    const btn = document.createElement('button');
    btn.id = 'hp-email-sync-btn';
    btn.innerHTML = '<span class="hp-icon">✉️</span> Sync Job Emails';
    btn.addEventListener('click', showScannerModal);
    document.body.appendChild(btn);
    console.log('[SpotApply] Email sync button injected');
  }

  // ── Init: wait for DOM to be ready, then inject ───────────────────────────
  // Gmail and Outlook are SPAs — wait a moment for the inbox to render
  if (document.readyState === 'complete') {
    setTimeout(injectSyncButton, 2500);
  } else {
    window.addEventListener('load', () => setTimeout(injectSyncButton, 2500));
  }
})();

// ── LinkedIn Profile Import ─────────────────────────────────────────────────
// Self-contained IIFE: only activates on linkedin.com. It is INERT on every
// other host, and even on LinkedIn it only shows a card on the user's own
// profile page (linkedin.com/in/...). The user clicks "Import", the extension
// reads the profile text ALREADY rendered in their own logged-in tab and POSTs
// it to the legal endpoint (/api/profile/memory/linkedin) — the same paste path
// the dashboard already uses. This is a manual, self-serve import of the user's
// OWN profile: no automation, no third-party profiles, no bulk scraping.
(function spotapplyLinkedInImport() {
  const _host = window.location.hostname;
  if (!_host.includes('linkedin.com')) return; // inert everywhere else

  const CARD_ID = 'hp-linkedin-import';
  const isOwnProfilePath = () => /\/in\//.test(window.location.pathname);

  // Read the profile text already visible in the tab (the main profile column).
  function extractProfileText() {
    const main = document.querySelector('main');
    let text = (main?.innerText || document.body?.innerText || '').trim();
    text = text.replace(/\n{3,}/g, '\n\n'); // collapse big gaps
    return text;
  }

  // POST the extracted text to the legal import endpoint. Requires a connected
  // pack (from the dashboard) for the API base URL + auth token, exactly like
  // the email-sync flow.
  function importProfile() {
    return new Promise((resolve) => {
      const text = extractProfileText();
      if (!text || text.length < 40) {
        resolve({ ok: false, error: 'Could not read your profile. Open your full profile (linkedin.com/in/...) and try again.' });
        return;
      }
      chromeCall(() => chrome.storage.local.get(
        ['spotapply_copilot_pack', 'spotapply_fill_pack'],
        async (data) => {
          const pack = data?.spotapply_copilot_pack || data?.spotapply_fill_pack;
          if (!pack || !packBase(pack)) {
            resolve({ ok: false, error: 'Not connected. Open your SpotApply dashboard first, then try again.' });
            return;
          }
          try {
            const res = await apiFetch(
              `${packBase(pack)}/api/profile/memory/linkedin`,
              'POST',
              pack.auth_token,
              { text: text.slice(0, 20000) }
            );
            if (res && res.ok) {
              resolve({ ok: true, recommendations: (res.data && res.data.recommendations) || '' });
            } else if (res && res.status === 401) {
              resolve({ ok: false, error: 'Session expired. Open your SpotApply dashboard to sign in, then try again.' });
            } else {
              resolve({ ok: false, error: (res && (res.error || (res.data && res.data.detail))) || 'Import failed. Please try again.' });
            }
          } catch (err) {
            resolve({ ok: false, error: err.message || 'Network error.' });
          }
        }
      ));
    });
  }

  function setStatus(el, msg, ok) {
    if (!el) return;
    el.style.display = 'block';
    el.style.color = ok ? '#34d399' : '#f87171';
    el.textContent = msg;
  }

  async function onImportClick(ev) {
    const btn = ev.currentTarget;
    const status = document.getElementById(CARD_ID)?.querySelector('[data-hp-status]');
    const label = btn.textContent;
    btn.disabled = true;
    btn.textContent = '⏳ Importing…';
    if (status) status.style.display = 'none';
    const res = await importProfile();
    btn.disabled = false;
    btn.textContent = label;
    if (res.ok) setStatus(status, '✅ Imported! Open your SpotApply dashboard for suggestions.', true);
    else setStatus(status, '⚠️ ' + res.error, false);
  }

  function renderCard() {
    if (document.getElementById(CARD_ID) || !document.body) return;
    const card = document.createElement('div');
    card.id = CARD_ID;
    card.style.cssText = [
      'position:fixed', 'bottom:24px', 'right:24px', 'z-index:2147483646',
      'width:280px', 'background:#0f0f1a', 'color:#e2e8f0',
      'border:1px solid rgba(99,102,241,0.35)', 'border-radius:14px',
      'padding:14px 16px', 'box-shadow:0 20px 40px rgba(0,0,0,0.45)',
      'font-family:system-ui,-apple-system,sans-serif',
    ].join(';');
    card.innerHTML =
      '<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">' +
        '<span style="font-size:16px">💼</span>' +
        '<span style="font-weight:800;font-size:13px">Import to SpotApply</span>' +
        '<button data-hp-close style="margin-left:auto;background:none;border:none;color:#64748b;cursor:pointer;font-size:14px">✕</button>' +
      '</div>' +
      '<div style="font-size:11px;color:#94a3b8;line-height:1.4;margin-bottom:10px">' +
        'Import <b>your own</b> profile so SpotApply can tailor resumes and cover letters more accurately.' +
      '</div>' +
      '<button data-hp-import style="display:block;width:100%;padding:10px 14px;border:none;border-radius:10px;font-weight:800;font-size:12px;cursor:pointer;color:#fff;background:linear-gradient(135deg,#4f46e5,#7c3aed)">⚡ Import my LinkedIn profile</button>' +
      '<div data-hp-status style="display:none;font-size:11px;text-align:center;margin-top:8px;line-height:1.4"></div>';
    document.body.appendChild(card);
    card.querySelector('[data-hp-import]').addEventListener('click', onImportClick);
    card.querySelector('[data-hp-close]').addEventListener('click', () => card.remove());
  }

  function removeCard() {
    document.getElementById(CARD_ID)?.remove();
  }

  // Show/hide the card as the user navigates LinkedIn's single-page app.
  function tick() {
    if (isOwnProfilePath()) renderCard();
    else removeCard();
  }

  // Popup entry point: the toolbar popup can trigger the same import.
  chromeCall(() => chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
    if (msg && msg.type === 'IMPORT_LINKEDIN') {
      importProfile().then(sendResponse);
      return true; // async response
    }
  }));

  tick();
  setInterval(tick, 1500); // LinkedIn is an SPA — poll for route changes
})();
